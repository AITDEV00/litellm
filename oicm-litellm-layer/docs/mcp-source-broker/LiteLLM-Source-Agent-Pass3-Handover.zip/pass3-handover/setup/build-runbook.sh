#!/usr/bin/env bash
# Reproduce every number in findings/FINDINGS.md.
# Starts from the Pass 2 delta bundle and the Pass 1 reference export.
set -euo pipefail

PKG="$(cd -- "$(dirname -- "$0")/.." && pwd)"
ROOT="${WORK_ROOT:-/tmp/sa-build}"
REF_ZIP="${REF_ZIP:?set REF_ZIP to LiteLLM-1.108.5-Source-Agent-Reference.zip}"
DELTA_DIR="${DELTA_DIR:?set DELTA_DIR to the extracted source-agent-v2 bundle}"

mkdir -p "$ROOT"

# 1. Go 1.27.4, verified. Never pipe a remote script into a shell.
if [[ ! -x "$ROOT/bin/go" ]]; then
  curl -fsSL --max-time 600 -o "$ROOT/go.tgz" https://go.dev/dl/go1.27.4.linux-amd64.tar.gz
  echo "7226736c2339719cda28fbf3a54d71aa63bcefe376e98cef00034268dab24840  $ROOT/go.tgz" | sha256sum -c -
  mkdir -p "$ROOT/gotool" && tar -C "$ROOT/gotool" --strip-components=1 -xzf "$ROOT/go.tgz"
  ln -sfn "$ROOT/gotool/bin/go" "$ROOT/bin/go"; mkdir -p "$ROOT/bin"
  ln -sfn "$ROOT/gotool/bin/go" "$ROOT/bin/go"
fi
GO="$ROOT/bin/go"
export GOTOOLCHAIN=local
[[ "$("$GO" env GOVERSION)" == go1.27.4 ]] || { echo "need go1.27.4" >&2; exit 1; }

# 2. Node 24.22.1. The origin fixture needs net.listen({reusePort}), added in Node 24.
if [[ ! -x "$ROOT/node/bin/node" ]]; then
  curl -fsSL --max-time 600 -o "$ROOT/node.tar.xz" https://nodejs.org/dist/v24.22.1/node-v24.22.1-linux-x64.tar.xz
  mkdir -p "$ROOT/node" && tar -xJf "$ROOT/node.tar.xz" -C "$ROOT/node" --strip-components=1
fi
export PATH="$ROOT/node/bin:$ROOT/bin:$PATH"

# 3. Reference extraction and delta application. The script self-verifies with BASELINE.sha256.
rm -rf "$ROOT/reference-export" "$ROOT/candidate"
python3 - "$REF_ZIP" "$ROOT/reference-export" <<'PY'
import sys, zipfile
zipfile.ZipFile(sys.argv[1]).extractall(sys.argv[2])
PY
cp -a "$ROOT/reference-export/source-agent-reference" "$ROOT/candidate"
bash "$DELTA_DIR/apply-delta.sh" "$ROOT/candidate"

# 4. Build, race suite, behavior suite.
export GOPATH="$ROOT/gopath" GOCACHE="$ROOT/gocache" GOMODCACHE="$ROOT/gomod" \
       GOPROXY=https://proxy.golang.org,direct
make -C "$ROOT/candidate" GO="$GO" build
make -C "$ROOT/candidate" GO="$GO" unit
# Ports must be free: a stale fixtures.mjs holding the shared origin port makes setup hang.
pkill -f 'fixtures.mjs' 2>/dev/null || true
sleep 1
python3 "$DELTA_DIR/tests/behavior.py" "$ROOT/candidate/bin/source-agent" "$ROOT/results/candidate-behavior"

# 5. Throughput sweep, direct vs relay, at 10k/50k/100k offered.
python3 "$DELTA_DIR/benchmarks/run.py" --binary "$ROOT/candidate/bin/source-agent" \
  --variant candidate --out "$ROOT/results/candidate-sweep" \
  --parallel 768 --agent-streams 896 --data-memory 512 --channel-memory 384 \
  --idle-connections 384 --concurrency 1024 --workers 8 --seconds 6 \
  --rates 10000,50000,100000

# 6. Profiles.
GO="$GO" bash "$DELTA_DIR/benchmarks/prepare-profiles.sh" "$ROOT/candidate" "$ROOT/profiler"
python3 "$DELTA_DIR/benchmarks/run.py" --binary "$ROOT/profiler/profile-replica" \
  --variant candidate --out "$ROOT/results/profile-run" \
  --parallel 512 --idle-connections 128 --seconds 10 --rates 20000
cd "$ROOT/profiler"
"$GO" tool pprof -top -nodecount=25 replica.test relay.cpu.pprof    > relay-cpu-top.txt
"$GO" tool pprof -top -nodecount=20 replica.test run.cpu.pprof      > agent-cpu-top.txt
"$GO" tool pprof -sample_index=alloc_space -top -nodecount=25 replica.test relay.mem.pprof > relay-alloc-top.txt
"$GO" tool pprof -sample_index=alloc_space -top -nodecount=20 replica.test run.mem.pprof   > agent-alloc-top.txt
echo "done: results under $ROOT/results, profiles in $ROOT/profiler"
