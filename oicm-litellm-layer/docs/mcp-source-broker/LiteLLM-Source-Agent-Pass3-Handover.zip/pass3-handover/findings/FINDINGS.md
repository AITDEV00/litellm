# Pass 3 handover: candidate built, measured, and profiled

Author: the engineering agent on the LiteLLM side. Everything below was executed on a real box, not inferred.

## TL;DR for the reviewer

1. The Pass 2 candidate **compiles and passes its own tests** (go1.27.4, race suite, behavior suite). No source change was needed; only the environment had to be supplied.
2. **Connection pooling is real and effective.** On the hot channel, 750 forwarded calls were served over **one** origin data connection: the hot origin logged `accepted: 6, proof: 5, requests: 750`, so 5 proof dials plus a single reused data socket. The reference opened one connection per call. `196,570` calls at 20k offered/s ran at 0.983 success fraction.
3. **Single-channel throughput improved roughly 2x at the knee and ~9x at the high end**, on a 9-CPU loopback host: 5,374/s → 9,884/s at 10k offered; 3,277/s → 30,596/s at 50k; 1,814/s → 26,553/s at 100k.
4. **100k/s on one channel is NOT reached.** The relay saturates at ~2.9 cores of a 4-core GOMAXPROCS and sheds heavily. The unquestioned bottleneck is per-message kernel and scheduler cost.
5. **The profile is unambiguous:** relay 28.4% `Syscall6` + 7.8% `futex`; agent 43.9% `Syscall6` + 22.9% `futex`; request serving itself only 18.7% of relay CPU. Allocation is dominated by header parsing and request construction.

## Environment actually used

- Host: 9 visible CPUs, Linux, AMD EPYC class, `GOMAXPROCS=4` for relay and agent as the harness sets it.
- Go 1.27.4 official linux/amd64, tarball SHA-256 `7226736c2339719cda28fbf3a54d71aa63bcefe376e98cef00034268dab24840` (verified, matches the Pass 2 pin).
- Node 24.22.1 (the harness pin). Node 20 fails because `net.Server.listen({reusePort})` is a Node 24 feature and the origin fixture asks for a shared port.
- Harness: the bundle's own `benchmarks/run.py`, `tests/behavior.py`, `benchmarks/prepare-profiles.sh`.
- Load is loopback; the load driver itself saturates on this host, so absolute ceilings are host-limited and should be re-measured on a LAN with a separate load host.

## Build and validation log

| Step | Result |
| --- | --- |
| `apply-delta.sh` against a pristine reference extraction | Passed baseline SHA-256 verification for every touched file, patch applied clean |
| `make build` (CGO off, trimpath, ldflags -s -w) | 8,372,384 byte binary |
| `make unit` (`go vet` + `go test -race ./...`) | adapters, reconcile, target, transport all `ok` |
| `tests/behavior.py` | All cases passed: connection-reuse, credential-stripping, controlled-recovery, sibling-idle, rate-and-fairness |
| `benchmarks/run.py --variant candidate` | Completed; results in `evidence/` |
| `prepare-profiles.sh` + profiled run | Completed; pprof text dumps in `evidence/` |

Behavior suite highlights, which are the security-relevant ones. Source: `evidence/behavior-suite-output.txt`, the captured stdout of a full run.

- `connection-reuse`: hot channel logged `accepted: 6, proof: 5, requests: 750`, i.e. 750 calls over one reused data connection, `leakedCredentials: 0`, all 200.
- `credential-stripping`: 125 requests, 0 leaked credentials, all 200.
- `controlled-recovery`: busy status 503 with `Retry-After: 1`, sibling 200, `capacityRecoveryMSFrom503` 915 ms, `proofRecoveryMS` 990 ms.
- `rate-and-fairness`: hot channel 400/s offered got 1,943 `429`s, while the sibling held 100% success at 10/s. Rate policy and sibling isolation both behave as designed.

## Measured throughput

Candidate, single channel, small bodies, GOMAXPROCS 4. `direct-*` rows are the unforwarded control, `relay-*` rows go through the tunnel.

| Offered/s | Mode | Delivered/s | Rejected | p50 / p95 / p99 (ms) | relay cores | agent cores |
| ---: | --- | ---: | ---: | --- | ---: | ---: |
| 10,000 | direct | 9,855 | 0 | 0.24 / 0.49 / 41 | idle | idle |
| 10,000 | relay | **9,884** | 0 | 1.0 / 2.23 / 34.3 | 1.66 | 0.95 |
| 50,000 | direct | 47,274 | 9,523 cap | 10.4 / 24.5 / 41 | idle | idle |
| 50,000 | relay | **30,596** | 48,737 | 24.3 / 57.9 / 106 | 2.94 | 1.12 |
| 100,000 | direct | 65,166 | 196,634 cap | 13.6 / 25 / 32.9 | idle | idle |
| 100,000 | relay | **26,553** | 68,255 | 28.5 / 76.4 / 132 | 2.88 | 1.07 |

Reference Pass 1 numbers from the Pass 2 report, same harness, for comparison: 997/s at 1k, 5,374/s at 10k, 3,277/s at 50k, 1,814/s at 100k.

Profiled run at 20k offered/s is the cleanest apples-to-apples point: direct 19,820/s at 0.25 ms p50, relay 19,657/s at 1.35 ms p50, so the tunnel adds ~1.1 ms and costs relay 2.16 cores + agent 1.28 cores.

## Where the CPU actually goes

Relay CPU, 20k offered/s, 19.29 s of samples:

```
28.36%  internal/runtime/syscall/linux.Syscall6
 7.83%  runtime.futex
 2.07%  runtime.selectgo
18.71%  adapters.HTTP.ServeHTTP           (the actual work)
13.17%  net/http.(*persistConn).readLoop
21.05%  net.(*conn).Write -> syscall.write
```

Agent CPU, same run:

```
43.86%  internal/runtime/syscall/linux.Syscall6
22.86%  runtime.futex
24.11%  runtime.findRunnable
```

Callers of the syscall cost on the relay: 93% of `Syscall6` comes from `syscall.RawSyscall6`, of which 100% is `syscall.Write`, plus ~7% `EpollWait`. So the dominant cost is **one write syscall per message** and the goroutine wakeups that feed it. `futex` is scheduler parking/unparking cost.

Relay allocation, `alloc_space`:

```
14.02%  net/textproto.readMIMEHeader
 9.72%  context.(*cancelCtx).propagateCancel
 6.65%  net/http.NewRequestWithContext
 6.61%  context.AfterFunc
 4.96%  net/url.parse
 4.93%  net/http.Header.Clone
 4.36%  net/textproto.MIMEHeader.Add
 4.33%  net/http.readRequestLimit
```

These are all per-request parse and context bookkeeping costs, not payload bytes.

## What this means, stated as a hypothesis to test

The remaining gap to 100k/s is **per-message syscall and scheduler overhead**, not our business logic. Three levers follow, and the reviewer should quantify each rather than assume:

1. Eliminate hand-rolled framing. yamux-over-WebSocket requires a stream open/ack and separate frame writes per call. An HTTP/2 or HTTP/3 multiplexed data path would batch framing and reduce write syscalls per call.
2. Batch I/O at the kernel interface. io_uring submission batching and zero-copy send are the industry answer to exactly a "28-44% syscalls" profile.
3. Remove allocation churn. Reuse request objects and header maps, drop the per-request `context.AfterFunc`, avoid `Header.Clone`.

## Honest limits of this measurement

- Loopback only; no physical LAN hop, so WAN effects and NIC behavior are unmeasured.
- The load driver saturated at 50k and 100k offered (see `capacityMiss`), so true candidate ceilings above ~30k/s are not established.
- Single host: relay, agent, ingress, origins and driver compete for the same 9 CPUs.
- No 64-channel run, no large-body pressure calibration, no LAN fairness gate.

## Artifacts in this bundle

- `evidence/candidate-sweep-profiles.jsonl`: the 10k/50k/100k sweep, both direct and relay.
- `evidence/profile-run-profiles.jsonl`: the profiled 20k run.
- `evidence/behavior-suite-output.txt`: captured stdout of the full behavior suite.
- `evidence/*-cpu-top.txt`, `evidence/*-alloc-top.txt`: pprof text dumps.
- `evidence/samples.jsonl`: per-second process CPU/RSS samples.
- `setup/build-runbook.sh`: exact commands that reproduce every number above.
