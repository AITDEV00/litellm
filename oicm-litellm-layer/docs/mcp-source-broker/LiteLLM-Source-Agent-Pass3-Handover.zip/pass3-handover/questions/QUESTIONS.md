# Questions for the research agent (Pass 3)

Context: `findings/FINDINGS.md` has measured results from a real build. The profile says per-message syscalls and scheduler wakeups dominate. Answer the questions below with measurements or explicit arithmetic, not surveys. Where you cannot run something, say so and show the calculation instead.

## Ground rules

- Start from `setup/build-runbook.sh`; it reproduces every number we have.
- Do not restate the Pass 2 design. We have read it.
- Label every number as measured-on-hardware or calculated. No mixing.
- "Pending" is an acceptable answer only if you name what blocks it.

## Q1. What is the actual ceiling of the current pooled design?

The sweep above is loopback on one 9-CPU host with the load driver saturating. Give us the real per-channel ceiling by removing the driver as a bottleneck:

- Run the load driver on a separate host over a real NIC, or at minimum run two driver processes and confirm `capacityMiss` is 0 at every rate.
- Report the highest offered rate with zero shedding and the highest delivered rate before p99 exceeds 10 ms.
- State the relay and agent cores per 1,000 delivered/s. That coefficient is what we need to size a pod.

## Q2. How much of the syscall cost does HTTP/2 actually remove here?

This is the decision that matters most. We currently pay a yamux stream open plus a WebSocket write per call. Concretely:

- Build a minimal Go HTTP/2 (h2c, no TLS) server-plus-client loopback pair carrying the same 128-byte request/response shape as our data plane.
- Measure requests/s per core, and compare against a raw yamux-over-WebSocket equivalent built the same way in your test.
- Report `Syscall6` and `futex` share from pprof for both. If the h2 framing path collapses the write-syscall count per call, show the syscall count, not just CPU.
- Conclude with a multiplier: expected candidate requests/s per core after replacing our framing, and the uncertainty band.

Do not compare against `net/http`'s full reverse-proxy stack; compare framing-to-framing, or the comparison is meaningless.

## Q3. Does io_uring help a Go process of this shape, and by how much?

- Ground the answer in a Go benchmark, not a Rust or C one. `net/http` does not use io_uring, so decide what would: the listener, the WSS/TLS reads, or only our own copy path.
- Give an expected range for a 28-44% `Syscall6` profile. If the honest answer is "you must replace the transport entirely", say that and quantify the rewrite.
- Check whether any maintained Go library gives us usable io_uring network I/O as of Go 1.27, and name versions.

## Q4. Is there a smaller change that closes most of the gap?

Before any transport rewrite, evaluate these and rank by measured gain per unit of work:

- Reusing `http.Request` objects and header maps across calls (`net/textproto.readMIMEHeader` is 14% of allocation).
- Removing the per-request `context.AfterFunc` / `propagateCancel` (16.3% combined).
- Avoiding `Header.Clone` and `net/url.parse` on the hot path.
- Raising `parallel` versus raising `idle_connections`: which one actually moves throughput at a fixed rate, measured.

If a week of Go-level work gets us to 60k/s, say so and say why.

## Q5. What does the production-shaped topology do to these numbers?

Our real deployment is not loopback. Answer with a measured or calculated estimate:

- nginx ingress TLS termination plus our tunnel: what does the extra hop cost at 10k/s and 50k/s, in cores and p99?
- Confirm `TCP_NODELAY` behavior through the ingress. The Pass 2 report saw 141/s versus 5,374/s on this one variable; we need to know whether our nginx config already sets it and how to verify from outside.
- Kubernetes pod network (not host loopback): measure or cite the per-request cost of the veth path at these rates.

## Q6. Prompt caching and SSE streaming change the shape entirely. Are we optimizing the right workload?

Our MCP source broker carries both short JSON tool calls and long SSE streams. Answer separately:

- For long-lived streams (minutes), the per-request cost is irrelevant and the memory model dominates. What is the maximum concurrent stream count per 1 GiB of agent memory, measured on the current design?
- For short calls, throughput dominates. How do the two workloads need different `scale` blocks in practice, and what should the defaults be for each?

## Q7. Where does this design simply lose to an off-the-shelf proxy?

We should know when to stop. If an MCP-aware deployment could route through HAProxy or Envoy for the data plane while keeping our broker for authentication and policy, what would that architecture look like and what throughput would it reach? Give the concrete topology and the gap this source-agent design would need to close to be worth keeping.

## Deliverable format

For each question: the number, how it was obtained (command or calculation), and a one-line verdict. If you recommend a direction, state the expected gain and the cost, and mark both as measured or estimated. A short document with real numbers beats a long one with adjectives.
