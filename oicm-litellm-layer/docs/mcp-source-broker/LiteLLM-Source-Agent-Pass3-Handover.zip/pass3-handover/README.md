# Research package: LiteLLM source-agent, Pass 3

Handover from the LiteLLM engineering side after building, testing and profiling the Pass 2 candidate.

## Read in this order

1. `findings/FINDINGS.md`: what we measured, what the profile says, and the honest limits of the measurement.
2. `questions/QUESTIONS.md`: seven questions we need answered with numbers.
3. `setup/build-runbook.sh`: one script that rebuilds everything from scratch.

## What is in here

```
findings/FINDINGS.md            measured results, CPU and allocation attribution, limits
questions/QUESTIONS.md          the questions, with the ground rules
setup/build-runbook.sh          verified-toolchain build, tests, sweep, profiling
evidence/relay-cpu-top.txt      relay pprof top, 20k offered/s
evidence/agent-cpu-top.txt      agent pprof top
evidence/relay-alloc-top.txt    relay allocation profile
evidence/agent-alloc-top.txt    agent allocation profile
evidence/candidate-sweep-profiles.jsonl   10k/50k/100k direct vs relay
evidence/profile-run-profiles.jsonl       the profiled 20k run
evidence/behavior-suite-output.txt        captured behavior suite output
evidence/samples.jsonl                    per-second process CPU/RSS
evidence/environment.json                 harness and host metadata
workspace/source-agent-v2/      the Pass 2 delta, applyable, plus its harness
```

`workspace/` is the unmodified Pass 2 bundle so this package is self-contained. `evidence/` is the output of running it, which the bundle did not have.

## The one-paragraph state of play

The candidate compiles on go1.27.4 and passes its race suite and behavior suite. Connection pooling works exactly as designed: on the hot channel, 750 forwarded calls went over a single reused origin data connection (the origin logged 5 proof dials plus 1 data accept), instead of one connection per call. Single-channel goodput improved from 5,374/s to 9,884/s at 10k offered and from 3,277/s to 30,596/s at 50k. It still does not reach 100k/s, and the profile explains why in one line: 28% of relay CPU and 44% of agent CPU is raw `Syscall6`, with `futex` scheduler cost on top, while our actual request handling is 18.7%. The bottleneck is per-message kernel and scheduler traffic, so the open question is which transport change removes the most of it per unit of work.

## Environment the numbers came from

9 visible CPUs, loopback, `GOMAXPROCS=4` per process, Go 1.27.4 (tarball verified against the official digest), Node 24.22.1. Same harness the Pass 2 bundle ships. The load driver saturates above ~30k offered/s on this host, so treat the 50k and 100k figures as floors, not ceilings.

## What we are not asking for

We do not need the Pass 2 design restated, and we do not need a survey of proxy products. We need to know, per question, whether a given change moves the needle enough to justify its cost, with the number that proves it.
