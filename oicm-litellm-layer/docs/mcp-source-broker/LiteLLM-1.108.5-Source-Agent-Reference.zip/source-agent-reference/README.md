# LiteLLM outbound source agent

**One outbound WSS connection per source host, one approval and health boundary per service, and one existing LiteLLM registration per backend.** The agent carries bytes. LiteLLM v1.108.5 LTS retains MCP discovery, execution, virtual keys, access groups, guardrails and spend logs.

| Start here | Purpose |
|---|---|
| [Architecture](docs/ARCHITECTURE.md) | Traffic and registration model |
| [Integration](integration/README.md) | Run locally and with the existing LiteLLM control API |
| [Kubernetes](docs/DISCOVERY.md) | Named Service discovery, manifests and cluster instructions |
| [Comparison and evidence](docs/EVALUATION-AND-TRADEOFFS.md) | What ran and alternatives |
| [Upgrade](docs/UPGRADE.md) | Verify and deploy the exact signed binary and image |

This is a separate reference tree. The real end-to-end test uses upstream LiteLLM v1.108.5 and the existing API seams. The private fork was available as an export.

## Run the tests

Use Linux amd64, Python 3.12, curl, OpenSSL 3 and Node/npm for the Prisma setup. The Kubernetes API test also uses Linux user/network namespaces. The commands fetch verified Go 1.27.4, Caddy 2.11.9 and Kubernetes API assets. Supply a local archive directory with the fetch script's --archives option for offline staging.

~~~bash
python3 tests/fetch.py go caddy kubernetes
export CADDY="$PWD/.lab-tools/caddy"
export KUBEBUILDER_ASSETS="$PWD/.lab-tools/controller-tools/envtest"
export PATH="$PWD/.lab-tools/go/bin:$PATH"
./tests/setup_python.sh
export PATH="$PWD/.venv/bin:$PATH"
make unit behavior
make e2e
make kube
make bench
make artifacts
~~~

Run the optional stock comparison with `python3 tests/fetch.py frp && make compare-frp`. The Linux executable and OCI archive are in bin/. Verify them with the [release instructions](docs/UPGRADE.md). Start with an isolated staging alias.

## Research questions

| Questions | Where answered |
|---|---|
| 1–4, 7–8 | [Data plane](docs/DATA-PLANE.md) |
| 5–6, 13 | [Architecture](docs/ARCHITECTURE.md) and [integration](integration/README.md) |
| 9–12, 18 | [Discovery](docs/DISCOVERY.md), [authentication](docs/AUTHENTICATION.md) and [upgrade](docs/UPGRADE.md) |
| 14–15 | [Lifecycle](docs/LIFECYCLE.md) |
| 16–17 | [Authentication](docs/AUTHENTICATION.md) |
| 19–20 | [Comparison](docs/EVALUATION-AND-TRADEOFFS.md) and [branch delta](docs/WHY-DELTA.md) |
