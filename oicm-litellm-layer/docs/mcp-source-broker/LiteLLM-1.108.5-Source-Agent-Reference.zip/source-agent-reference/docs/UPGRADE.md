# Signing, rollout and recovery

The Ed25519-signed release manifest covers platform, version, the executable SHA-256 and OCI manifest digest. The bundled public key identifies this reference release. Pin your organization's independently trusted release key for deployment. A key bundled with a download cannot prove organizational approval.

Verify before execution, using OpenSSL and the independently trusted public key.

~~~bash
base64 -d bin/release.sig.b64 > /tmp/source-agent-release.sig
openssl pkeyutl -verify -pubin -inkey /path/to/trusted-release-key.pem \
  -sigfile /tmp/source-agent-release.sig -rawin -in bin/release.json
python3 -c 'import json; print(json.load(open("bin/release.json"))["sha256"] + "  bin/source-agent")' | sha256sum -c -
~~~

The verify subcommand is also available in an already trusted binary. Import the OCI image to an internal registry while preserving digests. The OCI archive uses a scratch root filesystem, nonroot 10001 and the same static executable. Mount the gateway CA explicitly.

~~~bash
skopeo copy --preserve-digests \
  oci-archive:bin/source-agent-linux-amd64.oci.tar:0.1.0 \
  "docker://$INTERNAL_REGISTRY/source-agent:0.1.0"
~~~

The equivalent Containerfile lives under source-agent/kubernetes/. If registry policy changes the digest, sign the resulting artifact before use. The air-gapped cluster may import the verified archive through its own image distribution workflow.

For hosts that can reach only gateway ingress, serve the binary, manifest and detached signature by importing examples/Caddyfile.release inside the approved TLS site. Set SOURCE_AGENT_RELEASE_DIR to a read-only directory containing just those three files. The Caddy handler serves three versioned GET/HEAD paths. Stage the downloads without executing them. Distribute the expected signing key independently.

~~~bash
export SOURCE_RELEASE=https://gateway.example.org/source-agent/releases/0.1.0
mkdir -m 700 source-agent-stage
for asset in source-agent release.json release.sig.b64; do
  curl --fail --silent --show-error --proto '=https' \
    --cacert /path/to/gateway-ca.pem "$SOURCE_RELEASE/$asset" -o "source-agent-stage/$asset"
done
~~~

Run the same signature and checksum checks against the staged files, then install the binary through the host's managed service or a versioned image. Bootstrap, desired configuration and credential delivery can run independently of this download.

Drain active channels, wait for the desired revision and zero in-flight work, then replace the verified binary by rename or change the Deployment digest. Preserve the configuration and credential. Resume the channels and require fresh proof. A process restart disconnects all channels and legacy sessions reinitialize. Roll back with a compatible binary and live credentials. A new wire major should use a distinct ingress path during migration.
