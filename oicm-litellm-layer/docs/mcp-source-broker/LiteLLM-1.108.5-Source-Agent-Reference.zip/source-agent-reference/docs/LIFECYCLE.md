# Lifecycle and reconciliation

| Action | Durable input | Live behavior |
|---|---|---|
| Request publication | Enabled target ID in AgentState | Relay shows awaiting_approval until exact descriptor and valid origin proof are granted. |
| Approve or replace channel | Exact descriptor, proof key and release digest; increase channel revision on replacement | Attaches independently. Replacing a revision cancels its streams and expires its native session IDs. |
| Drain | Same channel revision, phase draining and an absolute drain_until | Stops new calls when applied. Existing calls may finish. At deadline reset residual streams and discard channel state. |
| Revoke target | Persist revoked tombstone | Cut only matching target streams. Explicit readmission increments its revision. |
| Revoke agent | Persist revoked agent grant | Close its WebSocket and all streams. The old credential fails to attach. |
| Recover or regenerate | Higher credential epoch and new digest under the same ID | Replace protected secret, retain approved config, require new connection and fresh proof. |
| Restart/replace | Reuse durable files or mounted inputs | Reconnect with backoff, rebuild live proof, and return 404 for old native session IDs. |

PostgreSQL acknowledges a **desired revision**. The relay exposes loaded_revision, freshness, per-channel phase, health and active count on private /v1/observed. A writer receives awaiting_relay after commit. Poll until the relay applies the intended revision. The sample writer locks the expected SQL row, validates the transition using the same Go rules as the relay and rejects a lost tombstone, reused generation or stale revision inside the transaction. The Go relay polls a complete, monotonically versioned projection about every 500 ms and keeps live health separate from the desired store. A delayed probe checks that its original channel still exists before writing observations.

On feed loss new traffic starts failing after a five-second policy age limit. The next reconcile closes live sockets, including any remaining drained work. A fresh grant and new origin proof are needed after reconnection. Keep revisions and tombstones when restoring a database backup. The relay's highest-seen revision is in memory. Its snapshot is capped at 256 KiB and 128 agents, with at most 16 channel entries per agent including tombstones. A multi-replica deployment needs shared ownership fencing and private call routing to the correct relay. This pilot uses a single relay and one process per identity.

## Catalog refresh and rollback

1. Review the new source release and the live diff with the existing staging LiteLLM workflow. Save the old origin version, approved digest, pinned tools and spec. Drain incompatible changes and hold consumer grants through the switch.
2. Deploy the reviewed origin release and publish the new digest with a higher channel revision. Wait for relay proof. The connector's identity, credential and WebSocket can stay in place.
3. For OpenAPI, update the existing row to the reviewed versioned spec with PUT /v1/mcp/server. For native MCP, use the same row and approved allowlist, then apply the existing admin POST /v1/mcp/server/{id}/pin. Restore grants after an actual tool call succeeds. Transport approval alone cannot add an allowed tool.
4. To roll back, restore the former origin version and its digest under a **higher** channel revision, then restore the former registry spec or pin and allowlist. Recover credentials only for agent identity changes.

[Integration instructions](../integration/README.md)
