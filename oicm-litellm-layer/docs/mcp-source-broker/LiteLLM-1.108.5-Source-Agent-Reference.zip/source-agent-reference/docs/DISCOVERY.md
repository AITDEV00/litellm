# Local control and Kubernetes discovery

Host and pod use the same typed YAML or JSON AgentState and TargetPolicy. A host operator selects IDs via CLI/TUI and the loopback API, using expected_revision. The process validates the schema and writes the file atomically. In mounted mode, update the ConfigMap with a higher revision. Mount the directory since subPath mounts do not receive updates. An invalid or stale file reports an error and retains the last valid local state. A central revoke remains authoritative. Choose one local writer.

| Local route | Behavior |
|---|---|
| GET /v1/status | Desired revision, allowlisted IDs, local problems, relay revision, observed health and active calls. |
| GET /v1/desired | Current enabled ID set and revision. |
| PUT /v1/desired | JSON expected_revision and enabled. HTTP 200 for commit/no-op, 409 for conflict, 422 for invalid targets, 405 in mounted mode. |

The optional numeric loopback listener requires a distinct token file. The CLI and TUI use the same endpoints. Neither can publish a new LiteLLM registration.

Selecting a target requests publication. A catalog replacement is submitted as a reviewed origin release and digest through the existing operator workflow. The TUI reports mismatch and readiness. The authority projection and LiteLLM pin record the approved replacement separately.

## Kubernetes mode

Use one agent per trusted workload or namespace and a distinct ID per cluster/security boundary. Use GitOps-mounted desired state. A future CR can materialize its spec as the same AgentState inputs. A custom controller or CRD is unnecessary here. Service metadata supplies allowlist and consent evidence. Port scans, broad list/watch and automatic registration are excluded.

The Role allows named Services reports and tools through GET only. Discovery requires exact namespace and UID, a consent annotation, selector-backed ClusterIP, a named TCP port and the approved private Service CIDR. It rejects ExternalName, headless and external IPs. It has no get/list privileges on Pods, EndpointSlices, Secrets or ConfigMaps. Kubernetes projects a short-lived token and CA. The connector rereads the token on discovery. Broker credentials stay in a separate Secret. [RBAC resource names](https://kubernetes.io/docs/reference/access-authn-authz/rbac/#referring-to-resources) · [ServiceAccount tokens](https://kubernetes.io/docs/tasks/configure-pod-container/configure-service-account/)

1. Apply the RBAC. Use selector-backed Services owned by your operators and annotate source-agent.example.org/target with the exact descriptor ID. Record each UID, namespace, Service port and its name.
2. Adapt the example identity, desired state and target policy. Replace address with a service object containing namespace, name, uid, port_name, port and cidr. Set ca_file to /config/gateway-ca.pem. The NetworkPolicy selects Pods labeled source-agent.origin with values reports or tools and allows target port 8443. Adapt both to your workload and CNI. Configure tls_name on the descriptor and the relay's trusted CA for HTTPS origins.
3. Deliver runtime credential and local control token via the separate Secret. Import the signed OCI image and use its pinned digest. The bundled example.rendered.yaml shows the exact release digest with example registry and network values. Render again for your cluster using the approved ingress IP and API destination. Test the policy against your CNI's Service translation behavior.

~~~bash
kubectl apply -f source-agent/kubernetes/rbac.yaml
kubectl -n source-lab create configmap source-agent-config \
  --from-file=identity.yaml --from-file=targets.yaml --from-file=agent-state.yaml --from-file=gateway-ca.pem \
  --dry-run=client -o yaml | kubectl apply -f -
kubectl -n source-lab create secret generic source-agent-credentials \
  --from-file=credential.yaml --from-file=control.key \
  --dry-run=client -o yaml | kubectl apply -f -
python3 source-agent/kubernetes/render.py \
  --image "$APPROVED_IMAGE_AT_DIGEST" --gateway-ip "$GATEWAY_CIDR" \
  --apiserver-ip "$APISERVER_CIDR" --apiserver-port "$APISERVER_PORT" > agent-staging.yaml
kubectl apply -f agent-staging.yaml
kubectl -n source-lab rollout status deployment/source-agent
kubectl -n source-lab exec deploy/source-agent -- /source-agent status -token-file=/credentials/control.key
~~~

Pair egress allowances with ingress protection on origin Pods. For legacy stateful MCP, use one origin replica per approved channel or a genuinely session-aware upstream. A normal multi-pod Service can send separate HTTP connections to different pods. Give each independent namespace or cluster its own ID and credentials.

The lab starts real Kubernetes v1.35.0 API/etcd, issues a short-lived ServiceAccount token and verifies both GET grants and RBAC denials. The same agent binary uses mounted-file-shaped inputs and two real ClusterIP values mapped inside an isolated namespace. Replacement reuses the agent ID and refreshes the K8s token. Kubelet, actual pod boot and CNI enforcement require staging.
