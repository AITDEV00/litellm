# Delta from 0272b20765b

The supplied implementation is the jya0-v1.108.5 export at 0272b20765b6c63a439a4f364a8e06468d39f479. The older research-reference/mcp-ingress-stack is a separate, single-node prototype. The attached Go transport suite passes. It does not exercise the combined Python-and-Go failure modes below.

| Existing code | Recommended change |
|---|---|
| gateway.py default_registration, native create/update functions and manager reload | Keep the existing registration ownership and collision behavior. Inject the reviewed URL, transport, spec path and grants. Use one stock row per backend. |
| remote_store.py create_peer/config/install | Split agent identity and credential epoch from the per-channel assignment. Keep durable revisions and tombstones. Replace install URLs carrying credentials and generated scripts with static signed artifacts and mounted secrets. |
| remote_gateway.py lifecycle and invalidate_local_adapter | Return committed desired revision plus apply status. Remove the mandatory synchronous close chain. Current code commits before returning a possible HTTP 503. Drain, revoke and recover all trigger the same immediate-close path. |
| remote_store.py report and lifecycle | Use one CAS or locked SQL transition. Report checks generation before the transaction, ignores the worker update's affected row count, and can update the parent on a stale observation. Fence worker and dependent updates on generation, current phase and catalog revision. |
| mcp-remotedialer main.go shutdown and runtime.go remove | Collect sessions under the lock, then close outside it. Exported shutdown holds runtime.mu while member.close invokes a callback that reacquires it. |
| mcp-remotedialer config.go, probe.go and pool.go | Replace single source/target workers with per-agent channels. Keep origin proof and header boundaries. Move spec projection to the adapter. The current 9092 handler rejects Mcp-Session-Id despite listing it among pass-through headers. |
| Duplicate listeners and transport switches | Keep the private 9092 projection or use a temporary staging port. Reuse the internal controller for a read feed. Remove the loopback notification chain and avoid exposing 9091 in the Service. Keep Chisel and its 8088/8089/9090 paths only while old registrations need migration rollback. |

The reference introduces a reusable channel library and private HTTP projection. It adds no MCP manager, virtual server product, user-key management or raw TCP forwarding interface. The private controller can inject the SQL projection into the existing control app. The supplied demo database table is an example and should not replace current source persistence.

**Rollout order.** Validate a new staged connector and alias. Add agent grants and channel assignments to the existing DB control path. Move one OpenAPI row with the existing update method. Then create the native MCP row and share the access group. Roll back an existing compatible row by restoring its old URL and control settings. Legacy OpenAPI/Chisel routing cannot preserve a native MCP session during failover.
