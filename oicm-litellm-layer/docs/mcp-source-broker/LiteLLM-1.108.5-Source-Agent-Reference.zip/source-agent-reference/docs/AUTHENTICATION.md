# Identity, configuration and source alteration

| Material | Owner and lifecycle |
|---|---|
| Agent ID, gateway URL and trust anchor | Nonsecret identity configuration. The stable ID stays when the process restarts, the pod is replaced or credentials rotate. |
| Agent token and epoch | Owner-protected file or Secret volume. The relay grant holds the token SHA-256 digest. Rotation reloads on heartbeat and reconnects. |
| Requested target set | Versioned AgentState, no credentials. Local operators can select approved descriptors. The relay still requires independent authorization and origin proof. |
| Descriptor and catalog digests | The descriptor binds the origin socket or Service identity, operation boundary, TLS name and capacity. Catalog changes advance the channel revision independently. |
| Origin signing key | Held by the origin owner, with public verification key in approval. Ed25519 binds a fresh nonce, agent ID, target ID and catalog digest. |
| Service credentials | Separate local control token, Kubernetes API token, feed token and LiteLLM-to-broker token. The relay drops Authorization, Cookie, X-Api-Key and the broker key before origin I/O. |

For regeneration use the credential subcommand with the next epoch and a new path. It writes the token to an owner-only file and outputs only a digest. Commit that digest under the previous ID, then atomically replace the credential file or Secret. Re-provision a wiped host from the same nonsecret configuration. The example uses existing protected secret delivery. It needs no bootstrap token in a URL, process list, environment or rendered installer.

A signature attests what the origin owner says is the active release. It does not prove dataset equivalence. A replica pool needs proof tied to the actual serving workload, tenant and credential scope, dataset ID, lineage or consistency epoch, contract digest, and lag or revision when relevant. Use an audience-specific nonce, a trusted issuer and verified service identity on the serving path. Preserve session ownership and replay policy. This reference does not pool across agents.

Descriptor matching catches ordinary target edits. Kubernetes also checks the named Service's UID, consent annotation, ClusterIP, named TCP port and CIDR. Control Service selectors, workload and signer through operator RBAC. The relay can open a stream to the approved origin socket. Dedicate that socket to the service. The proof covers the periodic probe, while the identity of each serving connection depends on the approved TLS identity and host controls. A fully compromised forwarding host can split plaintext proof and traffic. Use independently managed origin keys and verified HTTPS to the serving workload when the host or network is untrusted. Tool argument filtering and secret leakage through application data remain LiteLLM/app concerns.

Expose databases through a fixed contract such as read_report(record_id) with a server-configured tenant and a bounded query. The adapter can select from a scoped read-only view with query timeouts and parameters, for example SELECT value FROM reports_view WHERE tenant_id = $1 AND report_id = $2. SQL text, database host, and authorization stay in the application. There is no SQL parameter taking a query or raw DB route.
