# Architecture

Keep **one stable LiteLLM registration per independently owned backend**. Ten endpoints on one site can share a connector and a LiteLLM access group. Give each registration an alias, schema, tool allowlist and policy. Group grants carry the union of included servers. Grant individual registrations where audiences differ. Consumers can still use LiteLLM's aggregate /mcp endpoint, which namespaces tool names by server. [LiteLLM MCP access](https://docs.litellm.ai/docs/proxy/access_management/mcp) · [MCP configuration](https://docs.litellm.ai/docs/mcp_config_reference)

~~~mermaid
flowchart LR
  U["Caller"] --> L["LiteLLM MCP"]
  L -->|"Private HTTP"| R["Relay"]
  A["Source agent"] -->|"Opens one WSS"| R
  A --> O["Approved origins"]
  P["Operator approvals"] -->|"Versioned snapshot"| R
~~~

1. The source agent authenticates once. One control stream on that socket reports locally enabled and resolved target IDs and descriptor digests.
2. The relay compares the reported targets to approved descriptors and verifies the origin's current catalog proof. An ordinary HTTP call to one private channel opens an independent mux stream to that origin.
3. LiteLLM runs its existing OpenAPI-generated handler or native MCP SDK client. It owns discovery, capabilities, tool calls, pinning, guardrails and spend logs. The agent never registers a backend on its own.
4. The origin owns data and business behavior. Keep application permissions and side-effect policy in its existing authorization path or a reviewed adapter.

The relay has no SQL, model provider or tool logic. The PostgreSQL projection is an example of the read boundary the existing controller can provide. It fences agent credentials and channel approvals independently. The transport does not cache tool results. Discovery caching and pinned tools stay in LiteLLM. A later data cache needs explicit tenant, credential scope, method and freshness keys.

[Read the branch delta](WHY-DELTA.md)
