# Data plane

The connector initiates TLS to the approved /mcp-source-agent route. This works where the firewall permits only source-initiated connections and permits full-duplex bytes on the established connection. A physical one-way link cannot carry WSS. Caddy forwards the upgrade to the relay. The wire uses coder/websocket **v1.8.15** and libp2p yamux **v5.1.0**. Yamux owns stream framing, flow control, half-close, keepalive and reset. The application adds bounded metadata frames and a one-byte admission acknowledgment. [WebSocket RFC](https://www.rfc-editor.org/rfc/rfc6455.html) · [yamux API](https://pkg.go.dev/github.com/libp2p/go-yamux/v5@v5.1.0) · [WebSocket API](https://pkg.go.dev/github.com/coder/websocket@v1.8.15)

| Boundary | Behavior |
|---|---|
| WebSocket | One per agent ID, verified TLS, exact subprotocol, one control stream initiated by the agent, 1 MiB WebSocket message limit. |
| Service | Up to 16 descriptors, each 1–8 HTTP slots plus one origin probe slot. A saturated target returns 503 before dispatch. The agent waits at most 300 ms for a previous bridge to release a slot after the relay admits a call. Long-lived legacy GET consumes one slot. |
| Streams | At most 160 incoming streams on the agent; flow-control window does not grow above the mux initial window, and outbound data frames are at most 64 KiB. |
| HTTP | Header limits, 2 MiB request cap, 16 MiB streamed response cap, 15 s response headers and 2 min total. If a chunked response grows past the cap after headers, the relay aborts that response. Explicit single endpoint or path prefix. No redirect, upgrade, CONNECT or raw TCP route. |
| Cancellation | Target revoke resets only its streams. Closing the socket cuts all streams. The unit test verifies TCP half-close and a sibling stream progressing while the first is waiting on FIN. |
| Retry behavior | One forwarding attempt per HTTP request; outbound keepalive is disabled. Any SDK resume or initialization is its own policy. |
| Health | Per-target probe with 1.5 s request budget, roughly one-second cadence, and a four-second success horizon. A wrong proof removes target eligibility independently. |

One socket saves per-service handshakes and makes a site's credential updates simpler. One-per-service connectors cost more sockets, configuration and reconnects and offer stronger transport and credential isolation. Use distinct agents for independent trust domains or workloads sensitive to shared TCP loss. Per-target quotas bound concurrent work. They give no strict byte latency guarantee under congestion.

## Native MCP

The existing LiteLLM client connects to one fixed native origin. Legacy Streamable HTTP keeps GET, POST, DELETE and Mcp-Session-Id on the approved endpoint. The relay allows session IDs issued on the same live connection and channel approval, with 256 slots and 30-minute idle expiry. A lost attachment or a replaced approval makes old IDs return HTTP 404. The SDK can initialize a new session. The origin owns application state and clears it after DELETE or its own timeout. Draining allows admitted HTTP requests to finish and stops new requests, including calls using an existing ID.

The **2026-07-28** revision removed protocol-level sessions and the separate GET event stream. This eases migration for those callers. It does not make writes replay-safe. The reference tests both the modern and 2025-11-25 initialize modes with official SDK 2.3.0. SSE within a request is streamed. Deprecated 2024-11-05 two-endpoint SSE, arbitrary application metadata headers such as Mcp-Param-*, upstream BYOK/OAuth, and HA native affinity are outside this pilot. [2026-07-28 Streamable HTTP](https://modelcontextprotocol.io/specification/2026-07-28/basic/transports/streamable-http) · [2025-11-25 transport](https://modelcontextprotocol.io/specification/2025-11-25/basic/transports)

Canonical OpenAPI and tool schema checks belong to source release and the existing LiteLLM integration. The injected reconcile.Probe consumes a descriptor, expected catalog digest and narrow Dial. The mux sees only opaque channel IDs and digests. The enclosed OpenAPI projection tool turns approved path prefixes into broker-relative paths and rejects remote schema references and server overrides.
