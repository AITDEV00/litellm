# Test evidence and pins

The logs in this directory are emitted by executable assertions. They contain fixture labels and aggregate timing, with credentials and session IDs omitted.

| Evidence | Run from the top-level directory |
|---|---|
| unit.log | `make unit`. Includes Go vet and the race detector. |
| behavior.log | `make behavior`. Two services, TUI and lifecycle using official SDK clients. |
| litellm_e2e.log | `make e2e`. PostgreSQL, real LiteLLM registry and HTTP APIs, tool calls, feed failure and recovery. |
| kubernetes-api.log | `make kube`. Requires the pinned Kubernetes assets and Linux unprivileged network namespaces. |
| artifacts.log | `make artifacts`. Checks the bundled release and downloads through Caddy. |
| frp.log | `python3 tests/fetch.py frp`, then `make compare-frp`. Tests frp separately from the reference data plane. |
| benchmark.jsonl | `make bench`. Nine runs across one, two and ten targets. |
| manifests.log | `caddy adapt --validate --config examples/Caddyfile --adapter caddyfile`. The Kubernetes test validates rendered resources against the actual API. |

The recorded E2E run used the pinned upstream LiteLLM tag checkout and its Prisma schema. To repeat from that checkout, set PYTHONPATH to its directory and LITELLM_SCHEMA to its schema.prisma. Alternatively use the locked wheel as described in the [build steps](../README.md). Use a Python 3.12 venv with its bin on PATH so the generated Prisma command resolves. PG_BIN may point to a verified PostgreSQL 18.6 bin directory. The tests allocate temporary ports/files and launch disposable controllers and origins.

| Input | Version or digest |
|---|---|
| Private export revision | 0272b20765b6c63a439a4f364a8e06468d39f479 |
| Input ZIP SHA-256 | 269032c8c09ee5028cd2d5d6c106ad2260a2bef0eec5c17f4abf7adc1af1c431 |
| Public LiteLLM checkout | v1.108.5 LTS · 2a61f2114d45016bae77930903e65172cd8e762c |
| Go | 1.27.4 · Linux amd64, static executable, CGO disabled |
| Python | 3.12.14 · exact package pins in tests/requirements.lock.txt |
| Origin libraries | FastAPI 0.162.5 and official MCP SDK 2.3.0 |
| Database | PostgreSQL 18.6 and Prisma client 0.11.0 |
| Ingress | Caddy 2.11.9 |
| Kubernetes API | Kubernetes 1.35.0 and etcd 3.6.6 from the envtest archive |
| Signing and verification | OpenSSL 3.5.7, Ed25519 and SHA-256 |
| Stock comparison | frp 0.72.0 |

The exact Go modules and sums are under source-agent/go.mod and go.sum. The fetch script contains HTTPS URLs and SHA-256 pins for upstream executable archives. The signed binary and container digests are in bin/release.json. The signed release is buildable from the source in this archive. [Verification instructions](../docs/UPGRADE.md)
