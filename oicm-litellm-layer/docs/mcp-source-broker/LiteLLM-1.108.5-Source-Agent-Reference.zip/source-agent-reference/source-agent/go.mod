module example.org/litellm/source-agent

go 1.27.4

require (
	github.com/coder/websocket v1.8.15
	github.com/libp2p/go-yamux/v5 v5.1.0
	go.yaml.in/yaml/v3 v3.0.4
)

require github.com/libp2p/go-buffer-pool v0.0.2 // indirect
