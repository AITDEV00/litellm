package adapters

import (
	"crypto/ed25519"
	"crypto/rand"
	"encoding/base64"
	"testing"
)

func TestOriginProofIsBoundToNonceAndChannel(t *testing.T) {
	public, private, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	key := base64.StdEncoding.EncodeToString(public)
	proof := base64.StdEncoding.EncodeToString(ed25519.Sign(private, ProofMessage("nonce", "site-one", "docs", "approved")))
	if !VerifyProof(key, proof, "nonce", "site-one", "docs", "approved") {
		t.Fatal("invalidated authentic proof")
	}
	for _, input := range [][4]string{{"old", "site-one", "docs", "approved"}, {"nonce", "site-two", "docs", "approved"},
		{"nonce", "site-one", "tools", "approved"}, {"nonce", "site-one", "docs", "changed"}} {
		if VerifyProof(key, proof, input[0], input[1], input[2], input[3]) {
			t.Fatal("accepted altered proof")
		}
	}
}
