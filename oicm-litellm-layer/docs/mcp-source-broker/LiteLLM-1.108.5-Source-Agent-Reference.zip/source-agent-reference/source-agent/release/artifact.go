package release

import (
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"runtime"
	"strings"
)

type Manifest struct {
	Version string `json:"version"`
	OS      string `json:"os"`
	Arch    string `json:"arch"`
	SHA256  string `json:"sha256"`
}

func Verify(binary, manifest, signature, public string) (Manifest, error) {
	var m Manifest
	data, err := os.ReadFile(manifest)
	if err != nil || len(data) > 4096 {
		return m, errors.New("release manifest unavailable")
	}
	sig, err := decodeFile(signature, ed25519.SignatureSize)
	if err != nil {
		return m, err
	}
	key, err := decodeFile(public, ed25519.PublicKeySize)
	if err != nil {
		return m, err
	}
	if !ed25519.Verify(ed25519.PublicKey(key), data, sig) {
		return m, errors.New("release manifest signature mismatch")
	}
	if err := json.Unmarshal(data, &m); err != nil || m.Version == "" || m.OS != runtime.GOOS || m.Arch != runtime.GOARCH {
		return m, errors.New("release does not match this platform")
	}
	file, err := os.Open(binary)
	if err != nil {
		return m, err
	}
	defer file.Close()
	sum := sha256.New()
	if _, err = io.Copy(sum, file); err != nil {
		return m, err
	}
	if fmt.Sprintf("%x", sum.Sum(nil)) != m.SHA256 {
		return m, errors.New("release binary digest mismatch")
	}
	return m, nil
}

func decodeFile(path string, size int) ([]byte, error) {
	data, err := os.ReadFile(path)
	if err != nil || len(data) > 512 {
		return nil, errors.New("release signature or trust key unavailable")
	}
	decoded, err := base64.StdEncoding.DecodeString(strings.TrimSpace(string(data)))
	if err != nil || len(decoded) != size {
		return nil, errors.New("invalid release signature or trust key")
	}
	return decoded, nil
}
