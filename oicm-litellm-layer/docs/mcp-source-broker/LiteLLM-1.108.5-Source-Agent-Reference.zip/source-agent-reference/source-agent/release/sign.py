"""Sign the exact binary checksum and OCI digest with an offline Ed25519 key."""
import argparse
import base64
import hashlib
import json
import subprocess
from pathlib import Path


def sign(binary, output, key, image_digest):
    output.mkdir(parents=True, exist_ok=True)
    with binary.open("rb") as data:
        digest = hashlib.file_digest(data, "sha256").hexdigest()
    manifest = output / "release.json"
    manifest.write_text(json.dumps({"version": "0.1.0", "os": "linux", "arch": "amd64", "sha256": digest,
                                    "oci_manifest_digest": image_digest}, sort_keys=True) + "\n")
    signature = subprocess.run(["openssl", "pkeyutl", "-sign", "-rawin", "-inkey", key, "-in", manifest],
                               check=True, capture_output=True).stdout
    (output / "release.sig.b64").write_bytes(base64.b64encode(signature) + b"\n")
    key_der = subprocess.run(["openssl", "pkey", "-in", key, "-pubout", "-outform", "DER"],
                             check=True, capture_output=True).stdout
    # RFC 8410 SubjectPublicKeyInfo for Ed25519.
    if len(key_der) != 44 or not key_der.startswith(bytes.fromhex("302a300506032b6570032100")):
        raise ValueError("expected an Ed25519 key")
    (output / "release-public.b64").write_bytes(base64.b64encode(key_der[-32:]) + b"\n")
    (output / "release-public.pem").write_bytes(subprocess.run(
        ["openssl", "pkey", "-in", key, "-pubout"], check=True, capture_output=True).stdout)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("binary", type=Path)
    parser.add_argument("out", type=Path)
    parser.add_argument("--key", required=True, type=Path)
    parser.add_argument("--image-digest", required=True)
    args = parser.parse_args()
    sign(args.binary, args.out, args.key, args.image_digest)
