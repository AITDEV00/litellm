"""Reproducibly package the static binary as a Linux amd64 OCI image."""
import argparse
import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path


def as_json(data):
    return json.dumps(data, separators=(",", ":"), sort_keys=True).encode()


def checksum(data):
    return "sha256:" + hashlib.sha256(data).hexdigest()


def item(data, media):
    return {"digest": checksum(data), "size": len(data), "mediaType": media}


def put(archive, filename, data, mode=0o644, uid=0):
    entry = tarfile.TarInfo(filename)
    entry.size, entry.mode, entry.uid, entry.gid = len(data), mode, uid, uid
    archive.addfile(entry, io.BytesIO(data))


def build(binary, output):
    raw_layer = io.BytesIO()
    with tarfile.open(fileobj=raw_layer, mode="w", format=tarfile.USTAR_FORMAT) as archive:
        put(archive, "source-agent", binary.read_bytes(), mode=0o755, uid=10001)
    uncompressed = raw_layer.getvalue()
    layer = gzip.compress(uncompressed, compresslevel=6, mtime=0)
    layer_info = item(layer, "application/vnd.oci.image.layer.v1.tar+gzip")
    config = as_json({"architecture": "amd64", "os": "linux", "config": {"User": "10001:10001",
                             "Entrypoint": ["/source-agent"]},
                      "rootfs": {"type": "layers", "diff_ids": [checksum(uncompressed)]}})
    cfg_info = item(config, "application/vnd.oci.image.config.v1+json")
    manifest = as_json({"schemaVersion": 2, "mediaType": "application/vnd.oci.image.manifest.v1+json",
                        "config": cfg_info, "layers": [layer_info]})
    manifest_info = item(manifest, "application/vnd.oci.image.manifest.v1+json")
    manifest_info["annotations"] = {"org.opencontainers.image.ref.name": "0.1.0"}
    with tarfile.open(output, "w", format=tarfile.USTAR_FORMAT) as oci:
        put(oci, "oci-layout", as_json({"imageLayoutVersion": "1.0.0"}))
        put(oci, "index.json", as_json({"schemaVersion": 2, "manifests": [manifest_info]}))
        for data in (manifest, config, layer):
            put(oci, "blobs/sha256/" + checksum(data).split(":")[1], data)
    return manifest_info["digest"]


if __name__ == "__main__":
    args = argparse.ArgumentParser(description=__doc__)
    args.add_argument("binary", type=Path)
    args.add_argument("output", type=Path)
    flags = args.parse_args()
    print(build(flags.binary, flags.output))
