package main

import (
	"context"
	"crypto/rand"
	"encoding/base64"
	"encoding/json"
	"errors"
	"flag"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	"example.org/litellm/source-agent/adapters"
	"example.org/litellm/source-agent/cli"
	"example.org/litellm/source-agent/reconcile"
	"example.org/litellm/source-agent/release"
	"example.org/litellm/source-agent/target"
)

func main() {
	ctx, done := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer done()
	if len(os.Args) < 2 {
		log.Fatal("usage: source-agent run|relay|status|apply|tui|credential|descriptors|validate-policy|verify")
	}
	if err := run(ctx, os.Args[1], os.Args[2:]); err != nil {
		log.Print(err)
		os.Exit(1)
	}
}

func run(ctx context.Context, command string, args []string) error {
	fs := flag.NewFlagSet(command, flag.ContinueOnError)
	switch command {
	case "run":
		return agentMode(ctx, fs, args)
	case "relay":
		return relayMode(ctx, fs, args)
	case "status", "apply", "tui":
		base := fs.String("url", "http://127.0.0.1:19091", "local control URL")
		key := fs.String("token-file", "", "local control token file")
		enabled := fs.String("enabled", "", "comma-separated exact allowlist selection")
		revision := fs.Uint64("expect", 0, "expected revision")
		if err := fs.Parse(args); err != nil {
			return err
		}
		token, err := reconcile.Secret(*key)
		if err != nil {
			return err
		}
		c := cli.Client{Base: *base, Token: token}
		if command == "tui" {
			return c.TUI(os.Stdin, os.Stdout)
		}
		if command == "apply" {
			var ids []string
			if *enabled != "" {
				ids = strings.Split(*enabled, ",")
			}
			next, err := c.Apply(cli.Change{Expect: *revision, Enabled: ids})
			return printJSON(next, err)
		}
		s, err := c.Status()
		return printJSON(s, err)
	case "credential":
		file := fs.String("out", "", "new credential file path")
		epoch := fs.Uint64("epoch", 0, "new credential epoch")
		if err := fs.Parse(args); err != nil {
			return err
		}
		if *file == "" || *epoch == 0 {
			return errors.New("credential requires output path and epoch")
		}
		if _, err := os.Lstat(*file); !errors.Is(err, os.ErrNotExist) {
			return errors.New("write credentials to a new file")
		}
		raw := make([]byte, 32)
		if _, err := rand.Read(raw); err != nil {
			return err
		}
		token := base64.RawURLEncoding.EncodeToString(raw)
		if err := reconcile.Atomic(*file, reconcile.Credential{Epoch: *epoch, Token: token}); err != nil {
			return err
		}
		return printJSON(map[string]any{"epoch": *epoch, "credential_sha256": reconcile.Hash(token)}, nil)
	case "descriptors":
		file := fs.String("policy", "", "target policy filename")
		if err := fs.Parse(args); err != nil {
			return err
		}
		var p reconcile.Policy
		if err := reconcile.File(*file, &p, false); err != nil {
			return err
		}
		m, err := reconcile.LoadPolicy(p)
		if err != nil {
			return err
		}
		out := make(map[string]string)
		for id, d := range m {
			out[id] = d.Fingerprint()
		}
		return printJSON(out, nil)
	case "validate-policy":
		if len(args) != 0 {
			return errors.New("read a previous/candidate policy envelope from standard input")
		}
		const maxEnvelope = 2*reconcile.MaxConfig + 64
		data, err := io.ReadAll(io.LimitReader(os.Stdin, maxEnvelope+1))
		if err != nil || len(data) > maxEnvelope {
			return errors.New("policy envelope exceeds limit")
		}
		var change struct {
			Previous  reconcile.Snapshot `json:"previous"`
			Candidate reconcile.Snapshot `json:"candidate"`
		}
		if err := reconcile.DecodeJSON(data, &change); err != nil {
			return err
		}
		return reconcile.ValidatePolicy(change.Previous, change.Candidate)
	case "verify":
		bin := fs.String("binary", "", "binary to verify")
		m := fs.String("manifest", "", "signed JSON manifest")
		sig := fs.String("signature", "", "detached signature")
		pub := fs.String("trust-key", "", "trusted Ed25519 public key")
		if err := fs.Parse(args); err != nil {
			return err
		}
		matches, err := release.Verify(*bin, *m, *sig, *pub)
		return printJSON(matches, err)
	default:
		return errors.New("unknown source-agent command")
	}
}

func printJSON(value any, err error) error {
	if err != nil {
		return err
	}
	return json.NewEncoder(os.Stdout).Encode(value)
}

func agentMode(ctx context.Context, fs *flag.FlagSet, args []string) error {
	identity := fs.String("identity", "", "identity file")
	credential := fs.String("credential", "", "credential file")
	state := fs.String("state", "", "desired state file")
	policy := fs.String("policy", "", "target allowlist file")
	readOnly := fs.Bool("read-only", false, "read desired state from a mounted configuration")
	controlAddr := fs.String("control", "127.0.0.1:19091", "local control address")
	controlKey := fs.String("control-token", "", "local HTTP control token file; empty disables listener")
	kubeAPI := fs.String("kube-api", "", "Kubernetes HTTPS origin")
	kubeNamespace := fs.String("kube-namespace", "", "Kubernetes namespace")
	kubeToken := fs.String("kube-token", "", "projected Kubernetes token")
	kubeCA := fs.String("kube-ca", "", "trusted Kubernetes API CA")
	if err := fs.Parse(args); err != nil {
		return err
	}
	if !loopback(*controlAddr) {
		return errors.New("agent control must bind numeric loopback")
	}
	a := &reconcile.Agent{Credentials: *credential, StateFile: *state, PolicyFile: *policy, ReadOnly: *readOnly}
	if err := reconcile.File(*identity, &a.Identity, false); err != nil {
		return err
	}
	if *kubeToken != "" {
		if *kubeAPI == "" {
			*kubeAPI = reconcile.Endpoint(os.Getenv("KUBERNETES_SERVICE_HOST"), os.Getenv("KUBERNETES_SERVICE_PORT_HTTPS"))
		}
		client, err := reconcile.TLSClient(*kubeCA, 1500*time.Millisecond)
		if err != nil {
			return err
		}
		a.Kube = &target.Kubernetes{API: *kubeAPI, TokenFile: *kubeToken, Namespace: *kubeNamespace, HTTP: client}
	}
	var endpoints []*http.Server
	if *controlKey != "" {
		secret, err := reconcile.Secret(*controlKey)
		if err != nil {
			return err
		}
		endpoints = append(endpoints, server(*controlAddr, cli.Control(a, secret)))
	}
	if err := a.Start(ctx); err != nil {
		return err
	}
	return serve(ctx, endpoints...)
}

func relayMode(ctx context.Context, fs *flag.FlagSet, args []string) error {
	file := fs.String("policy", "", "private local desired snapshot")
	feedURL := fs.String("feed", "", "private desired snapshot endpoint")
	feedSecret := fs.String("feed-token", "", "feed credential")
	feedCA := fs.String("feed-ca", "", "feed CA")
	worker := fs.String("worker", "127.0.0.1:8092", "worker listener behind approved HTTPS")
	path := fs.String("worker-path", "/mcp-source-agent", "HTTPS worker path")
	data := fs.String("data", "127.0.0.1:9092", "private data listener")
	dataKey := fs.String("data-token", "", "private LiteLLM-to-broker credential")
	originCA := fs.String("origin-ca", "", "upstream CA for approved HTTPS origins")
	if err := fs.Parse(args); err != nil {
		return err
	}
	if !target.Path(*path) || (*file == "") == (*feedURL == "") {
		return errors.New("specify one authority feed and an exact worker path")
	}
	key, err := reconcile.Secret(*dataKey)
	if err != nil {
		return err
	}
	feed := reconcile.FileFeed(*file)
	if *feedURL != "" {
		token, err := reconcile.Secret(*feedSecret)
		if err != nil {
			return err
		}
		feed, err = reconcile.HTTPFeed(*feedURL, token, *feedCA)
		if err != nil || token == key {
			return errors.New("invalid authority feed or reused credential")
		}
	}
	tlsClient, err := reconcile.TLSClient(*originCA, 0)
	if err != nil {
		return err
	}
	relay := reconcile.NewRelay(feed, adapters.CatalogProbe(tlsClient))
	public := http.NewServeMux()
	public.HandleFunc("GET "+*path, relay.Attach)
	private := http.NewServeMux()
	private.HandleFunc("GET /v1/observed", func(w http.ResponseWriter, r *http.Request) {
		if !reconcile.Matches(reconcile.Hash(key), r.Header.Get("X-Source-Broker-Key")) {
			http.Error(w, "unauthorized", http.StatusUnauthorized)
			return
		}
		cli.JSON(w, 200, relay.Status())
	})
	private.HandleFunc("GET /readyz", func(w http.ResponseWriter, r *http.Request) {
		if !relay.Status().Fresh {
			w.WriteHeader(503)
			return
		}
		w.WriteHeader(204)
	})
	private.Handle("/sources/", adapters.HTTP{Relay: relay, KeyHash: reconcile.Hash(key), TLS: tlsClient})
	go relay.Run(ctx)
	dataServer := server(*data, private)
	dataServer.ReadTimeout = adapters.RequestTimeout
	dataServer.WriteTimeout = adapters.RequestTimeout + 5*time.Second
	return serve(ctx, server(*worker, public), dataServer)
}

func loopback(address string) bool {
	host, _, err := net.SplitHostPort(address)
	return err == nil && net.ParseIP(host).IsLoopback()
}

func server(addr string, handler http.Handler) *http.Server {
	return &http.Server{Addr: addr, Handler: handler, ReadHeaderTimeout: 4 * time.Second,
		IdleTimeout: 30 * time.Second, MaxHeaderBytes: 32 << 10}
}

func serve(ctx context.Context, servers ...*http.Server) error {
	errs := make(chan error, len(servers))
	var listeners []net.Listener
	defer func() {
		for _, l := range listeners {
			l.Close()
		}
		for _, s := range servers {
			s.Close()
		}
	}()
	for _, s := range servers {
		l, err := net.Listen("tcp", s.Addr)
		if err != nil {
			return err
		}
		listeners = append(listeners, l)
	}
	for i, l := range listeners {
		go func() { errs <- servers[i].Serve(l) }()
	}
	select {
	case <-ctx.Done():
		return nil
	case err := <-errs:
		return err
	}
}
