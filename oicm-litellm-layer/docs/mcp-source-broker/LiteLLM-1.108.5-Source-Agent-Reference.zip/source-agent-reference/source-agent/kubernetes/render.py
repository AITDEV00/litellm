#!/usr/bin/env python3
import argparse
import ipaddress
import re
from pathlib import Path
from string import Template


root = Path(__file__).resolve().parent


def render(image, gateway, api, api_port):
    if not re.fullmatch(r"[a-zA-Z0-9./:_-]+@sha256:[a-f0-9]{64}", image):
        raise ValueError("use an immutable OCI image reference with SHA-256 digest")
    for address in (gateway, api):
        network = ipaddress.ip_network(address)
        if network.num_addresses != 1 or network.is_link_local:
            raise ValueError("ingress and API exemptions must each name one address")
    if not 1 <= api_port <= 65535:
        raise ValueError("invalid API port")
    values = {"SOURCE_AGENT_IMAGE": image, "GATEWAY_CIDR": gateway, "APISERVER_CIDR": api,
              "APISERVER_PORT": api_port}
    for template in ("agent.yaml.in", "network-policy.yaml.in"):
        print("---")
        print(Template((root / template).read_text()).substitute(values), end="")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--image", required=True)
    parser.add_argument("--gateway-ip", required=True)
    parser.add_argument("--apiserver-ip", required=True)
    parser.add_argument("--apiserver-port", type=int, default=443)
    args = parser.parse_args()
    def cidr(value):
        return str(ipaddress.ip_network(value))
    render(args.image, cidr(args.gateway_ip), cidr(args.apiserver_ip), args.apiserver_port)
