package cli

import (
	"bufio"
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"slices"
	"strconv"
	"strings"
	"time"

	"example.org/litellm/source-agent/reconcile"
)

type Change struct {
	Expect  uint64   `json:"expected_revision"`
	Enabled []string `json:"enabled"`
}

func JSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}

func Control(agent *reconcile.Agent, token string) http.Handler {
	hash := reconcile.Hash(token)
	router := http.NewServeMux()
	router.HandleFunc("GET /v1/status", func(w http.ResponseWriter, r *http.Request) {
		JSON(w, 200, agent.Status())
	})
	router.HandleFunc("GET /v1/desired", func(w http.ResponseWriter, r *http.Request) {
		JSON(w, 200, agent.Status().Desired)
	})
	router.HandleFunc("PUT /v1/desired", func(w http.ResponseWriter, r *http.Request) {
		var change Change
		dec := json.NewDecoder(http.MaxBytesReader(w, r.Body, 4096))
		dec.DisallowUnknownFields()
		if dec.Decode(&change) != nil || dec.Decode(new(any)) != io.EOF {
			http.Error(w, "invalid change", 400)
			return
		}
		next, err := agent.Apply(change.Expect, change.Enabled)
		switch {
		case errors.Is(err, reconcile.ErrConflict):
			http.Error(w, "revision conflict; reload desired state", 409)
		case errors.Is(err, reconcile.ErrReadOnly):
			http.Error(w, "edit the mounted ConfigMap", 405)
		case err != nil:
			http.Error(w, "desired state not applied", 422)
		default:
			JSON(w, 200, next)
		}
	})
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !reconcile.Matches(hash, reconcile.Auth(r)) {
			http.Error(w, "unauthorized", 401)
			return
		}
		router.ServeHTTP(w, r)
	})
}

type Client struct {
	Base  string
	Token string
}

func (c Client) request(method, path string, body any, target any) error {
	u, err := url.Parse(c.Base)
	if err != nil || u.Scheme != "http" || !net.ParseIP(u.Hostname()).IsLoopback() ||
		u.User != nil || u.Path != "" || u.RawQuery != "" || u.Fragment != "" {
		return errors.New("control URL must use a numeric HTTP loopback address")
	}
	u.Path = path
	encoded, err := json.Marshal(body)
	if err != nil {
		return err
	}
	req, err := http.NewRequest(method, u.String(), bytes.NewReader(encoded))
	if err != nil {
		return err
	}
	req.Header.Set("Authorization", "Bearer "+c.Token)
	req.Header.Set("Content-Type", "application/json")
	client := http.Client{Timeout: 5 * time.Second, Transport: &http.Transport{Proxy: nil},
		CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}
	defer client.CloseIdleConnections()
	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		b, _ := io.ReadAll(io.LimitReader(resp.Body, 200))
		return fmt.Errorf("control HTTP %d: %s", resp.StatusCode, strings.TrimSpace(string(b)))
	}
	return json.NewDecoder(io.LimitReader(resp.Body, 64<<10)).Decode(target)
}

func (c Client) Status() (reconcile.Status, error) {
	var state reconcile.Status
	err := c.request("GET", "/v1/status", nil, &state)
	return state, err
}

func (c Client) Apply(change Change) (reconcile.State, error) {
	var state reconcile.State
	err := c.request("PUT", "/v1/desired", change, &state)
	return state, err
}

func Toggle(s reconcile.State, id string, enable bool) Change {
	result := slices.Clone(s.Enabled)
	contained := slices.Contains(result, id)
	if enable && !contained {
		result = append(result, id)
	}
	if !enable && contained {
		result = slices.DeleteFunc(result, func(key string) bool { return key == id })
	}
	return Change{Expect: s.Revision, Enabled: result}
}

// TUI deliberately uses the same CAS endpoints as the batch CLI.
func (c Client) TUI(input io.Reader, output io.Writer) error {
	scanner := bufio.NewScanner(input)
	for {
		status, err := c.Status()
		if err != nil {
			return err
		}
		fmt.Fprintf(output, "\nSource agent | local revision %d | broker revision %d | connected %t\n",
			status.Desired.Revision, status.PolicyRevision, status.Connected)
		for i, id := range status.Allowed {
			state := "disabled"
			if slices.Contains(status.Desired.Enabled, id) {
				state = "waiting_for_relay"
			}
			if reason := status.Problems[id]; reason != "" {
				state = reason
			}
			for _, observed := range status.Observations {
				if observed.ID == id {
					state = fmt.Sprintf("%s ready=%t in-flight=%d %s", observed.Phase,
						observed.Ready, observed.InFlight, observed.Problem)
				}
			}
			fmt.Fprintf(output, "%2d. %-18s %s\n", i+1, id, state)
		}
		fmt.Fprint(output, "Number to toggle, Enter to refresh, q to quit: ")
		if !scanner.Scan() || scanner.Text() == "q" {
			return scanner.Err()
		}
		index, err := strconv.Atoi(scanner.Text())
		if err != nil || index < 1 || index > len(status.Allowed) {
			continue
		}
		id := status.Allowed[index-1]
		if _, err := c.Apply(Toggle(status.Desired, id, !slices.Contains(status.Desired.Enabled, id))); err != nil {
			fmt.Fprintln(output, err)
		}
	}
}
