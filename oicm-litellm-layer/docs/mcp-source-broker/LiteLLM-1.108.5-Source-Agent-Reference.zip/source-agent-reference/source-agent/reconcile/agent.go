package reconcile

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"errors"
	"fmt"
	"net"
	"net/http"
	"net/url"
	"os"
	"reflect"
	"slices"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"example.org/litellm/source-agent/target"
	"example.org/litellm/source-agent/transport"
	yamux "github.com/libp2p/go-yamux/v5"
)

type Agent struct {
	Identity    Identity
	Credentials string
	StateFile   string
	PolicyFile  string
	ReadOnly    bool
	Kube        *target.Kubernetes

	mu          sync.Mutex
	state       State
	allowed     map[string]target.Descriptor
	resolved    map[string]*route
	seen        map[string]string
	remote      transport.Reply
	connected   bool
	fileError   string
	attachError string
}

type route struct {
	descriptor target.Descriptor
	address    string
	ctx        context.Context
	cancel     context.CancelFunc
	slots      chan struct{}
}

type Status struct {
	Desired        State                   `json:"desired"`
	Allowed        []string                `json:"allowlisted"`
	Observations   []transport.Observation `json:"observed"`
	PolicyRevision uint64                  `json:"relay_revision"`
	Connected      bool                    `json:"connected"`
	Problems       map[string]string       `json:"problems,omitempty"`
	FileError      string                  `json:"config_error,omitempty"`
	AttachError    string                  `json:"connection_error,omitempty"`
}

func TLSClient(ca string, timeout time.Duration) (*http.Client, error) {
	cfg := &tls.Config{MinVersion: tls.VersionTLS12}
	if ca != "" {
		pem, err := os.ReadFile(ca)
		if err != nil {
			return nil, err
		}
		root := x509.NewCertPool()
		if !root.AppendCertsFromPEM(pem) {
			return nil, errors.New("invalid configured CA")
		}
		cfg.RootCAs = root
	}
	return &http.Client{
		Transport:     &http.Transport{TLSClientConfig: cfg, Proxy: nil},
		CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse },
		Timeout:       timeout,
	}, nil
}

func (a *Agent) Start(ctx context.Context) error {
	endpoint, err := url.Parse(a.Identity.Endpoint)
	if err != nil || endpoint.Scheme != "wss" || endpoint.Hostname() == "" || endpoint.User != nil ||
		endpoint.RawQuery != "" || endpoint.Fragment != "" || !target.Path(endpoint.Path) || !target.ID(a.Identity.Agent) {
		return errors.New("invalid connector identity or WSS endpoint")
	}
	client, err := TLSClient(a.Identity.CAFile, 0)
	if err != nil {
		return err
	}
	a.resolved = make(map[string]*route)
	a.seen = make(map[string]string)
	if err := a.reload(); err != nil {
		return err
	}
	// The resolver, dial admission and local API all consume the same desired state.
	go a.runResolver(ctx)
	go a.runConnection(ctx, client)
	return nil
}

func (a *Agent) reload() error {
	a.mu.Lock()
	defer a.mu.Unlock()
	var policy Policy
	var state State
	if err := File(a.PolicyFile, &policy, false); err != nil {
		return err
	}
	allowed, err := LoadPolicy(policy)
	if err != nil {
		return err
	}
	if err := File(a.StateFile, &state, false); err != nil {
		return err
	}
	if err := state.Validate(allowed); err != nil {
		return err
	}
	if state.Revision < a.state.Revision || (state.Revision == a.state.Revision && !slices.Equal(state.Enabled, a.state.Enabled)) {
		return errors.New("desired state revision is stale")
	}
	a.state, a.allowed = state, allowed
	for id, current := range a.resolved {
		if !slices.Contains(state.Enabled, id) || current.descriptor.Fingerprint() != allowed[id].Fingerprint() {
			current.cancel()
			delete(a.resolved, id)
		}
	}
	return nil
}

var ErrConflict = errors.New("desired state revision conflict")
var ErrReadOnly = errors.New("desired state is mounted read-only")

func (a *Agent) Apply(expected uint64, enabled []string) (State, error) {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.ReadOnly {
		return State{}, ErrReadOnly
	}
	if expected != a.state.Revision || expected == ^uint64(0) {
		return State{}, ErrConflict
	}
	next := State{APIVersion: APIVersion, Kind: "AgentState", Revision: expected + 1, Enabled: slices.Clone(enabled)}
	if err := next.Validate(a.allowed); err != nil {
		return State{}, err
	}
	if slices.Equal(next.Enabled, a.state.Enabled) {
		return a.state, nil
	}
	if err := Atomic(a.StateFile, next); err != nil {
		return State{}, err
	}
	a.state = next
	for id, old := range a.resolved {
		if !slices.Contains(next.Enabled, id) {
			delete(a.resolved, id)
			old.cancel()
		}
	}
	return next, nil
}

func (a *Agent) Status() Status {
	a.mu.Lock()
	defer a.mu.Unlock()
	out := Status{Desired: a.state, Connected: a.connected, PolicyRevision: a.remote.PolicyRevision,
		FileError: a.fileError, AttachError: a.attachError, Problems: make(map[string]string)}
	for id := range a.allowed {
		out.Allowed = append(out.Allowed, id)
	}
	sort.Strings(out.Allowed)
	for id, code := range a.seen {
		out.Problems[id] = code
	}
	out.Observations = slices.Clone(a.remote.Targets)
	return out
}

func (a *Agent) runResolver(ctx context.Context) {
	tick := time.NewTicker(transport.Heartbeat)
	defer tick.Stop()
	defer func() {
		a.mu.Lock()
		defer a.mu.Unlock()
		for _, value := range a.resolved {
			value.cancel()
		}
	}()
	for {
		err := a.reload()
		a.mu.Lock()
		a.fileError = ""
		if err != nil {
			a.fileError = "rejected configuration update"
		}
		state, allowed := a.state, a.allowed
		a.mu.Unlock()
		var jobs sync.WaitGroup
		for _, id := range state.Enabled {
			d := allowed[id]
			jobs.Go(func() {
				attempt, cancel := context.WithTimeout(ctx, 1500*time.Millisecond)
				defer cancel()
				address, err := a.Kube.Resolve(attempt, d)
				a.mu.Lock()
				defer a.mu.Unlock()
				if a.state.Revision != state.Revision || !reflect.DeepEqual(a.allowed[id], d) {
					return
				}
				old := a.resolved[id]
				if err != nil {
					a.seen[id] = err.Error()
					if old != nil {
						old.cancel()
						delete(a.resolved, id)
					}
					return
				}
				delete(a.seen, id)
				if old != nil && old.address == address {
					return
				}
				if old != nil {
					old.cancel()
				}
				routeCtx, release := context.WithCancel(ctx)
				a.resolved[id] = &route{descriptor: d, address: address, ctx: routeCtx, cancel: release,
					slots: make(chan struct{}, d.Parallel+1)}
			})
		}
		jobs.Wait()
		select {
		case <-ctx.Done():
			return
		case <-tick.C:
		}
	}
}

func (a *Agent) inventory() transport.Inventory {
	a.mu.Lock()
	defer a.mu.Unlock()
	res := transport.Inventory{Revision: a.state.Revision}
	for id, d := range a.resolved {
		res.Targets = append(res.Targets, transport.Advertised{ID: id, Fingerprint: d.descriptor.Fingerprint()})
	}
	sort.Slice(res.Targets, func(i, j int) bool { return res.Targets[i].ID < res.Targets[j].ID })
	return res
}

func (a *Agent) runConnection(ctx context.Context, client *http.Client) {
	delay := 150 * time.Millisecond
	for ctx.Err() == nil {
		start := time.Now()
		err := a.connect(ctx, client)
		a.mu.Lock()
		a.connected = false
		a.remote = transport.Reply{}
		a.attachError = "disconnected"
		if err != nil && ctx.Err() == nil {
			a.attachError = err.Error()
		}
		a.mu.Unlock()
		if time.Since(start) > 4*time.Second {
			delay = 150 * time.Millisecond
		}
		select {
		case <-ctx.Done():
			return
		case <-time.After(delay + time.Duration(time.Now().UnixNano()%int64(delay/2))):
		}
		delay = min(4*time.Second, delay*2)
	}
}

func (a *Agent) connect(ctx context.Context, client *http.Client) error {
	var cfg Credential
	if err := File(a.Credentials, &cfg, true); err != nil || cfg.Epoch == 0 || !StrongToken(cfg.Token) {
		return errors.New("connector credentials unavailable")
	}
	headers := http.Header{
		"Authorization":  {"Bearer " + cfg.Token},
		"X-Source-Agent": {a.Identity.Agent},
		"X-Source-Epoch": {strconv.FormatUint(cfg.Epoch, 10)},
	}
	session, err := transport.Connect(ctx, a.Identity.Endpoint, headers, client)
	if err != nil {
		return err
	}
	defer session.Close()
	control, err := session.OpenStream(ctx)
	if err != nil {
		return err
	}
	ch := make(chan error, 1)
	go func() { ch <- a.heartbeat(ctx, control, cfg); _ = session.Close() }()
	for {
		stream, err := session.AcceptStream()
		if err != nil {
			select {
			case why := <-ch:
				return why
			default:
				return errors.New("tunnel closed")
			}
		}
		go a.serve(stream)
	}
}

func (a *Agent) heartbeat(ctx context.Context, stream *yamux.Stream, original Credential) error {
	ticker := time.NewTicker(transport.Heartbeat)
	defer ticker.Stop()
	for {
		stream.SetDeadline(time.Now().Add(transport.InventoryTTL))
		if err := transport.Write(stream, a.inventory(), transport.MaxControl); err != nil {
			return errors.New("inventory delivery failed")
		}
		var reply transport.Reply
		if err := transport.Read(stream, &reply, transport.MaxControl); err != nil {
			return errors.New("inventory acknowledgment lost")
		}
		a.mu.Lock()
		a.remote, a.connected, a.attachError = reply, true, ""
		a.mu.Unlock()
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-ticker.C:
		}
		var current Credential
		if err := File(a.Credentials, &current, true); err != nil || current != original {
			return errors.New("connector credentials changed")
		}
	}
}

func (a *Agent) serve(stream *yamux.Stream) {
	defer stream.Reset()
	stream.SetDeadline(time.Now().Add(transport.Handshake))
	var ref transport.Open
	if err := transport.Read(stream, &ref, 1024); err != nil {
		return
	}
	a.mu.Lock()
	r := a.resolved[ref.Target]
	a.mu.Unlock()
	if r == nil || ref.Fingerprint != r.descriptor.Fingerprint() {
		_, _ = stream.Write([]byte{0})
		return
	}
	// The relay releases its lease when the HTTP call ends. Waiting briefly
	// lets the previous stream's reset reach this bridge and release its slot.
	wait, release := context.WithTimeout(r.ctx, 300*time.Millisecond)
	defer release()
	select {
	case r.slots <- struct{}{}:
		defer func() { <-r.slots }()
		release()
	case <-wait.Done():
		_, _ = stream.Write([]byte{0})
		return
	}
	attempt, cancel := context.WithTimeout(r.ctx, 2*time.Second)
	defer cancel()
	conn, err := (&net.Dialer{}).DialContext(attempt, "tcp", r.address)
	if err != nil {
		_, _ = stream.Write([]byte{0})
		return
	}
	defer conn.Close()
	drop := context.AfterFunc(r.ctx, func() { conn.Close(); stream.Reset() })
	defer drop()
	if _, err := stream.Write([]byte{1}); err != nil {
		return
	}
	stream.SetDeadline(time.Now().Add(5 * time.Minute))
	transport.Bridge(stream, conn.(*net.TCPConn))
}

func Auth(r *http.Request) string {
	value, ok := strings.CutPrefix(r.Header.Get("Authorization"), "Bearer ")
	if !ok {
		return ""
	}
	return value
}

func Endpoint(kubeHost, port string) string {
	return fmt.Sprintf("https://%s", net.JoinHostPort(kubeHost, port))
}
