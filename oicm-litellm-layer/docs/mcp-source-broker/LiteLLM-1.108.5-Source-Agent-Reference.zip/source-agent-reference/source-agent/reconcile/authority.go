package reconcile

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"encoding/base64"
	"encoding/json"
	"errors"
	"io"
	"net"
	"net/http"
	"net/url"
	"reflect"
	"sort"
	"time"

	"example.org/litellm/source-agent/target"
)

const PolicyTTL = 5 * time.Second
const HealthTTL = 4 * time.Second

type Admission struct {
	Descriptor target.Descriptor `json:"descriptor" yaml:"descriptor"`
	Revision   uint64            `json:"revision" yaml:"revision"`
	Phase      string            `json:"phase" yaml:"phase"`
	DrainUntil time.Time         `json:"drain_until,omitempty" yaml:"drain_until,omitempty"`
	Catalog    string            `json:"catalog_sha256" yaml:"catalog_sha256"`
	ProofKey   string            `json:"proof_key" yaml:"proof_key"`
}

type AgentGrant struct {
	ID             string      `json:"id" yaml:"id"`
	Epoch          uint64      `json:"epoch" yaml:"epoch"`
	CredentialHash string      `json:"credential_sha256" yaml:"credential_sha256"`
	Phase          string      `json:"phase" yaml:"phase"`
	Channels       []Admission `json:"channels" yaml:"channels"`
}

type Snapshot struct {
	Revision uint64       `json:"revision" yaml:"revision"`
	Agents   []AgentGrant `json:"agents" yaml:"agents"`
}

type Feed func(context.Context) (Snapshot, error)

func FileFeed(path string) Feed {
	return func(context.Context) (Snapshot, error) {
		var s Snapshot
		err := File(path, &s, true)
		return s, err
	}
}

func HTTPFeed(raw, token, ca string) (Feed, error) {
	u, err := url.Parse(raw)
	if err != nil || u.Hostname() == "" || u.User != nil || u.RawQuery != "" || u.Fragment != "" ||
		(u.Scheme != "https" && (u.Scheme != "http" || !net.ParseIP(u.Hostname()).IsLoopback())) {
		return nil, errors.New("policy feed requires HTTPS or numeric loopback")
	}
	client, err := TLSClient(ca, 1500*time.Millisecond)
	if err != nil {
		return nil, err
	}
	return func(ctx context.Context) (Snapshot, error) {
		var s Snapshot
		req, err := http.NewRequestWithContext(ctx, http.MethodGet, raw, nil)
		if err != nil {
			return s, err
		}
		req.Header.Set("Authorization", "Bearer "+token)
		resp, err := client.Do(req)
		if err != nil {
			return s, err
		}
		defer resp.Body.Close()
		if resp.StatusCode != 200 {
			return s, errors.New("policy feed unavailable")
		}
		data, err := io.ReadAll(io.LimitReader(resp.Body, MaxConfig+1))
		if err != nil || len(data) > MaxConfig || DecodeJSON(data, &s) != nil {
			return s, errors.New("invalid policy feed document")
		}
		return s, nil
	}, nil
}

func (s *Snapshot) normalize() error {
	if s.Revision == 0 || len(s.Agents) > 128 {
		return errors.New("invalid authority revision or agent count")
	}
	sort.Slice(s.Agents, func(i, j int) bool { return s.Agents[i].ID < s.Agents[j].ID })
	for i := range s.Agents {
		a := &s.Agents[i]
		if a.Epoch == 0 || !target.ID(a.ID) || (i > 0 && s.Agents[i-1].ID == a.ID) ||
			(a.Phase != "active" && a.Phase != "revoked") || !target.Digest(a.CredentialHash) || len(a.Channels) > target.MaxTargets {
			return errors.New("invalid or duplicate agent grant")
		}
		sort.Slice(a.Channels, func(i, j int) bool { return a.Channels[i].Descriptor.ID < a.Channels[j].Descriptor.ID })
		for j, c := range a.Channels {
			key, err := base64.StdEncoding.DecodeString(c.ProofKey)
			if c.Revision == 0 || !target.Digest(c.Catalog) || c.Descriptor.Validate() != nil ||
				err != nil || len(key) != ed25519.PublicKeySize ||
				(j > 0 && a.Channels[j-1].Descriptor.ID == c.Descriptor.ID) ||
				(c.Phase != "active" && c.Phase != "draining" && c.Phase != "revoked") ||
				(c.Phase == "draining" && c.DrainUntil.IsZero()) {
				return errors.New("invalid or duplicate channel grant")
			}
		}
	}
	return nil
}

func (s Snapshot) agent(id string) (AgentGrant, bool) {
	for _, a := range s.Agents {
		if a.ID == id {
			return a, true
		}
	}
	return AgentGrant{}, false
}

func (a AgentGrant) channel(id string) (Admission, bool) {
	for _, c := range a.Channels {
		if c.Descriptor.ID == id {
			return c, true
		}
	}
	return Admission{}, false
}

func compatible(old, next Admission) bool {
	return old.Revision == next.Revision && old.Descriptor.Fingerprint() == next.Descriptor.Fingerprint() &&
		old.ProofKey == next.ProofKey && old.Catalog == next.Catalog
}

// ValidatePolicy applies the same rules as the relay before a publisher commits
// a candidate projection. A zero previous revision represents initial setup.
func ValidatePolicy(previous, candidate Snapshot) error {
	if err := candidate.normalize(); err != nil {
		return err
	}
	if previous.Revision != 0 {
		if err := previous.normalize(); err != nil {
			return err
		}
	}
	return checkPolicyTransition(previous, candidate)
}

func DecodeJSON(data []byte, destination any) error {
	decoder := json.NewDecoder(bytes.NewReader(data))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(destination); err != nil {
		return errors.New("invalid policy JSON")
	}
	if err := decoder.Decode(new(any)); err != io.EOF {
		return errors.New("expected a single policy JSON document")
	}
	return nil
}

func checkPolicyTransition(old, next Snapshot) error {
	if next.Revision < old.Revision || (next.Revision == old.Revision && !reflect.DeepEqual(old, next)) {
		return errors.New("authority revision regressed or was reused")
	}
	for _, before := range old.Agents {
		a, ok := next.agent(before.ID)
		if !ok {
			return errors.New("retain the revoked agent as a tombstone")
		}
		if a.Epoch < before.Epoch || (a.Epoch == before.Epoch &&
			(a.CredentialHash != before.CredentialHash || (before.Phase == "revoked" && a.Phase != "revoked"))) {
			return errors.New("agent credential change requires a new epoch")
		}
		for _, p := range before.Channels {
			c, ok := a.channel(p.Descriptor.ID)
			if !ok {
				return errors.New("retain the revoked channel as a tombstone")
			}
			if c.Revision < p.Revision || (c.Revision == p.Revision &&
				(!compatible(p, c) || (p.Phase == "revoked" && c.Phase != "revoked"))) {
				return errors.New("channel approval change requires a new revision")
			}
		}
	}
	return nil
}
