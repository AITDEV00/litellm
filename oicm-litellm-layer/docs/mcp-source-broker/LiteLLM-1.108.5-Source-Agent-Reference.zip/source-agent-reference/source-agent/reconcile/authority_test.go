package reconcile

import (
	"context"
	"encoding/base64"
	"strings"
	"testing"
	"time"

	"example.org/litellm/source-agent/target"
)

func approvedTest() Admission {
	return Admission{
		Descriptor: target.Descriptor{ID: "docs", Kind: "mcp", Address: "127.0.0.1:1234", Path: "/mcp", Proof: "/proof", Parallel: 2},
		Revision:   1, Phase: "active", Catalog: strings.Repeat("a", 64),
		ProofKey: base64.StdEncoding.EncodeToString(make([]byte, 32)),
	}
}

func TestPolicyFences(t *testing.T) {
	grant := AgentGrant{ID: "site-one", Epoch: 1, CredentialHash: strings.Repeat("b", 64),
		Phase: "active", Channels: []Admission{approvedTest()}}
	duplicates := Snapshot{Revision: 1, Agents: []AgentGrant{grant, grant}}
	if duplicates.normalize() == nil {
		t.Fatal("accepted duplicate identity")
	}
	dupe := grant
	dupe.Channels = []Admission{approvedTest(), approvedTest()}
	duplicates.Agents = []AgentGrant{dupe}
	if duplicates.normalize() == nil {
		t.Fatal("accepted duplicate channel grant")
	}
	before := Snapshot{Revision: 1, Agents: []AgentGrant{grant}}
	changed := grant
	revision := approvedTest()
	revision.Catalog = strings.Repeat("c", 64)
	changed.Channels = []Admission{revision}
	next := Snapshot{Revision: 2, Agents: []AgentGrant{changed}}
	if checkPolicyTransition(before, next) == nil {
		t.Fatal("reused green revision for new catalog")
	}
	next.Agents[0].Channels[0].Revision = 2
	if err := checkPolicyTransition(before, next); err != nil {
		t.Fatal(err)
	}
	next.Agents[0].CredentialHash = strings.Repeat("d", 64)
	if checkPolicyTransition(before, next) == nil {
		t.Fatal("changed credential without epoch")
	}
	if ValidatePolicy(before, Snapshot{Revision: 2}) == nil {
		t.Fatal("accepted loss of agent tombstone")
	}
	changed.CredentialHash = grant.CredentialHash
	changed.Channels = nil
	if ValidatePolicy(before, Snapshot{Revision: 2, Agents: []AgentGrant{changed}}) == nil {
		t.Fatal("accepted loss of channel tombstone")
	}
}

func TestDrainRevokeAndSessionGC(t *testing.T) {
	approval := approvedTest()
	grant := AgentGrant{ID: "site-one", Phase: "active", Epoch: 1, Channels: []Admission{approval}}
	now := time.Now()
	r := NewRelay(nil, nil)
	r.policy = Snapshot{Revision: 1, Agents: []AgentGrant{grant}}
	r.loadedAt = now
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	chanCtx, chanCancel := context.WithCancel(ctx)
	c := &channel{ctx: chanCtx, cancel: chanCancel, approval: approval, goodUntil: now.Add(time.Minute),
		sessions: map[string]time.Time{"stale": now.Add(-time.Second), "current": now.Add(time.Minute)}}
	p := &peer{ctx: ctx, id: grant.ID, reportedAt: now, channels: map[string]*channel{"docs": c},
		inventory: map[string]string{"docs": approval.Descriptor.Fingerprint()}}
	r.peers[p.id] = p
	r.syncChannels(p, grant, now)
	if len(c.sessions) != 1 || c.sessions["current"].IsZero() {
		t.Fatal("garbage collection retained expired or deleted current")
	}
	lease, err := r.Acquire(ctx, p.id, "docs", "current")
	if err != nil {
		t.Fatal(err)
	}
	defer lease.Finish()
	grant.Channels[0].Phase, grant.Channels[0].DrainUntil = "draining", now.Add(time.Minute)
	r.syncChannels(p, grant, now)
	if _, err := r.Acquire(ctx, p.id, "docs", "current"); err != ErrUnavailable || lease.Context.Err() != nil {
		t.Fatal("drain admitted new work or interrupted existing work")
	}
	r.syncChannels(p, grant, now.Add(2*time.Minute))
	select {
	case <-lease.Context.Done():
	case <-time.After(time.Second):
		t.Fatal("drain deadline failed to revoke the channel")
	}
	if p.channels["docs"] != nil {
		t.Fatal("retained expired channel")
	}
}
