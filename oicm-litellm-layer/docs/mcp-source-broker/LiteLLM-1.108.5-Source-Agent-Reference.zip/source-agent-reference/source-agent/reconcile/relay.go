package reconcile

import (
	"context"
	"errors"
	"net"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"

	"example.org/litellm/source-agent/target"
	"example.org/litellm/source-agent/transport"
	yamux "github.com/libp2p/go-yamux/v5"
)

type Dial func(context.Context) (net.Conn, error)
type Probe func(context.Context, string, Admission, Dial) error

type Relay struct {
	feed  Feed
	probe Probe

	mu        sync.Mutex
	policy    Snapshot
	loadedAt  time.Time
	feedError string
	peers     map[string]*peer
}

type peer struct {
	id          string
	epoch       uint64
	digest      string
	mux         *transport.Session
	inventory   map[string]string
	reportedAt  time.Time
	attachedAt  time.Time
	reportedRev uint64
	ctx         context.Context
	cancel      context.CancelFunc
	channels    map[string]*channel
}

type channel struct {
	approval  Admission
	ctx       context.Context
	cancel    context.CancelFunc
	goodUntil time.Time
	problem   string
	active    int
	sessions  map[string]time.Time
}

func NewRelay(feed Feed, probe Probe) *Relay {
	return &Relay{feed: feed, probe: probe, peers: make(map[string]*peer)}
}

func (r *Relay) Run(ctx context.Context) {
	defer func() {
		r.mu.Lock()
		defer r.mu.Unlock()
		for _, p := range r.peers {
			p.cancel()
		}
	}()
	interval := time.NewTicker(500 * time.Millisecond)
	defer interval.Stop()
	for {
		policy, err := r.feed(ctx)
		now := time.Now()
		r.mu.Lock()
		switch {
		case err != nil:
			r.feedError = "read_failed"
		case policy.normalize() != nil:
			r.feedError = "invalid_snapshot"
		case checkPolicyTransition(r.policy, policy) != nil:
			r.feedError = "revision_conflict"
		default:
			r.policy, r.loadedAt = policy, now
			r.feedError = ""
		}
		for id, p := range r.peers {
			grant, ok := r.policy.agent(id)
			if !r.fresh(now) || !ok || grant.Phase != "active" || grant.Epoch != p.epoch ||
				grant.CredentialHash != p.digest || (!p.reportedAt.IsZero() && now.Sub(p.reportedAt) > transport.InventoryTTL) {
				delete(r.peers, id)
				p.cancel()
				continue
			}
			r.syncChannels(p, grant, now)
		}
		r.mu.Unlock()
		select {
		case <-ctx.Done():
			return
		case <-interval.C:
		}
	}
}

func (r *Relay) fresh(now time.Time) bool {
	return !r.loadedAt.IsZero() && now.Sub(r.loadedAt) < PolicyTTL
}

func (r *Relay) Attach(w http.ResponseWriter, req *http.Request) {
	if !strings.EqualFold(req.Header.Get("Upgrade"), "websocket") ||
		req.Header.Get("Sec-WebSocket-Protocol") != transport.Protocol {
		http.Error(w, "source-agent WebSocket required", http.StatusUpgradeRequired)
		return
	}
	id := req.Header.Get("X-Source-Agent")
	epoch, err := strconv.ParseUint(req.Header.Get("X-Source-Epoch"), 10, 64)
	r.mu.Lock()
	grant, ok := r.policy.agent(id)
	if !r.fresh(time.Now()) {
		r.mu.Unlock()
		http.Error(w, "authority unavailable", http.StatusServiceUnavailable)
		return
	}
	if !ok || err != nil || grant.Phase != "active" || epoch != grant.Epoch || !Matches(grant.CredentialHash, Auth(req)) {
		r.mu.Unlock()
		http.Error(w, "source agent unauthorized", http.StatusUnauthorized)
		return
	}
	if _, exists := r.peers[id]; exists {
		r.mu.Unlock()
		http.Error(w, "source agent already attached", http.StatusConflict)
		return
	}
	ctx, cancel := context.WithCancel(req.Context())
	p := &peer{id: id, epoch: epoch, digest: grant.CredentialHash, ctx: ctx, cancel: cancel, attachedAt: time.Now(),
		channels: make(map[string]*channel)}
	r.peers[id] = p
	r.mu.Unlock()
	defer func() {
		cancel()
		r.mu.Lock()
		defer r.mu.Unlock()
		if r.peers[id] == p {
			delete(r.peers, id)
		}
	}()
	mux, err := transport.Accept(ctx, w, req)
	if err != nil {
		return
	}
	defer mux.Close()
	stop := context.AfterFunc(ctx, func() { _ = mux.Close() })
	defer stop()
	r.mu.Lock()
	p.mux = mux
	r.mu.Unlock()

	timer := time.AfterFunc(transport.InventoryTTL, cancel)
	stream, err := mux.AcceptStream()
	timer.Stop()
	if err != nil {
		return
	}
	defer stream.Reset()
	for ctx.Err() == nil {
		stream.SetDeadline(time.Now().Add(transport.InventoryTTL))
		var view transport.Inventory
		if err := transport.Read(stream, &view, transport.MaxControl); err != nil {
			return
		}
		result, err := r.inventory(p, view)
		if err != nil || transport.Write(stream, result, transport.MaxControl) != nil {
			return
		}
	}
}

func (r *Relay) inventory(p *peer, view transport.Inventory) (transport.Reply, error) {
	if view.Revision == 0 || len(view.Targets) > target.MaxTargets {
		return transport.Reply{}, errors.New("invalid inventory")
	}
	inventory := make(map[string]string, len(view.Targets))
	for _, d := range view.Targets {
		if !target.ID(d.ID) || !target.Digest(d.Fingerprint) || inventory[d.ID] != "" {
			return transport.Reply{}, errors.New("invalid or duplicate inventory channel")
		}
		inventory[d.ID] = d.Fingerprint
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	grant, ok := r.policy.agent(p.id)
	now := time.Now()
	if r.peers[p.id] != p || !r.fresh(now) || !ok || view.Revision < p.reportedRev {
		return transport.Reply{}, errors.New("stale inventory or connection")
	}
	p.inventory, p.reportedRev, p.reportedAt = inventory, view.Revision, now
	r.syncChannels(p, grant, now)
	return r.report(p, now), nil
}

func (r *Relay) syncChannels(p *peer, grant AgentGrant, now time.Time) {
	for name, c := range p.channels {
		desired, exists := grant.channel(name)
		if !exists || p.inventory[name] != desired.Descriptor.Fingerprint() || !compatible(c.approval, desired) ||
			desired.Phase == "revoked" || (desired.Phase == "draining" && !now.Before(desired.DrainUntil)) {
			delete(p.channels, name)
			c.cancel()
			continue
		}
		c.approval.Phase, c.approval.DrainUntil = desired.Phase, desired.DrainUntil
		for session, expires := range c.sessions {
			if !now.Before(expires) {
				delete(c.sessions, session)
			}
		}
	}
	for _, desired := range grant.Channels {
		id := desired.Descriptor.ID
		if p.channels[id] != nil || desired.Phase != "active" || p.inventory[id] != desired.Descriptor.Fingerprint() {
			continue
		}
		ctx, cancel := context.WithCancel(p.ctx)
		c := &channel{approval: desired, ctx: ctx, cancel: cancel, sessions: make(map[string]time.Time)}
		p.channels[id] = c
		go r.watch(p, c, desired)
	}
}

func (r *Relay) watch(p *peer, c *channel, approval Admission) {
	interval := time.NewTicker(transport.Heartbeat)
	defer interval.Stop()
	for {
		r.mu.Lock()
		active := c.approval.Phase == "active"
		r.mu.Unlock()
		if !active {
			select {
			case <-c.ctx.Done():
				return
			case <-interval.C:
				continue
			}
		}
		ctx, cancel := context.WithTimeout(c.ctx, 1500*time.Millisecond)
		err := r.probe(ctx, p.id, approval, func(ctx context.Context) (net.Conn, error) { return r.dial(ctx, p, c, approval) })
		cancel()
		r.mu.Lock()
		if p.channels[approval.Descriptor.ID] != c || c.ctx.Err() != nil {
			r.mu.Unlock()
			return
		}
		if c.approval.Phase == "active" {
			c.goodUntil, c.problem = time.Time{}, ""
			if err != nil {
				c.problem = err.Error()
			} else {
				c.goodUntil = time.Now().Add(HealthTTL)
			}
		}
		r.mu.Unlock()
		select {
		case <-c.ctx.Done():
			return
		case <-interval.C:
		}
	}
}

func (r *Relay) dial(ctx context.Context, p *peer, c *channel, approval Admission) (net.Conn, error) {
	ctx, cancel := context.WithCancel(ctx)
	defer cancel()
	revoke := context.AfterFunc(c.ctx, cancel)
	defer revoke()
	stream, err := p.mux.Target(ctx, transport.Open{Target: approval.Descriptor.ID, Fingerprint: approval.Descriptor.Fingerprint()})
	if err != nil {
		return nil, err
	}
	stop := context.AfterFunc(c.ctx, func() { _ = stream.Reset() })
	return &channelConn{Stream: stream, stop: stop}, nil
}

type channelConn struct {
	*yamux.Stream
	stop func() bool
}

func (c *channelConn) Close() error { c.stop(); return c.Reset() }

func (r *Relay) report(p *peer, now time.Time) transport.Reply {
	reply := transport.Reply{PolicyRevision: r.policy.Revision, AttachedAt: p.attachedAt.UnixMilli()}
	grant, _ := r.policy.agent(p.id)
	for id, fingerprint := range p.inventory {
		view := transport.Observation{ID: id, Phase: "awaiting_approval"}
		if desired, ok := grant.channel(id); ok {
			view.Revision, view.Phase = desired.Revision, desired.Phase
			if desired.Descriptor.Fingerprint() != fingerprint {
				view.Phase = "descriptor_mismatch"
			}
		}
		if c := p.channels[id]; c != nil {
			view.Ready = c.approval.Phase == "active" && now.Before(c.goodUntil) && r.fresh(now)
			view.InFlight, view.Problem = c.active, c.problem
		}
		reply.Targets = append(reply.Targets, view)
	}
	return reply
}

type RelayStatus struct {
	Revision  uint64                     `json:"loaded_revision"`
	Fresh     bool                       `json:"fresh"`
	FeedError string                     `json:"feed_error,omitempty"`
	Agents    map[string]transport.Reply `json:"attached"`
}

func (r *Relay) Status() RelayStatus {
	now := time.Now()
	r.mu.Lock()
	defer r.mu.Unlock()
	s := RelayStatus{Revision: r.policy.Revision, Fresh: r.fresh(now), FeedError: r.feedError, Agents: make(map[string]transport.Reply)}
	for id, p := range r.peers {
		s.Agents[id] = r.report(p, now)
	}
	return s
}

var ErrUnavailable = errors.New("channel unavailable")
var ErrSession = errors.New("MCP session is gone")

type Lease struct {
	Admission Admission
	Context   context.Context
	Dial      Dial
	Finish    func()
	Session   func(id string, remove bool) bool
}

func (r *Relay) Acquire(ctx context.Context, agent, targetID, sessionID string) (Lease, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	p := r.peers[agent]
	now := time.Now()
	if p == nil || p.ctx.Err() != nil || now.Sub(p.reportedAt) > transport.InventoryTTL || !r.fresh(now) {
		if sessionID != "" {
			return Lease{}, ErrSession
		}
		return Lease{}, ErrUnavailable
	}
	c := p.channels[targetID]
	if sessionID != "" && (c == nil || c.approval.Descriptor.Kind != "mcp" || !now.Before(c.sessions[sessionID])) {
		return Lease{}, ErrSession
	}
	if c == nil || c.ctx.Err() != nil || c.approval.Phase != "active" || !now.Before(c.goodUntil) ||
		c.active >= c.approval.Descriptor.Parallel {
		return Lease{}, ErrUnavailable
	}
	approval := c.approval
	if sessionID != "" {
		c.sessions[sessionID] = now.Add(30 * time.Minute)
	}
	c.active++
	streamCtx, cancel := context.WithCancel(ctx)
	drop := context.AfterFunc(c.ctx, cancel)
	finished := sync.OnceFunc(func() {
		drop()
		cancel()
		r.mu.Lock()
		defer r.mu.Unlock()
		c.active--
	})
	return Lease{Admission: approval, Context: streamCtx,
		Dial: func(ctx context.Context) (net.Conn, error) { return r.dial(ctx, p, c, approval) }, Finish: finished,
		Session: func(id string, remove bool) bool {
			r.mu.Lock()
			defer r.mu.Unlock()
			if c.ctx.Err() != nil || p.channels[targetID] != c {
				return false
			}
			if remove {
				delete(c.sessions, id)
				return true
			}
			if len(c.sessions) >= 256 && c.sessions[id].IsZero() {
				return false
			}
			c.sessions[id] = time.Now().Add(30 * time.Minute)
			return true
		},
	}, nil
}
