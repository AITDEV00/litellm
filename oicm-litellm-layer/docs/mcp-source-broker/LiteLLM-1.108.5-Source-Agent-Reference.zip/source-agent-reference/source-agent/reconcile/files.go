package reconcile

import (
	"bytes"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"example.org/litellm/source-agent/target"
	"go.yaml.in/yaml/v3"
)

const APIVersion = "source-agent.example.org/v1alpha1"
const MaxConfig = 256 << 10

type State struct {
	APIVersion string   `json:"apiVersion" yaml:"apiVersion"`
	Kind       string   `json:"kind" yaml:"kind"`
	Revision   uint64   `json:"revision" yaml:"revision"`
	Enabled    []string `json:"enabled" yaml:"enabled"`
}

type Policy struct {
	APIVersion string              `json:"apiVersion" yaml:"apiVersion"`
	Kind       string              `json:"kind" yaml:"kind"`
	Targets    []target.Descriptor `json:"targets" yaml:"targets"`
}

type Identity struct {
	Agent    string `json:"agent" yaml:"agent"`
	Endpoint string `json:"endpoint" yaml:"endpoint"`
	CAFile   string `json:"ca_file,omitempty" yaml:"ca_file,omitempty"`
}

type Credential struct {
	Epoch uint64 `json:"epoch" yaml:"epoch"`
	Token string `json:"token" yaml:"token"`
}

func File(path string, value any, private bool) error {
	file, err := os.Open(path)
	if err != nil {
		return err
	}
	defer file.Close()
	stat, err := file.Stat()
	if err != nil || !stat.Mode().IsRegular() || (private && stat.Mode().Perm() != 0600 && stat.Mode().Perm() != 0400 && stat.Mode().Perm() != 0440) {
		return errors.New("bad configuration mode, expected regular file and protected credentials")
	}
	data, err := io.ReadAll(io.LimitReader(file, MaxConfig+1))
	if err != nil || len(data) > MaxConfig {
		return errors.New("configuration exceeds limit")
	}
	decoder := yaml.NewDecoder(bytes.NewReader(data))
	decoder.KnownFields(true)
	if err := decoder.Decode(value); err != nil {
		return errors.New("invalid configuration document or unknown field")
	}
	if err := decoder.Decode(new(any)); err != io.EOF {
		return errors.New("configuration must contain one document")
	}
	return nil
}

func Atomic(path string, value any) error {
	data, err := json.MarshalIndent(value, "", "  ")
	if err != nil || len(data) > MaxConfig {
		return errors.New("outgoing configuration exceeds limit")
	}
	dir := filepath.Dir(path)
	file, err := os.CreateTemp(dir, ".source-agent-")
	if err != nil {
		return err
	}
	defer os.Remove(file.Name())
	defer file.Close()
	if _, err := file.Write(append(data, '\n')); err != nil {
		return err
	}
	if err := file.Sync(); err != nil {
		return err
	}
	if err := file.Close(); err != nil {
		return err
	}
	if err := os.Rename(file.Name(), path); err != nil {
		return err
	}
	folder, err := os.Open(dir)
	if err != nil {
		return err
	}
	defer folder.Close()
	return folder.Sync()
}

func LoadPolicy(p Policy) (map[string]target.Descriptor, error) {
	if p.APIVersion != APIVersion || p.Kind != "TargetPolicy" || len(p.Targets) > target.MaxTargets {
		return nil, errors.New("invalid TargetPolicy type or capacity")
	}
	res := make(map[string]target.Descriptor, len(p.Targets))
	for _, d := range p.Targets {
		if err := d.Validate(); err != nil {
			return nil, fmt.Errorf("invalid descriptor %q: %w", d.ID, err)
		}
		if _, ok := res[d.ID]; ok {
			return nil, errors.New("duplicate target ID")
		}
		res[d.ID] = d
	}
	return res, nil
}

func (s *State) Validate(allowed map[string]target.Descriptor) error {
	if s.APIVersion != APIVersion || s.Kind != "AgentState" || s.Revision == 0 || len(s.Enabled) > target.MaxTargets {
		return errors.New("invalid AgentState type, revision, or capacity")
	}
	sort.Strings(s.Enabled)
	for i, id := range s.Enabled {
		if _, ok := allowed[id]; !ok || (i > 0 && id == s.Enabled[i-1]) {
			return errors.New("target is outside the allowlist or duplicated")
		}
	}
	return nil
}

func StrongToken(s string) bool {
	decoded, err := base64.RawURLEncoding.DecodeString(s)
	return len(s) == 43 && len(decoded) == 32 && err == nil
}

func Hash(s string) string { return fmt.Sprintf("%x", sha256.Sum256([]byte(s))) }

func Matches(hash, value string) bool {
	return len(value) <= 256 && subtle.ConstantTimeCompare([]byte(hash), []byte(Hash(value))) == 1
}

func Secret(path string) (string, error) {
	file, err := os.Open(path)
	if err != nil {
		return "", errors.New("secret file is unavailable")
	}
	defer file.Close()
	info, err := file.Stat()
	if err != nil || !info.Mode().IsRegular() || (info.Mode().Perm() != 0600 && info.Mode().Perm() != 0400 && info.Mode().Perm() != 0440) {
		return "", errors.New("secret file must be protected")
	}
	if info.Size() > 256 {
		return "", errors.New("invalid control secret")
	}
	b, err := io.ReadAll(io.LimitReader(file, 257))
	token := strings.TrimSpace(string(b))
	if err != nil || len(b) > 256 || !StrongToken(token) {
		return "", errors.New("invalid control secret")
	}
	return token, nil
}
