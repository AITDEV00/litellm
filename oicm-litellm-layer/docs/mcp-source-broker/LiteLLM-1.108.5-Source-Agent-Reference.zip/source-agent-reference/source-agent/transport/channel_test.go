package transport

import (
	"bytes"
	"context"
	"encoding/binary"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

func TestBounds(t *testing.T) {
	var frame bytes.Buffer
	if err := Write(&frame, strings.Repeat("a", 33), 32); err == nil || frame.Len() != 0 {
		t.Fatal("oversize outbound control frame")
	}
	if err := binary.Write(&frame, binary.BigEndian, uint32(MaxControl+1)); err != nil {
		t.Fatal(err)
	}
	if err := Read(&frame, new(Inventory), MaxControl); err == nil {
		t.Fatal("oversize inbound control frame")
	}
}

func TestWSSHalfCloseAndIndependentStreams(t *testing.T) {
	ctx, done := context.WithTimeout(context.Background(), 8*time.Second)
	defer done()
	accepted := make(chan *Session, 1)
	srv := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		s, err := Accept(ctx, w, r)
		if err != nil {
			return
		}
		defer s.Close()
		accepted <- s
		<-ctx.Done()
	}))
	defer func() { done(); srv.Close() }()
	client, err := Connect(ctx, "wss"+strings.TrimPrefix(srv.URL, "https"), nil, srv.Client())
	if err != nil {
		t.Fatal(err)
	}
	defer client.Close()
	server := <-accepted
	listener, err := net.ListenTCP("tcp", &net.TCPAddr{IP: net.IPv4(127, 0, 0, 1)})
	if err != nil {
		t.Fatal(err)
	}
	defer listener.Close()
	go func() {
		origin, err := listener.AcceptTCP()
		if err != nil {
			return
		}
		defer origin.Close()
		origin.SetDeadline(time.Now().Add(4 * time.Second))
		body, _ := io.ReadAll(origin)
		origin.Write(append([]byte("after-fin:"), body...))
	}()
	go func() {
		stream, err := client.AcceptStream()
		if err != nil {
			return
		}
		defer stream.Close()
		var opened Open
		if Read(stream, &opened, 1024) != nil || opened.Target != "one" {
			return
		}
		conn, err := net.DialTCP("tcp", nil, listener.Addr().(*net.TCPAddr))
		if err != nil {
			return
		}
		defer conn.Close()
		stream.Write([]byte{1})
		Bridge(stream, conn)
	}()
	first, err := server.Target(ctx, Open{Target: "one"})
	if err != nil {
		t.Fatal(err)
	}
	first.SetDeadline(time.Now().Add(3 * time.Second))
	if _, err := first.Write([]byte("fixture")); err != nil {
		t.Fatal(err)
	}

	// One open stream is waiting for the native peer's FIN. A second stream progresses.
	go func() {
		stream, err := client.AcceptStream()
		if err != nil {
			return
		}
		defer stream.Close()
		var opened Open
		if Read(stream, &opened, 1024) == nil && opened.Target == "two" {
			stream.Write([]byte{1})
			stream.Write([]byte("sibling"))
		}
	}()
	second, err := server.Target(ctx, Open{Target: "two"})
	if err != nil {
		t.Fatal(err)
	}
	second.SetDeadline(time.Now().Add(time.Second))
	out, err := io.ReadAll(second)
	if err != nil || string(out) != "sibling" {
		t.Fatalf("sibling: %q %v", out, err)
	}
	second.Close()
	first.CloseWrite()
	out, err = io.ReadAll(first)
	if err != nil || string(out) != "after-fin:fixture" {
		t.Fatalf("target: %q %v", out, err)
	}
	first.Close()
}
