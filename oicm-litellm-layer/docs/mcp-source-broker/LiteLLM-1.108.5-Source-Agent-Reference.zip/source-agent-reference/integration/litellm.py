"""Apply a reviewed channel to LiteLLM's existing admin MCP API."""
import argparse
import json
import os
import sys
import urllib.error
import urllib.request
import uuid
from pathlib import Path
from urllib.parse import urlsplit

if __package__:
    from .openapi import validate
else:
    from openapi import validate


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def secret(path):
    with path.open() as stream:
        if os.fstat(stream.fileno()).st_mode & 0o007:
            raise ValueError("credential file must be protected")
        value = stream.read(4096).strip()
    if len(value) < 32 or "\r" in value or "\n" in value:
        raise ValueError("invalid credential")
    return value


class LiteLLM:
    def __init__(self, base, key):
        uri = urlsplit(base)
        if (uri.scheme != "https" and not (uri.scheme == "http" and uri.hostname in {"127.0.0.1", "::1"})) or (
            not uri.hostname or uri.username is not None or uri.path not in ("", "/") or uri.query or uri.fragment
        ):
            raise ValueError("use a trusted LiteLLM origin")
        self.base, self.key = base.rstrip("/"), key
        self.client = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())

    def api(self, method, suffix="", body=None):
        request = urllib.request.Request(self.base + "/v1/mcp/server" + suffix,
                  method=method, data=json.dumps(body).encode() if body is not None else None,
                  headers={"Authorization": "Bearer " + self.key, "Content-Type": "application/json"})
        try:
            with self.client.open(request, timeout=20) as response:
                return json.load(response)
        except urllib.error.HTTPError as err:
            raise ValueError(f"LiteLLM {method} returned HTTP {err.code}") from None

    def apply(self, *, alias, source, group, tools, data_key, spec=None):
        source_url = urlsplit(source)
        segments = source_url.path.split("/")
        if (source_url.scheme not in ("http", "https") or not source_url.hostname or source_url.username is not None or
                source_url.query or source_url.fragment or len(segments) != 4 or segments[1] != "sources" or
                not all(segments[2:]) or not group or not tools or len(set(tools)) != len(tools)):
            raise ValueError("expected a private broker channel, access group, and exact tool allowlist")
        # Do not silently claim a colliding admin-managed registration.
        identifier = str(uuid.uuid5(uuid.NAMESPACE_URL, "source-agent:" + alias))
        body = {"server_id": identifier, "server_name": alias, "alias": alias, "url": source,
                "transport": "http", "allow_all_keys": False, "available_on_public_internet": False,
                "mcp_access_groups": [group], "allowed_tools": tools,
                "static_headers": {"X-Source-Broker-Key": data_key}}
        if spec:
            spec = spec.resolve(strict=True)
            validate(json.loads(spec.read_text()))
            body["spec_path"] = str(spec)
        matching = [row for row in self.api("GET") if row.get("alias") == alias or
                    row.get("server_id") == identifier or row.get("server_name") == alias]
        for row in matching:
            if row.get("server_id") != identifier or row.get("url") != source:
                raise ValueError("alias already points to a different registered service")
            if bool(row.get("spec_path")) != bool(spec):
                raise ValueError("registration mode changes require explicit migration")
        result = self.api("PUT" if matching else "POST", body=body)
        if result.get("server_id") != identifier:
            raise ValueError("LiteLLM returned an unexpected registration ID")
        return identifier

    def pin(self, identifier):
        return self.api("POST", "/" + str(uuid.UUID(identifier)) + "/pin")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--proxy", required=True)
    parser.add_argument("--admin-key", type=Path, required=True)
    parser.add_argument("--broker-key", type=Path, required=True)
    parser.add_argument("--alias", required=True)
    parser.add_argument("--source-url", required=True)
    parser.add_argument("--group", required=True)
    parser.add_argument("--tool", action="append", required=True)
    parser.add_argument("--spec", type=Path)
    parser.add_argument("--pin", action="store_true", help="pin the reviewed tool catalog after registering")
    args = parser.parse_args()
    proxy = LiteLLM(args.proxy, secret(args.admin_key))
    server_id = proxy.apply(alias=args.alias, source=args.source_url, group=args.group, tools=args.tool,
                            data_key=secret(args.broker_key), spec=args.spec)
    pinned = sorted(proxy.pin(server_id)) if args.pin else []
    print(json.dumps({"server_id": server_id, "pinned_names": pinned}))


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError) as exc:
        sys.exit(str(exc))
