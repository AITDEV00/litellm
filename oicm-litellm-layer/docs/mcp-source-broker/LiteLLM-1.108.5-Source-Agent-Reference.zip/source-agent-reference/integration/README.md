# Integrate with the existing LiteLLM gateway

Preserve the existing private data plane. Expose the exact worker WebSocket through the approved HTTPS ingress. Keep the authority feed and HTTP projection private. For separate pods, restrict the Service to LiteLLM and use the existing private TLS or service mesh. Keep Authorization out of ingress logs. The supplied Caddy fragment illustrates exact upgrade routing. The optional [signed download routes](../docs/UPGRADE.md) use the same approved TLS site.

## Standalone staged site

Use tests/behavior.py or examples/demo.py for a runnable disposable fixture with two origins. For a staged host, provision the example nonsecret identity, policy and desired files. Generate the credential on the source host and send only its digest and epoch to the authorized broker operator. Regenerate the file without reinstalling the binary.

~~~bash
bin/source-agent credential -epoch 1 -out credential.yaml
bin/source-agent descriptors -policy examples/targets.yaml
bin/source-agent run -identity identity.yaml -policy targets.yaml \
  -state agent-state.yaml -credential credential.yaml -control-token control.key
bin/source-agent tui -token-file control.key
~~~

Create individual control and data keys as mode-600 files with Python secrets.token_urlsafe(32). Put the pinned gateway address and CA in the identity file. Adjust the illustrative descriptors to match the reviewed origin. Install the bundled source-agent.service under the host's systemd unit directory. Give its dedicated source-agent account read access to /etc/source-agent and its credential files. Give it a writable /var/lib/source-agent with the desired-state file. Once these paths are provisioned, `systemctl enable --now source-agent.service` starts it and enables start on reboot.

The approval snapshot is the control plane input. The tests create a complete one. Copy the exact reviewed target descriptors into each channel.

~~~yaml
revision: 1
agents:
  - id: site-one
    epoch: 1
    phase: active
    credential_sha256: "<digest written by credential command>"
    channels:
      - descriptor: {id: tools, kind: mcp, address: "127.0.0.1:18082", path: /mcp, proof_path: /proof, parallel: 4}
        revision: 1
        phase: active
        catalog_sha256: "<reviewed release digest>"
        proof_key: "<standard-base64 Ed25519 public key>"
~~~

~~~bash
chmod 600 authority.yaml
bin/source-agent relay -policy authority.yaml -data-token broker-data.key
~~~

For durable controller integration, use the PostgreSQL projection and its read-only private endpoint. Mount the handler in the existing control app. Reuse your existing admin identity and permissions. Produce the full projection within one transaction from real desired rows. The reference stores a sample projection in a separate schema so Prisma migrations do not claim it.

~~~bash
python3 integration/authority.py --dsn-file pg-controller.dsn publish --expect 0 --snapshot authority.json
python3 integration/authority.py --dsn-file pg-reader.dsn serve --feed-token relay-feed.key
bin/source-agent relay -feed http://127.0.0.1:9091/v1/source-agent/desired \
  -feed-token relay-feed.key -data-token broker-data.key
~~~

The publish helper accepts JSON using the same schema as the YAML snapshot. It uses the bundled validate-policy command inside the revision-checked transaction. Set --source-agent to your approved verifier binary if stored elsewhere. Use a separate PostgreSQL role with SELECT on the projection for the feed. Check the relay's authenticated /v1/observed before claiming publication. A local policy file is a staging source and has no external controller to detect.

## Register and call

Once proof is ready, call the branch's injected default_registration or the enclosed adapter for existing REST endpoints. It allocates one stable UUID per new alias and refuses collisions. If migrating an existing registration, use the branch's current update helper with its existing row and grants.

~~~bash
python3 integration/litellm.py --proxy http://127.0.0.1:4000 \
  --admin-key litellm-admin.key --broker-key broker-data.key \
  --alias site_tools --source-url http://127.0.0.1:9092/sources/site-one/tools \
  --group site-source-access --tool lookup_tool --pin
~~~

For OpenAPI, project the reviewed document and save it at a versioned path shared by the registrar and LiteLLM. The source signs the original release digest.

~~~bash
python3 integration/openapi.py reports-v1-reviewed.json --prefix /reports > reports-v1-broker.json
python3 integration/litellm.py --proxy http://127.0.0.1:4000 \
  --admin-key litellm-admin.key --broker-key broker-data.key \
  --alias site_reports --source-url http://127.0.0.1:9092/sources/site-one/reports \
  --group site-source-access --spec reports-v1-broker.json --tool read_report
~~~

Using the UUID from the registration output, call the existing execution route with an authorized virtual key. This example reads the key from a protected file. The same grants drive /mcp-rest/tools/list and the native /mcp route.

~~~bash
python3 - SERVER_UUID <<'PY'
import json
import sys
from pathlib import Path
from urllib.request import Request, urlopen

body = {"server_id": sys.argv[1], "name": "read_report", "arguments": {"record": "staging"}}
headers = {"Authorization": "Bearer " + Path("litellm-virtual.key").read_text().strip(),
           "Content-Type": "application/json"}
with urlopen(Request("http://127.0.0.1:4000/mcp-rest/tools/call", json.dumps(body).encode(), headers)) as response:
    print(response.read().decode())
PY
~~~

The relay strips the broker credential, caller headers and cookies before connecting to the approved origin.

[Stock MCP configuration](https://docs.litellm.ai/docs/mcp_config_reference) · [MCP access controls](https://docs.litellm.ai/docs/proxy/access_management/mcp)
