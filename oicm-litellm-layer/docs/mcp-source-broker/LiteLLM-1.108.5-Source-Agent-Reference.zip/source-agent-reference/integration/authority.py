"""Private, read-only relay projection with a transactional publication example."""
import asyncio
import hmac
import json
import sys
from pathlib import Path

import psycopg
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from psycopg.types.json import Jsonb

SCHEMA = """
CREATE SCHEMA IF NOT EXISTS source_agent_control;
CREATE TABLE IF NOT EXISTS source_agent_control.authority_projection (
    id boolean PRIMARY KEY CHECK (id),
    revision bigint NOT NULL CHECK (revision > 0),
    snapshot jsonb NOT NULL,
    CHECK ((snapshot ->> 'revision')::bigint = revision)
)
"""
MAX_SNAPSHOT = 256 << 10
AGENT_BINARY = Path(__file__).resolve().parents[1] / "bin/source-agent"


class RevisionConflict(ValueError):
    pass


class Projection:
    def __init__(self, dsn, agent_binary=AGENT_BINARY):
        self.dsn = dsn
        self.agent_binary = agent_binary

    async def initialize(self):
        async with await psycopg.AsyncConnection.connect(self.dsn) as connection:
            await connection.execute(SCHEMA)

    async def get(self):
        async with await psycopg.AsyncConnection.connect(self.dsn) as connection:
            row = await (await connection.execute(
                "SELECT snapshot FROM source_agent_control.authority_projection WHERE id")).fetchone()
            return row[0] if row else None

    async def publish(self, expected, snapshot):
        if (type(expected) is not int or not 0 <= expected < 2**63 - 1 or not isinstance(snapshot, dict)
                or type(snapshot.get("revision")) is not int or snapshot["revision"] != expected + 1):
            raise RevisionConflict("next revision must be expected + 1")
        if len(json.dumps(snapshot, separators=(",", ":")).encode()) > MAX_SNAPSHOT:
            raise ValueError("snapshot is too large for the relay")
        async with await psycopg.AsyncConnection.connect(self.dsn) as connection:
            previous = {}
            if expected:
                locked = await (await connection.execute(
                    "SELECT snapshot FROM source_agent_control.authority_projection WHERE id AND revision=%s FOR UPDATE",
                    (expected,))).fetchone()
                if locked is None:
                    raise RevisionConflict("stale authority revision")
                previous = locked[0]
                query = """UPDATE source_agent_control.authority_projection SET revision=%s,snapshot=%s
                           WHERE id AND revision=%s RETURNING revision"""
                params = (expected + 1, Jsonb(snapshot), expected)
            else:
                query = """INSERT INTO source_agent_control.authority_projection(id,revision,snapshot)
                           VALUES (true,1,%s) ON CONFLICT DO NOTHING RETURNING revision"""
                params = (Jsonb(snapshot),)
            await self.validate(previous, snapshot)
            row = await (await connection.execute(query, params)).fetchone()
            if row is None:
                raise RevisionConflict("stale authority revision")
        return row[0]

    async def validate(self, previous, candidate):
        envelope = json.dumps({"previous": previous, "candidate": candidate}, separators=(",", ":")).encode()
        validator = await asyncio.create_subprocess_exec(
            self.agent_binary, "validate-policy", stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)
        try:
            await asyncio.wait_for(validator.communicate(envelope), 3)
        finally:
            if validator.returncode is None:
                validator.kill()
                await validator.wait()
        if validator.returncode:
            raise ValueError("candidate failed the relay's policy and generation validation")


def feed_app(read_snapshot, token, enabled=lambda: True):
    app = FastAPI(openapi_url=None, docs_url=None, redoc_url=None)

    @app.get("/v1/source-agent/desired")
    async def desired(request: Request):
        presented = request.headers.get("authorization", "")
        if not hmac.compare_digest(presented.encode(), f"Bearer {token}".encode()):
            raise HTTPException(401)
        if not enabled():
            raise HTTPException(503)
        snapshot = await read_snapshot()
        if snapshot is None:
            raise HTTPException(503)
        return JSONResponse(snapshot, headers={"Cache-Control": "no-store"})

    return app


async def cli(args):
    dsn = args.dsn_file.read_text().strip()

    if args.command == "publish":
        projection = Projection(dsn, agent_binary=args.source_agent)
        await projection.initialize()
        snapshot = json.loads(args.snapshot.read_text())
        revision = await projection.publish(args.expect, snapshot)
        print(json.dumps({"desired_revision": revision, "apply_state": "awaiting_relay"}))
        return
    import uvicorn

    token = args.feed_token.read_text().strip()
    if len(token) != 43:
        raise ValueError("invalid feed credential")
    await uvicorn.Server(uvicorn.Config(feed_app(Projection(dsn).get, token),
                                        host="127.0.0.1", port=args.port, log_level="warning")).serve()


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dsn-file", type=Path, required=True)
    parser.add_argument("--source-agent", type=Path, default=AGENT_BINARY)
    sub = parser.add_subparsers(dest="command", required=True)
    publish = sub.add_parser("publish")
    publish.add_argument("--expect", type=int, required=True)
    publish.add_argument("--snapshot", type=Path, required=True)
    serve = sub.add_parser("serve")
    serve.add_argument("--feed-token", type=Path, required=True)
    serve.add_argument("--port", type=int, default=9091)
    try:
        asyncio.run(cli(parser.parse_args()))
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(1) from None
