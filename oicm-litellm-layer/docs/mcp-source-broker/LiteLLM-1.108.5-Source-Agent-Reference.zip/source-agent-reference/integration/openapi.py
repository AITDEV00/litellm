"""Project a reviewed OpenAPI document onto an approved channel's private path."""
import argparse
import copy
import json
from pathlib import Path


def validate(doc):
    if not isinstance(doc, dict) or not str(doc.get("openapi", "")).startswith("3.") or not isinstance(doc.get("paths"), dict):
        raise ValueError("expected an OpenAPI 3 JSON document")
    if doc.get("servers"):
        raise ValueError("document servers must come from the registered broker URL")
    def references(value):
        if isinstance(value, dict):
            for key, item in value.items():
                if key == "$ref" and (not isinstance(item, str) or not item.startswith("#/")):
                    raise ValueError("external schema references are not supported by this adapter")
                references(item)
        elif isinstance(value, list):
            for item in value:
                references(item)
    references(doc)
    for entry in doc["paths"].values():
        if not isinstance(entry, dict) or entry.get("servers"):
            raise ValueError("path-level server overrides are unsupported")
        for method in ("get", "post", "put", "patch", "delete", "head", "options", "trace"):
            if method in entry and (not isinstance(entry[method], dict) or entry[method].get("servers")):
                raise ValueError("operation-level server overrides are unsupported")
    return doc


def project(doc, prefix):
    if not prefix.startswith("/") or prefix.endswith("/") or any(c in prefix for c in "?#%\\"):
        raise ValueError("use an explicit non-root origin path prefix")
    doc = copy.deepcopy(validate(doc))
    projected = {}
    for path, operations in doc["paths"].items():
        if path.startswith(prefix + "/"):
            projected[path[len(prefix):]] = operations
    if not projected:
        raise ValueError("nothing matches the approved origin prefix")
    doc["paths"] = projected
    return doc


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("--prefix", required=True)
    args = parser.parse_args()
    print(json.dumps(project(json.loads(args.input.read_text()), args.prefix), indent=2))
