"""Real v1.108.5 + PostgreSQL + source-agent, exercising stock registration, auth and tool calls."""
import asyncio
import copy
import hashlib
import importlib.metadata
import importlib.util
import json
import logging
import os
import secrets
import sys
from datetime import UTC, datetime, timedelta
from pathlib import Path

import httpx
import psycopg

from postgres import start_postgres
from support import BIN, HOST, ROOT, Lab, atomic, port, serve, until
from integration.authority import Projection, RevisionConflict, feed_app
from integration.openapi import project

BLOCKED = "block-source-agent-fixture"


async def register(lab, gateway, keyfile, channel, tool, spec=None, pin=False):
    command = [sys.executable, ROOT / "integration/litellm.py", "--proxy", f"http://{HOST}:{gateway}",
               "--admin-key", keyfile, "--broker-key", lab.data_key,
               "--alias", f"source_agent_{channel}", "--source-url", lab.base(channel),
               "--group", "source-lab-fixture", "--tool", tool]
    if spec:
        command.extend(("--spec", spec))
    if pin:
        command.append("--pin")
    process = await asyncio.create_subprocess_exec(*command, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
    out, err = await asyncio.wait_for(process.communicate(), 45)
    assert process.returncode == 0, err.decode()
    return json.loads(out)


async def main():
    assert importlib.metadata.version("litellm") == "1.108.5"
    async with Lab() as lab:
        dsn = await start_postgres(lab)
        db = Projection(dsn, agent_binary=BIN)
        await db.initialize()
        available = True
        feed_port, proxy_port = port(), port()

        async def publish_initial(fixture):
            assert await db.publish(0, fixture.desired) == 1
            await lab.stack.enter_async_context(serve(feed_app(db.get, lab.auth["feed"], lambda: available), feed_port))
        await lab.setup(feed=f"http://{HOST}:{feed_port}/v1/source-agent/desired", publish=publish_initial)
        await lab.serve_origins()
        await lab.connector()
        await lab.ready("reports")
        await lab.ready("tools")

        schema = Path(os.environ.get("LITELLM_SCHEMA") or
                      Path(importlib.util.find_spec("litellm").origin).parent / "proxy/schema.prisma")
        proxy_key, keyfile = "fixture-admin-" + secrets.token_urlsafe(32), lab.dir / "litellm.key"
        atomic(keyfile, proxy_key)
        config = lab.dir / "proxy.yaml"
        atomic(config, {
            "model_list": [{"model_name": "fixture", "litellm_params": {"model": "openai/fixture",
                            "api_key": "fixture-unused", "api_base": f"http://{HOST}:1/v1"}}],
            "general_settings": {"master_key": proxy_key, "proxy_batch_write_at": 1},
            "guardrails": [{"guardrail_name": "fixture-policy", "litellm_params": {
                "guardrail": "litellm_content_filter", "mode": "pre_mcp_call", "default_on": True,
                "blocked_words": [{"keyword": BLOCKED, "action": "BLOCK"}],
            }}],
        })
        env = {k: v for k, v in os.environ.items() if not k.lower().endswith("_proxy")}
        env.update({"DATABASE_URL": dsn, "CONFIG_FILE_PATH": str(config), "LITELLM_MASTER_KEY": proxy_key,
                    "LITELLM_LOCAL_MODEL_COST_MAP": "True", "LITELLM_TELEMETRY": "False",
                    "DO_NOT_TRACK": "1", "CHECKPOINT_DISABLE": "1", "PRISMA_DISABLE_TELEMETRY": "1",
                    "NPM_CONFIG_OFFLINE": "true", "NPM_CONFIG_UPDATE_NOTIFIER": "false",
                    "LITELLM_DONT_SHOW_FEEDBACK_BOX": "true"})
        migration = await asyncio.create_subprocess_exec(sys.executable, "-m", "prisma", "db", "push",
                    "--skip-generate", "--schema", schema, env=env,
                    stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
        out, _ = await asyncio.wait_for(migration.communicate(), 60)
        assert migration.returncode == 0, out.decode().replace(dsn, "[db]").splitlines()[-6:]
        proxy = await lab.proc("litellm", sys.executable, "-m", "uvicorn", "litellm.proxy.proxy_server:app",
                               "--host", HOST, "--port", str(proxy_port), "--log-level", "warning", env=env)

        async with httpx.AsyncClient(base_url=f"http://{HOST}:{proxy_port}", trust_env=False, timeout=20) as http:
            async def proxy_ready():
                if proxy.returncode is not None:
                    log = (lab.dir / "litellm.log").read_text().replace(dsn, "[db]").replace(proxy_key, "[admin]")
                    raise AssertionError(log[-1800:])
                return (await http.get("/health/liveliness")).status_code == 200
            await until(proxy_ready, seconds=50)
            spec = lab.dir / "reports-v1.json"
            atomic(spec, project(lab.report_app.openapi(), "/reports"))
            report = (await register(lab, proxy_port, keyfile, "reports", "read_report", spec))["server_id"]
            native_registration = await register(lab, proxy_port, keyfile, "tools", "lookup_tool", pin=True)
            native = native_registration["server_id"]
            assert native_registration["pinned_names"] == ["lookup_tool"], native_registration
            assert (await register(lab, proxy_port, keyfile, "reports", "read_report", spec))["server_id"] == report

            async def key(servers):
                r = await http.post("/key/generate", headers={"Authorization": "Bearer " + proxy_key},
                                    json={"models": ["fixture"], "object_permission": {"mcp_servers": servers}})
                assert r.is_success, r.status_code
                return r.json()["key"]

            permit = await key([report, native])
            report_only = await key([report])
            permitted = {"Authorization": "Bearer " + permit}
            restricted = {"Authorization": "Bearer " + report_only}

            async def invoke(server, tool, record, headers=permitted):
                return await http.post("/mcp-rest/tools/call", headers=headers, json={
                    "server_id": server, "name": tool, "arguments": {"record": record}})

            output = await invoke(report, "read_report", "entry")
            assert output.is_success and not output.json().get("isError"), output.text
            assert json.loads(output.json()["content"][0]["text"]) == {"record": "entry", "value": "approved-report"}
            output = await invoke(native, "lookup_tool", "entry")
            assert output.is_success and not output.json().get("isError"), output.text
            assert output.json()["content"][0]["text"] == "native:entry"
            assert (await invoke(native, "lookup_tool", "denied", restricted)).status_code == 403
            assert (await invoke(report, "read_report", BLOCKED)).status_code == 400
            assert BLOCKED not in lab.inspections
            assert (await http.delete(f"/v1/mcp/server/{native}", headers=permitted)).status_code in (401, 403)
            print("PASS actual LiteLLM LTS executed OpenAPI and native MCP on one agent; virtual keys, guardrails, pinned-tool registration and private-header stripping", flush=True)

            approved = copy.deepcopy(lab.desired)
            approved["revision"] = 2
            invalid = {"revision": 2, "agents": []}
            try:
                await db.publish(1, invalid)
            except ValueError as exc:
                assert "policy and generation validation" in str(exc)
            else:
                raise AssertionError("projection discarded the existing authority tombstones")
            assert (await db.get())["revision"] == 1
            async def compete():
                try:
                    return await db.publish(1, approved)
                except RevisionConflict:
                    return "conflict"
            assert set(await asyncio.gather(compete(), compete())) == {2, "conflict"}
            async def loaded(revision):
                s = await lab.observation()
                return s["fresh"] and s["loaded_revision"] == revision
            await until(lambda: loaded(2))

            @lab.mcp.tool(structured_output=False)
            def proposed_tool(record: str) -> str:
                return "new:" + record

            async def quarantined():
                view = await lab.target_status("tools")
                return "catalog differs" in view.get("problem", "")
            await until(quarantined)
            assert (await invoke(native, "lookup_tool", "during-drift")).json().get("isError")
            approved["agents"][0]["channels"][1]["revision"] += 1
            approved["agents"][0]["channels"][1]["catalog_sha256"] = await lab.native_catalog_now()
            approved["revision"] = 3
            await db.publish(2, approved)
            await lab.ready("tools")
            listing = await http.get("/mcp-rest/tools/list", headers=permitted, params={"server_id": native})
            assert listing.is_success and [t["name"] for t in listing.json()["tools"]] == ["lookup_tool"], listing.text
            assert (await invoke(native, "lookup_tool", "republished")).json()["content"][0]["text"] == "native:republished"
            print("PASS live native catalog drift froze the channel. Operator approved a new digest; LiteLLM's pinned catalog and allowlist still hid the proposed tool", flush=True)

            async with await psycopg.AsyncConnection.connect(dsn, autocommit=True) as conn:
                row = await (await conn.execute('SELECT count(*) FROM "LiteLLM_MCPServerTable" WHERE server_id IN (%s,%s)',
                                               (report, native))).fetchone()
                assert row == (2,)
                async def logged():
                    rows = await conn.execute('SELECT count(*) FROM "LiteLLM_SpendLogs" WHERE api_key=%s AND call_type=%s',
                                              (hashlib.sha256(permit.encode()).hexdigest(), "call_mcp_tool"))
                    return (await rows.fetchone())[0] >= 2
                await until(logged, seconds=25)
            print("PASS existing LiteLLM MCP registry rows and spend logs persisted in PostgreSQL", flush=True)

            available = False
            approved["agents"][0]["channels"][0]["phase"] = "revoked"
            approved["revision"] = 4
            assert await db.publish(3, approved) == 4
            assert (await lab.observation())["loaded_revision"] == 3
            async def expired():
                return not (await lab.observation())["fresh"]
            await until(expired, seconds=12)
            assert (await lab.http.get(lab.base("reports", "/lookup?record=after"), headers=lab.data_headers)).status_code == 503
            available = True
            await until(lambda: loaded(4))
            await lab.ready("tools")
            assert (await lab.http.get(lab.base("reports", "/lookup?record=after"), headers=lab.data_headers)).status_code == 503
            await lab.stop(lab.relay_process)
            await lab.relay()
            await until(lambda: loaded(4))
            await lab.ready("tools")
            assert (await lab.http.get(lab.base("reports", "/lookup?record=after"), headers=lab.data_headers)).status_code == 503
            print("PASS durable PostgreSQL CAS, invalid transition rejection, acknowledged-vs-observed mismatch, feed expiry and relay restart reconciled without a notify write", flush=True)


if __name__ == "__main__":
    logging.getLogger().setLevel(logging.WARNING)
    for name in ("httpx", "httpx2", "mcp"):
        logging.getLogger(name).setLevel(logging.WARNING)
    asyncio.run(main())
