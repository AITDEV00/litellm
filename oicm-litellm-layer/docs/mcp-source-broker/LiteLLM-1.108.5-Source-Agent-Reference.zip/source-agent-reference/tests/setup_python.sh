#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname -- "$0")/.."
export CHECKPOINT_DISABLE=1 PRISMA_DISABLE_TELEMETRY=1 DO_NOT_TRACK=1 NPM_CONFIG_UPDATE_NOTIFIER=false
python3 -m venv .venv
export PATH="$PWD/.venv/bin:$PATH"
python -m pip install -r tests/requirements.lock.txt
schema=$(python -c 'from importlib.util import find_spec; from pathlib import Path; print(Path(find_spec("litellm").origin).parent/"proxy/schema.prisma")')
python -m prisma generate --schema "$schema"
