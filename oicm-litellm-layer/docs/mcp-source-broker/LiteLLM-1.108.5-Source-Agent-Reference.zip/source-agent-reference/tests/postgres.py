import os
import secrets
from pathlib import Path
from urllib.parse import quote

from support import HOST, atomic, check, port, until


async def start_postgres(lab):
    override = os.environ.get("PG_BIN")
    if override:
        bin_dir = Path(override)
    else:
        from importlib.util import find_spec
        bin_dir = Path(find_spec("embedded_postgres").origin).parent / "pginstall/bin"
    p = port()
    password = secrets.token_urlsafe(24)
    key = lab.dir / "pg.key"
    atomic(key, password + "\n")
    root = lab.dir / "pg"
    check([bin_dir / "initdb", "-D", root, "-U", "postgres", "--no-sync", "--auth-host=scram-sha-256",
           "--auth-local=trust", "--pwfile", key])
    key.unlink()
    await lab.proc("postgres", bin_dir / "postgres", "-D", root, "-h", HOST, "-p", str(p),
                   "-c", "unix_socket_directories=")
    import psycopg
    dsn = f"postgresql://postgres:{quote(password)}@{HOST}:{p}/postgres"

    async def ready():
        try:
            async with await psycopg.AsyncConnection.connect(dsn, connect_timeout=1) as conn:
                return True
        except psycopg.OperationalError:
            return False

    await until(ready)
    return dsn
