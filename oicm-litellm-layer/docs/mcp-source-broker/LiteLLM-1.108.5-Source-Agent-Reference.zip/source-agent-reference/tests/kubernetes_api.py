"""Real Kubernetes API/etcd + RBAC and mounted inputs. Run in a disposable Linux network namespace."""
import asyncio
import fcntl
import json
import logging
import os
import secrets
import socket
import struct
import sys
from pathlib import Path

import httpx

from support import HOST, ROOT, Lab, atomic, check, port, until
from behavior import check_native


def make_cluster_ips(*addresses):
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        request = struct.pack("16sh22x", b"lo", 0)
        flags = struct.unpack("16sh22x", fcntl.ioctl(sock, 0x8913, request))[1]
        fcntl.ioctl(sock, 0x8914, struct.pack("16sh22x", b"lo", flags | 1))
        for index, ip in enumerate(addresses, 1):
            for op, value in ((0x8916, ip), (0x891c, "255.255.255.255")):
                fcntl.ioctl(sock, op, struct.pack("16sHH4s16x", f"lo:{index}".encode(), socket.AF_INET, 0, socket.inet_aton(value)))


async def main():
    assert not Path("/sys/class/net/eth0").exists(), "run as instructed in a temporary network namespace"
    cluster_ips = {"reports": "10.96.0.27", "tools": "10.96.0.28"}
    make_cluster_ips(*cluster_ips.values())
    binaries = Path(os.environ["KUBEBUILDER_ASSETS"]).resolve()
    assert check([binaries / "kube-apiserver", "--version"]).stdout.strip() == b"Kubernetes v1.35.0"
    async with Lab() as lab:
        api_port, etcd_port, peer_port, origin_port = (port() for _ in range(4))
        etcd, peer = (f"http://{HOST}:{n}" for n in (etcd_port, peer_port))
        await lab.proc("etcd", binaries / "etcd", "--data-dir", lab.dir / "etcd", "--listen-client-urls", etcd,
                       "--advertise-client-urls", etcd, "--listen-peer-urls", peer, "--initial-advertise-peer-urls", peer,
                       "--initial-cluster", f"default={peer}")
        cert, key = lab.dir / "api.crt", lab.dir / "api.key"
        check(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-noenc", "-days", "1", "-subj", "/CN=127.0.0.1",
               "-addext", "subjectAltName=IP:127.0.0.1", "-out", cert, "-keyout", key])
        signer = lab.dir / "service-account.key"
        check(["openssl", "genpkey", "-algorithm", "RSA", "-pkeyopt", "rsa_keygen_bits:2048", "-out", signer])
        keys = lab.dir / "bootstrap.csv"
        admin = secrets.token_urlsafe(32)
        atomic(keys, f'{admin},fixture-admin,fixture-admin,system:masters\n')
        aid = "https://kubernetes.default.svc"
        api = f"https://{HOST}:{api_port}"
        await lab.proc("kube-apiserver", binaries / "kube-apiserver", f"--secure-port={api_port}",
                       f"--bind-address={HOST}", f"--advertise-address={HOST}", f"--etcd-servers={etcd}",
                       f"--tls-cert-file={cert}", f"--tls-private-key-file={key}", f"--token-auth-file={keys}",
                       "--anonymous-auth=false", "--authorization-mode=RBAC", "--service-cluster-ip-range=10.96.0.0/24",
                       f"--service-account-issuer={aid}", f"--api-audiences={aid}", f"--service-account-key-file={signer}",
                       f"--service-account-signing-key-file={signer}", "--profiling=false")
        cfg = lab.dir / "kubectl.json"
        atomic(cfg, {"apiVersion": "v1", "kind": "Config", "current-context": "fixture",
                     "clusters": [{"name": "api", "cluster": {"server": api, "certificate-authority": str(cert)}}],
                     "users": [{"name": "admin", "user": {"token": admin}}],
                     "contexts": [{"name": "fixture", "context": {"cluster": "api", "user": "admin"}}]})
        ctl = [binaries / "kubectl", "--kubeconfig", cfg]

        async def api_ready():
            async with httpx.AsyncClient(verify=str(cert), trust_env=False, timeout=1) as client:
                return (await client.get(api + "/readyz", headers={"Authorization": "Bearer " + admin})).status_code == 200
        await until(api_ready, seconds=55)

        async def kubectl(*args, **kwargs):
            return await asyncio.to_thread(check, [*ctl, *args], **kwargs)

        await kubectl("apply", "-f", ROOT / "source-agent/kubernetes/rbac.yaml")
        release = ROOT / "bin/release.json"
        if release.is_file():
            digest = json.loads(release.read_text())["oci_manifest_digest"]
            rendered = check([sys.executable, ROOT / "source-agent/kubernetes/render.py",
                              "--image", f"registry.example.test/litellm/source-agent@{digest}",
                              "--gateway-ip", "192.0.2.11/32", "--apiserver-ip", "10.96.0.1/32"]).stdout
            preview = await kubectl("apply", "--dry-run=server", "-f", "-", input=rendered)
            assert b"deployment.apps/source-agent" in preview.stdout
            assert b"networkpolicy.networking.k8s.io/" in preview.stdout
            print("PASS Kubernetes API accepted the digest-pinned Deployment and NetworkPolicy via server-side dry run", flush=True)
        services = []
        for name in ("reports", "tools", "unapproved"):
            record = {"apiVersion": "v1", "kind": "Service",
                      "metadata": {"name": name, "namespace": "source-lab",
                                   "annotations": {"source-agent.example.org/target": name}},
                      "spec": {"type": "ClusterIP", "selector": {"fixture": name},
                               "ports": [{"name": "http", "protocol": "TCP", "port": origin_port}]}}
            if name in cluster_ips:
                record["spec"]["clusterIP"] = cluster_ips[name]
            services.append(record)
        await kubectl("apply", "-f", "-", input=json.dumps({"apiVersion": "v1", "kind": "List", "items": services}).encode())
        live = {name: json.loads((await kubectl("-n", "source-lab", "get", "service", name, "-o", "json")).stdout)
                for name in cluster_ips}
        projected = lab.dir / "projected"
        projected.mkdir()
        token_file = projected / "token"

        async def mint():
            text = (await kubectl("-n", "source-lab", "create", "token", "source-agent",
                                  "--duration=15m", f"--audience={aid}")).stdout.decode().strip()
            atomic(token_file, text)
            return text
        token = await mint()
        async with httpx.AsyncClient(verify=str(cert), trust_env=False, headers={"Authorization": f"Bearer {token}"}) as restricted:
            for path, code in [
                ("/api/v1/namespaces/source-lab/services/reports", 200),
                ("/api/v1/namespaces/source-lab/services/tools", 200),
                ("/api/v1/namespaces/source-lab/services/unapproved", 403),
                ("/api/v1/namespaces/source-lab/services", 403),
                ("/api/v1/namespaces/source-lab/services?watch=true", 403),
                ("/api/v1/namespaces/source-lab/pods", 403),
                ("/api/v1/namespaces/source-lab/secrets", 403),
                ("/apis/discovery.k8s.io/v1/namespaces/source-lab/endpointslices", 403),
                ("/api/v1/namespaces/default/services/kubernetes", 403),
            ]:
                assert (await restricted.get(api + path)).status_code == code, path
            assert (await restricted.patch(api + "/api/v1/namespaces/source-lab/services/reports", json={})).status_code == 403
        print("PASS Kubernetes v1.35.0 authenticated an expiring ServiceAccount token, allowed both named GETs and denied cross-namespace/list/watch/patch/pods/secrets/EndpointSlices", flush=True)

        await lab.setup(descriptor_overrides={name: {"service": {"namespace": "source-lab", "name": name,
            "uid": service["metadata"]["uid"], "port_name": "http", "port": origin_port, "cidr": "10.96.0.0/24"}}
            for name, service in live.items()})
        await lab.serve_origins(*cluster_ips.values())
        args = ("-read-only", "-kube-api", api, "-kube-namespace", "source-lab", "-kube-token", token_file, "-kube-ca", cert)
        first = await lab.connector("mounted-agent", *args)
        await lab.ready("reports")
        await lab.ready("tools")
        await check_native(lab, modern=True)
        result = await lab.http.get(lab.base("reports", "/lookup?record=cluster"), headers=lab.data_headers)
        assert result.status_code == 200, result.text
        readonly = await lab.control_request("PUT", "desired", json={"expected_revision": 1, "enabled": []})
        assert readonly.status_code == 405
        print("PASS mounted AgentState and separate credential used WSS to the relay and ClusterIP HTTP to both approved Services", flush=True)

        await lab.stop(first)
        await mint()
        await lab.connector("replacement-agent", *args)
        await lab.ready("reports")
        assert (await lab.http.get(lab.base("reports", "/lookup?record=rejoin"), headers=lab.data_headers)).status_code == 200
        patch = '{"metadata":{"annotations":{"source-agent.example.org/target":"withdrawn"}}}'
        await kubectl("-n", "source-lab", "patch", "service", "reports", "--type=merge", "-p", patch)
        async def gone():
            response = await lab.http.get(lab.base("reports", "/lookup?record=gone"), headers=lab.data_headers)
            return response.status_code == 503
        await until(gone)
        await check_native(lab, modern=True)
        print("PASS replacement process rejoined with the same broker identity and refreshed Kubernetes token; annotation withdrawal removed the route", flush=True)


if __name__ == "__main__":
    logging.getLogger().setLevel(logging.WARNING)
    for name in ("httpx", "httpx2", "mcp"):
        logging.getLogger(name).setLevel(logging.WARNING)
    asyncio.run(main())
