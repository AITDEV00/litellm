"""Verify the exact signed release, OCI contents and restricted download routes."""
import asyncio
import base64
import gzip
import hashlib
import io
import json
import os
import shutil
import ssl
import subprocess
import tarfile

import httpx

from support import CADDY, HOST, ROOT, Lab, check, port, until


def inspect_oci(path, binary, declared_digest):
    with tarfile.open(path, "r:") as oci:
        def load(name):
            with oci.extractfile(name) as reader:
                return reader.read()

        def blob(descriptor):
            algorithm, digest = descriptor["digest"].split(":")
            assert algorithm == "sha256"
            data = load(f"blobs/sha256/{digest}")
            assert len(data) == descriptor["size"] and hashlib.sha256(data).hexdigest() == digest
            return data

        index = json.loads(load("index.json"))
        assert json.loads(load("oci-layout")) == {"imageLayoutVersion": "1.0.0"}
        row, = index["manifests"]
        assert row["digest"] == declared_digest
        manifest = json.loads(blob(row))
        cfg = json.loads(blob(manifest["config"]))
        assert (cfg["os"], cfg["architecture"], cfg["config"]["User"]) == ("linux", "amd64", "10001:10001")
        assert cfg["config"]["Entrypoint"] == ["/source-agent"]
        layer, = manifest["layers"]
        plain = gzip.decompress(blob(layer))
        assert cfg["rootfs"]["diff_ids"] == ["sha256:" + hashlib.sha256(plain).hexdigest()]
        with tarfile.open(fileobj=io.BytesIO(plain), mode="r:") as layer:
            member, = layer.getmembers()
            assert member.name == "source-agent" and member.mode == 0o755 and member.uid == 10001
            assert layer.extractfile(member).read() == binary


async def main():
    release = ROOT / "bin"
    binary, manifest, sig = (release / name for name in ("source-agent", "release.json", "release.sig.b64"))
    async with Lab() as lab:
        detached = lab.dir / "signature"
        detached.write_bytes(base64.b64decode(sig.read_bytes()))
        check(["openssl", "pkeyutl", "-verify", "-pubin", "-inkey", release / "release-public.pem", "-sigfile", detached,
               "-rawin", "-in", manifest])
        verify = [binary, "verify", "-signature", sig, "-trust-key", release / "release-public.b64"]
        check([*verify, "-manifest", manifest, "-binary", binary])
        original = json.loads(manifest.read_text())
        damaged = lab.dir / "tampered.json"
        damaged.write_text(manifest.read_text().replace("0.1.0", "0.1.1"))
        failure = subprocess.run([*verify, "-manifest", damaged, "-binary", binary], capture_output=True, timeout=5)
        assert failure.returncode and b"signature" in failure.stderr.lower()
        changed = lab.dir / "tampered-executable"
        changed.write_bytes(binary.read_bytes() + b"x")
        failure = subprocess.run([*verify, "-manifest", manifest, "-binary", changed], capture_output=True, timeout=5)
        assert failure.returncode and b"digest" in failure.stderr.lower()
        print("PASS OpenSSL and trusted verifier accepted the signed release and rejected modified manifests and executables", flush=True)

        inspect_oci(release / "source-agent-linux-amd64.oci.tar", binary.read_bytes(), original["oci_manifest_digest"])
        print("PASS OCI digest, config, nonroot entrypoint and executable matched the signed release", flush=True)

        assets = lab.dir / "release"
        assets.mkdir()
        for item in (binary, manifest, sig):
            shutil.copyfile(item, assets / item.name)
        (assets / "private-fixture").touch()
        cert, key = lab.dir / "cert", lab.dir / "key"
        check(["openssl", "req", "-x509", "-newkey", "ed25519", "-noenc", "-days", "1", "-subj", "/CN=127.0.0.1",
               "-addext", "subjectAltName=IP:127.0.0.1", "-out", cert, "-keyout", key])
        listener = port()
        config = lab.dir / "Caddyfile"
        config.write_text(f"""{{
    admin off
    auto_https off
}}
https://{HOST}:{listener} {{
    tls {cert} {key}
    import {ROOT / 'examples/Caddyfile.release'}
    handle {{
        respond 404
    }}
}}
""")
        await lab.proc("release-caddy", CADDY, "run", "--config", config,
                       env={**os.environ, "SOURCE_AGENT_RELEASE_DIR": str(assets),
                            "XDG_CONFIG_HOME": str(lab.dir / "config"), "XDG_DATA_HOME": str(lab.dir / "caddy")})
        tls = ssl.create_default_context(cafile=str(cert))
        async with httpx.AsyncClient(base_url=f"https://{HOST}:{listener}/source-agent/releases/0.1.0/",
                                    trust_env=False, verify=tls, timeout=4) as http:
            async def ready():
                return (await http.get("release.json")).status_code == 200
            await until(ready)
            response = await http.get("source-agent")
            assert response.status_code == 200
            assert hashlib.sha256(response.content).hexdigest() == original["sha256"]
            assert (await http.get("release.sig.b64")).content == sig.read_bytes()
            assert (await http.get("private-fixture")).status_code == 404
            assert (await http.post("source-agent")).status_code == 404
        print("PASS TLS download served the exact signed artifacts and denied unlisted files and methods", flush=True)


if __name__ == "__main__":
    asyncio.run(main())
