"""Fetch exact upstream lab binaries with digest validation."""
import argparse
import hashlib
import subprocess
import tempfile
from pathlib import Path

PINS = {
    "go": ("https://go.dev/dl/go1.27.4.linux-amd64.tar.gz",
           "7226736c2339719cda28fbf3a54d71aa63bcefe376e98cef00034268dab24840"),
    "caddy": ("https://github.com/caddyserver/caddy/releases/download/v2.11.9/caddy_2.11.9_linux_amd64.tar.gz",
              "5b8cb7faf8726a2028ad96a66e54e6e81e8f361bc6175e5d22bbd997cc5177fb"),
    "kubernetes": ("https://github.com/kubernetes-sigs/controller-tools/releases/download/envtest-v1.35.0/envtest-v1.35.0-linux-amd64.tar.gz",
                   "5716719def14a3fec3ed285e5e8c4280e6268854039b5073a96e8c0adafb1c02"),
    "frp": ("https://github.com/fatedier/frp/releases/download/v0.72.0/frp_0.72.0_linux_amd64.tar.gz",
            "daf719b32ca2778770bb92955e231a07414d754378b9af328aa2642862479804"),
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("components", nargs="+", choices=sorted(PINS))
    parser.add_argument("--out", type=Path, default=Path(".lab-tools"))
    parser.add_argument("--archives", type=Path)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as work:
        for case in args.components:
            url, digest = PINS[case]
            filename = url.rsplit("/", 1)[-1]
            if args.archives:
                archive = args.archives / filename
            else:
                archive = Path(work) / filename
                subprocess.run(["curl", "-fLsS", "--proto", "=https", "--proto-redir", "=https", "--max-time", "120",
                                url, "-o", archive], check=True)
            with archive.open("rb") as data:
                if hashlib.file_digest(data, "sha256").hexdigest() != digest:
                    raise SystemExit(f"archive digest mismatch for {case}")
            subprocess.run(["tar", "-xzf", archive, "-C", args.out], check=True)
            print(f"{case} verified and extracted into {args.out}")


if __name__ == "__main__":
    main()
