import asyncio
import base64
import copy
import hashlib
import json
import os
import secrets
import socket
import ssl
import subprocess
import sys
import tempfile
import time
from contextlib import AsyncExitStack, asynccontextmanager
from pathlib import Path

import httpx
import uvicorn
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

ROOT = Path(__file__).resolve().parents[1]
BIN = Path(os.environ.get("SOURCE_AGENT", ROOT / "bin/source-agent")).resolve()
CADDY = Path(os.environ.get("CADDY", "caddy"))
HOST = "127.0.0.1"
sys.path.insert(0, str(ROOT))
from examples.origins import native_origin, openapi_origin, json_digest

VERSION = "source-agent.example.org/v1alpha1"


def port(host=HOST):
    with socket.socket() as sock:
        sock.bind((host, 0))
        return sock.getsockname()[1]


def atomic(path, value):
    data = value if isinstance(value, str) else json.dumps(value)
    with tempfile.NamedTemporaryFile(dir=path.parent, mode="w", delete=False) as temp:
        temp.write(data)
        temp_path = Path(temp.name)
    temp_path.replace(path)


def check(args, **kwargs):
    return subprocess.run(args, capture_output=True, check=True, timeout=20, **kwargs)


async def until(test, seconds=20):
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        try:
            if value := await test():
                return value
        except (OSError, httpx.TransportError):
            pass
        await asyncio.sleep(0.035)
    raise AssertionError("timed out waiting for condition")


@asynccontextmanager
async def serve(app, port_number, host=HOST):
    config = uvicorn.Config(app, host=host, port=port_number, log_level="error", timeout_graceful_shutdown=2)
    server = uvicorn.Server(config)
    task = asyncio.create_task(server.serve())
    try:
        async with asyncio.timeout(8):
            while not server.started:
                if task.done():
                    await task
                    raise RuntimeError("fixture server failed to bind")
                await asyncio.sleep(0.02)
        yield
    finally:
        server.should_exit = True
        await asyncio.wait_for(task, 6)


class Lab:
    async def __aenter__(self):
        self.stack = AsyncExitStack()
        await self.stack.__aenter__()
        self.dir = Path(self.stack.enter_context(tempfile.TemporaryDirectory(prefix="source-agent-lab-")))
        self.http = await self.stack.enter_async_context(httpx.AsyncClient(timeout=3, trust_env=False))
        self.processes = {}
        return self

    async def __aexit__(self, *args):
        if args[0]:
            for name, process in self.processes.items():
                if process.returncode is not None:
                    print(f"{name} exited ({process.returncode}); log sanitized and withheld", file=sys.stderr)
        await self.stack.__aexit__(*args)

    async def proc(self, name, *args, **options):
        log = self.stack.enter_context((self.dir / f"{name}.log").open("w"))
        process = await asyncio.create_subprocess_exec(*args, stdout=log, stderr=log, **options)
        self.processes[name] = process
        self.stack.push_async_callback(self.stop, process)
        return process

    @staticmethod
    async def stop(process):
        if process.returncode is None:
            process.terminate()
            try:
                await asyncio.wait_for(process.wait(), 4)
            except TimeoutError:
                process.kill()
                await process.wait()

    async def setup(self, descriptor_overrides=None, feed=None, single=False, publish=None):
        self.auth = {name: secrets.token_urlsafe(32) for name in ("agent", "data", "control", "feed")}
        self.agent = "site-one"
        self.data, self.worker, self.ingress, self.control, self.origin_http, self.origin_native = [port() for _ in range(6)]
        self.cert, self.key = self.dir / "tls.pem", self.dir / "tls.key"
        check(["openssl", "req", "-x509", "-newkey", "ed25519", "-noenc", "-days", "1", "-subj", "/CN=127.0.0.1",
               "-addext", "subjectAltName=IP:127.0.0.1", "-out", self.cert, "-keyout", self.key])
        self.tls = ssl.create_default_context(cafile=str(self.cert))
        descriptors = [
            {"id": "reports", "kind": "openapi", "address": f"{HOST}:{self.origin_http}", "path": "/reports",
             "proof_path": "/proof", "parallel": 1, "methods": ["GET"]},
            {"id": "tools", "kind": "mcp", "address": f"{HOST}:{self.origin_native}", "path": "/mcp",
             "proof_path": "/proof", "parallel": 4},
        ]
        for d in descriptors:
            if descriptor_overrides and d["id"] in descriptor_overrides:
                d.pop("address", None)
                d.update(descriptor_overrides[d["id"]])
        if single:
            descriptors = descriptors[:1]
        self.descriptors = descriptors
        self.state = {"apiVersion": VERSION, "kind": "AgentState", "revision": 1,
                      "enabled": [d["id"] for d in descriptors]}
        self.policy = {"apiVersion": VERSION, "kind": "TargetPolicy", "targets": descriptors}
        self.gate = asyncio.Event()
        self.inspections = []
        self.digest_overrides = {}
        keys = [Ed25519PrivateKey.generate(), Ed25519PrivateKey.generate()]
        self.report_app = openapi_origin(keys[0], self.agent, self.gate, self.digest_overrides, self.inspections)
        self.native_gate = asyncio.Event()
        origin_host = descriptors[-1].get("service")
        native_host = (origin_host["name"] + "." + origin_host["namespace"] + ".svc"
                       if origin_host else f"{HOST}:{self.origin_native}")
        self.native_app, native_catalog, self.mcp = native_origin(keys[1], self.agent, gate=self.native_gate,
                                                                 origin_host=native_host)
        self.catalog = json_digest(self.report_app.openapi())
        self.native_catalog = await native_catalog()
        self.native_catalog_now = native_catalog
        admitted = [{"descriptor": copy.deepcopy(d), "revision": 1, "phase": "active",
                     "catalog_sha256": catalogue, "proof_key": base64.b64encode(key.public_key().public_bytes_raw()).decode()}
                    for d, catalogue, key in zip(descriptors, (self.catalog, self.native_catalog), keys)]
        self.desired = {"revision": 1, "agents": [{"id": self.agent, "epoch": 1, "phase": "active",
                         "credential_sha256": hashlib.sha256(self.auth["agent"].encode()).hexdigest(),
                         "channels": admitted}]}
        self.projection = self.dir / "approval.yaml"
        self.identity = self.dir / "identity.yaml"
        self.credentials = self.dir / "credential.yaml"
        self.policy_file = self.dir / "targets.yaml"
        self.state_file = self.dir / "state.yaml"
        self.data_key = self.dir / "data.key"
        self.control_key = self.dir / "control.key"
        self.feed_key = self.dir / "feed.key"
        for path, value in ((self.projection, self.desired),
                            (self.identity, {"agent": self.agent, "endpoint": f"wss://{HOST}:{self.ingress}/mcp-source-agent",
                                             "ca_file": str(self.cert)}),
                            (self.credentials, {"epoch": 1, "token": self.auth["agent"]}),
                            (self.policy_file, self.policy), (self.state_file, self.state),
                            (self.data_key, self.auth["data"]), (self.control_key, self.auth["control"]),
                            (self.feed_key, self.auth["feed"])):
            atomic(path, value)

        config = self.dir / "Caddyfile"
        config.write_text(f"""{{ 
    admin off
    auto_https off
}}
https://{HOST}:{self.ingress} {{
    bind {HOST}
    tls {self.cert} {self.key}
    handle /mcp-source-agent {{
        reverse_proxy {HOST}:{self.worker}
    }}
    handle {{
        respond 404
    }}
}}
""")
        caddy = str(CADDY.resolve()) if CADDY.exists() else str(CADDY)
        await self.proc("caddy", caddy, "run", "--config", config, "--adapter", "caddyfile",
                        env={**os.environ, "XDG_CONFIG_HOME": str(self.dir), "XDG_DATA_HOME": str(self.dir)})
        self.feed_spec = ("-policy", self.projection) if feed is None else ("-feed", feed, "-feed-token", self.feed_key)
        if publish is not None:
            await publish(self)
        await self.relay()

    async def relay(self):
        self.relay_process = await self.proc("relay", BIN, "relay", *self.feed_spec, "-worker", f"{HOST}:{self.worker}",
                                             "-data", f"{HOST}:{self.data}", "-data-token", self.data_key)
        await until(lambda: self.readyz())

    async def readyz(self):
        response = await self.http.get(f"http://{HOST}:{self.data}/readyz")
        return response.status_code == 204

    async def serve_origins(self, address=HOST, native_address=HOST):
        if address != HOST:
            self.origin_http = self.descriptors[0]["service"]["port"]
        await self.stack.enter_async_context(serve(self.report_app, self.origin_http, address))
        if len(self.descriptors) > 1:
            if native_address != HOST:
                self.origin_native = self.descriptors[1]["service"]["port"]
            await self.stack.enter_async_context(serve(self.native_app, self.origin_native, native_address))

    async def connector(self, name="agent", *flags):
        return await self.proc(name, BIN, "run", "-identity", self.identity, "-credential", self.credentials,
                               "-policy", self.policy_file, "-state", self.state_file,
                               "-control", f"{HOST}:{self.control}", "-control-token", self.control_key, *flags)

    def base(self, channel, rest=""):
        return f"http://{HOST}:{self.data}/sources/{self.agent}/{channel}{rest}"

    @property
    def data_headers(self):
        return {"X-Source-Broker-Key": self.auth["data"]}

    async def control_request(self, method="GET", path="status", **kwargs):
        return await self.http.request(method, f"http://{HOST}:{self.control}/v1/{path}",
                                       headers={"Authorization": f"Bearer {self.auth['control']}"}, **kwargs)

    async def observation(self):
        r = await self.http.get(f"http://{HOST}:{self.data}/v1/observed", headers=self.data_headers)
        r.raise_for_status()
        return r.json()

    async def target_status(self, target):
        state = await self.observation()
        return next((x for x in state["attached"].get(self.agent, {}).get("targets") or [] if x["id"] == target), {})

    async def ready(self, target, want=True):
        return await until(lambda: self._ready(target, want))

    async def _ready(self, target, want):
        status = await self.target_status(target)
        return status if status.get("ready") is want else None

    def update(self):
        self.desired["revision"] += 1
        atomic(self.projection, self.desired)
