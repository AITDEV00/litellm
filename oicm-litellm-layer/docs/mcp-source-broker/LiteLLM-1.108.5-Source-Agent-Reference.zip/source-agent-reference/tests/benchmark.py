import asyncio
import base64
import copy
import hashlib
import json
import logging
import statistics
import time

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from support import HOST, Lab, atomic, json_digest, openapi_origin, port, serve, until


async def measure(lab, url, headers):
    count = 64
    samples = []
    for i in range(count + 3):
        start = time.perf_counter()
        resp = await lab.http.get(url, params={"record": "bench"}, headers=headers)
        assert resp.status_code == 200, resp.status_code
        if i >= 3:
            samples.append((time.perf_counter() - start) * 1000)
    return {"p50_ms": round(statistics.median(samples), 3), "p95_ms": round(sorted(samples)[60], 3),
            "requests": count}


async def trial(num):
    async with Lab() as lab:
        await lab.setup(single=True)
        await lab.serve_origins()
        for i in range(1, num):
            label = f"fixture-{i}"
            listener = port()
            key = Ed25519PrivateKey.generate()
            app = openapi_origin(key, lab.agent, lab.gate, lab.digest_overrides, [], target=label)
            await lab.stack.enter_async_context(serve(app, listener))
            desc = {**lab.descriptors[0], "id": label, "address": f"{HOST}:{listener}"}
            lab.state["enabled"].append(label)
            lab.descriptors.append(desc)
            lab.desired["agents"][0]["channels"].append({"descriptor": copy.deepcopy(desc), "revision": 1, "phase": "active",
                "catalog_sha256": json_digest(app.openapi()), "proof_key": base64.b64encode(key.public_key().public_bytes_raw()).decode()})
        lab.state["revision"] += 1
        atomic(lab.policy_file, lab.policy)
        atomic(lab.state_file, lab.state)
        lab.update()
        start = time.perf_counter()
        process = await lab.connector()
        await asyncio.gather(*(lab.ready(t) for t in lab.state["enabled"]))
        all_ready = round((time.perf_counter() - start) * 1000)
        baseline = await measure(lab, f"http://{HOST}:{lab.origin_http}/reports/lookup", {})
        muxed = await measure(lab, lab.base("reports", "/lookup"), lab.data_headers)
        before = time.perf_counter()
        lab.digest_overrides["reports"] = hashlib.sha256(b"wrong digest").hexdigest()
        await lab.ready("reports", False)
        detected = round((time.perf_counter() - before) * 1000)
        siblings = lab.state["enabled"][1:]

        async def check_sibling(target):
            assert (await lab.target_status(target))["ready"]
            response = await lab.http.get(lab.base(target, "/lookup?record=works"), headers=lab.data_headers)
            assert response.status_code == 200

        await asyncio.gather(*map(check_sibling, siblings))
        lab.digest_overrides.clear()
        await lab.ready("reports")
        await lab.stop(process)
        started = time.perf_counter()
        await lab.connector("restarted")
        await asyncio.gather(*(lab.ready(t) for t in lab.state["enabled"]))
        print(json.dumps({"channels": num, "sibling_calls_during_failure": len(siblings),
            "initial_ready_ms": all_ready, "process_rejoin_ready_ms": round(
            (time.perf_counter() - started) * 1000), "detect_catalog_mismatch_ms": detected, "direct": baseline,
            "wss_broker": muxed, "p50_delta_ms": round(muxed["p50_ms"] - baseline["p50_ms"], 3)}), flush=True)


async def main():
    for size in (1, 2, 10):
        for _ in range(3):
            await trial(size)


if __name__ == "__main__":
    logging.getLogger().setLevel(logging.WARNING)
    for name in ("httpx", "httpx2", "mcp"):
        logging.getLogger(name).setLevel(logging.WARNING)
    asyncio.run(main())
