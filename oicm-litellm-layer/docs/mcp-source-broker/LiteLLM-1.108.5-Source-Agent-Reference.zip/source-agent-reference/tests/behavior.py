import asyncio
import hashlib
import json
import logging
import secrets
import time
from datetime import UTC, datetime, timedelta

import httpx
import httpx2
from mcp import ClientSession
from mcp.client.streamable_http import streamable_http_client
from websockets.asyncio.client import connect
from websockets.exceptions import InvalidStatus

from support import BIN, HOST, Lab, atomic, until


async def check_native(lab, modern=False):
    session_headers = []

    async def inspect(response):
        if value := response.headers.get("Mcp-Session-Id"):
            session_headers.append(value)

    async with httpx2.AsyncClient(headers=lab.data_headers, trust_env=False, timeout=8,
                                 event_hooks={"response": [inspect]}) as http:
        async with streamable_http_client(lab.base("tools"), http_client=http, terminate_on_close=False) as streams:
            async with ClientSession(*streams) as session:
                if modern:
                    result = await session.discover()
                    session.adopt(result)
                else:
                    result = await session.initialize()
                    assert result.protocol_version == "2025-11-25", result
                listed = await session.list_tools()
                assert [tool.name for tool in listed.tools] == ["lookup_tool"]
                response = await session.call_tool("lookup_tool", {"record": "part-7"})
                assert response.content[0].text == "native:part-7", response
    assert bool(session_headers) is not modern
    return session_headers[0] if session_headers else None


async def request_report(lab, record="entry"):
    return await lab.http.get(lab.base("reports", "/lookup"), params={"record": record},
                              headers={**lab.data_headers, "Authorization": "Bearer fixture-only",
                                       "Cookie": "fixture=private", "X-Api-Key": "fixture-only"}, timeout=12)


async def inflight(lab, channel):
    return (await lab.target_status(channel)).get("in_flight") == 1


async def route_phase(lab, channel, want):
    return (await lab.target_status(channel)).get("phase") == want


async def ready_control(lab):
    return (await lab.control_request()).is_success


async def main():
    async with Lab() as lab:
        pending = []

        async def approve_reports_first(fixture):
            pending.append(fixture.desired["agents"][0]["channels"].pop())
            atomic(fixture.projection, fixture.desired)

        await lab.setup(publish=approve_reports_first)
        await lab.serve_origins()
        grants = lab.desired["agents"][0]["channels"]
        tool, = pending
        process = await lab.connector()
        await lab.ready("reports")
        await until(lambda: route_phase(lab, "tools", "awaiting_approval"))
        attach = (await lab.observation())["attached"][lab.agent]["attached_at_unix_ms"]
        assert (await lab.http.get(lab.base("reports", "/lookup"), params={"record": "x"})).status_code == 401
        await until(lambda: ready_control(lab))
        applied = await lab.control_request("PUT", "desired", json={"expected_revision": 1, "enabled": ["reports", "tools"]})
        assert applied.status_code == 200 and applied.json()["revision"] == 1
        assert (await lab.control_request("PUT", "desired", json={"expected_revision": 0, "enabled": ["reports"]})).status_code == 409
        assert (await lab.control_request("PUT", "desired", json={"expected_revision": 1, "enabled": ["unapproved"]})).status_code == 422
        assert (await lab.control_request("PUT", "desired", json={"expected_revision": 1, "enabled": ["tools", "tools"]})).status_code == 422
        assert (await lab.http.get(f"http://{HOST}:{lab.control}/v1/status")).status_code == 401
        async def local_knows_pending():
            reply = (await lab.control_request()).json()
            return any(t["id"] == "tools" and t["phase"] == "awaiting_approval" for t in (reply["observed"] or []))
        await until(local_knows_pending)
        tui = await asyncio.create_subprocess_exec(BIN, "tui", "-url", f"http://{HOST}:{lab.control}",
             "-token-file", lab.control_key, stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE,
             stderr=asyncio.subprocess.PIPE)
        output, _ = await asyncio.wait_for(tui.communicate(b"q\n"), 8)
        assert tui.returncode == 0 and b"awaiting_approval" in output and lab.auth["agent"].encode() not in output
        for line in output.decode().splitlines():
            if line.strip():
                print("TUI", line)
        print("PASS local API CAS, idempotence, credential boundary and review-gated publication", flush=True)
        grants.append(tool)
        lab.update()
        await lab.ready("tools")
        duplicate = {"Authorization": "Bearer " + lab.auth["agent"], "X-Source-Agent": lab.agent, "X-Source-Epoch": "1"}
        try:
            async with connect(f"wss://{HOST}:{lab.ingress}/mcp-source-agent", ssl=lab.tls, proxy=None,
                               subprotocols=["source-agent.v1"], additional_headers=duplicate):
                raise AssertionError("duplicate connector attached")
        except InvalidStatus as err:
            assert err.response.status_code == 409

        assert (await request_report(lab)).json()["value"] == "approved-report"
        session_id = await check_native(lab)
        await check_native(lab, modern=True)
        assert (await lab.observation())["attached"][lab.agent]["attached_at_unix_ms"] == attach
        print("PASS real FastAPI plus official MCP SDK legacy and modern modes used two approvals on the same WSS", flush=True)

        for _ in range(128):
            response = await request_report(lab, "burst")
            assert response.status_code == 200, response.status_code
        print("PASS 128 back-to-back calls at one-slot capacity while probes remained active", flush=True)

        long = asyncio.create_task(request_report(lab, "hold"))
        await until(lambda: inflight(lab, "reports"))
        assert (await request_report(lab, "busy")).status_code == 503
        before = time.perf_counter()
        await check_native(lab, modern=True)
        print(f"PASS saturated reports left native MCP responsive in {(time.perf_counter()-before)*1000:.0f} ms", flush=True)

        grants[0]["phase"] = "draining"
        grants[0]["drain_until"] = (datetime.now(UTC) + timedelta(seconds=20)).isoformat().replace("+00:00", "Z")
        lab.update()
        await until(lambda: route_phase(lab, "reports", "draining"))
        assert not long.done() and (await request_report(lab, "new")).status_code == 503
        lab.gate.set()
        assert (await long).status_code == 200
        assert lab.inspections.count("hold") == 1
        print("PASS drain allowed an existing call to complete and rejected new calls", flush=True)

        grants[0]["phase"] = "active"
        grants[0].pop("drain_until")
        lab.update()
        await lab.ready("reports")
        original = grants[0]["catalog_sha256"]
        changed = hashlib.sha256(b"fixture catalog v2").hexdigest()
        start = time.perf_counter()
        lab.digest_overrides["reports"] = changed
        failed = await lab.ready("reports", False)
        assert "catalog differs" in failed["problem"]
        print(f"PASS incompatible signed catalog quarantined in {(time.perf_counter()-start)*1000:.0f} ms", flush=True)
        assert (await request_report(lab, "mismatch")).status_code == 503
        for catalog in (changed, original):
            grants[0]["revision"] += 1
            grants[0]["catalog_sha256"] = catalog
            lab.digest_overrides["reports"] = catalog
            lab.update()
            await until(lambda: exact_revision(lab, grants[0]["revision"]))
        assert process.returncode is None
        assert (await lab.observation())["attached"][lab.agent]["attached_at_unix_ms"] == attach
        print("PASS catalog approval and rollback preserved the connector process, credential and WebSocket", flush=True)

        # A local change cannot retain central approval, even with healthy network access.
        lab.policy["targets"][0]["address"] = lab.policy["targets"][1]["address"]
        atomic(lab.policy_file, lab.policy)
        await until(lambda: route_phase(lab, "reports", "descriptor_mismatch"))
        assert (await request_report(lab)).status_code == 503
        lab.policy["targets"][0]["address"] = grants[0]["descriptor"]["address"]
        atomic(lab.policy_file, lab.policy)
        await lab.ready("reports")
        assert (await lab.observation())["attached"][lab.agent]["attached_at_unix_ms"] == attach

        # Cancel a real upstream legacy MCP request before its tool sends a result.
        held_tool = asyncio.create_task(lab.http.post(lab.base("tools"), headers={
            **lab.data_headers, "Mcp-Session-Id": session_id, "Mcp-Protocol-Version": "2025-11-25",
            "Accept": "application/json, text/event-stream"},
            json={"jsonrpc": "2.0", "id": 31, "method": "tools/call",
                  "params": {"name": "lookup_tool", "arguments": {"record": "hold"}}}, timeout=12))
        await until(lambda: inflight(lab, "tools"))
        held_tool.cancel()
        await asyncio.gather(held_tool, return_exceptions=True)
        await until(lambda: no_call(lab, "tools"))
        lab.native_gate.set()
        print("PASS legacy MCP HTTP cancellation released the transport lease", flush=True)
        lab.gate.clear()
        pending = asyncio.create_task(request_report(lab, "hold"))
        await until(lambda: inflight(lab, "reports"))
        grants[0]["phase"] = "revoked"
        lab.update()
        result = await pending
        assert result.status_code == 502, result
        assert (await request_report(lab)).status_code == 503
        lab.gate.set()
        await check_native(lab, modern=True)
        print("PASS targeted revoke cut the active request while the sibling ran", flush=True)

        start = time.perf_counter()
        await lab.stop(process)
        await lab.connector("agent-restarted")
        await until(lambda: rejoined(lab, attach))
        await lab.ready("tools")
        expired = await lab.http.post(lab.base("tools"), json={"jsonrpc": "2.0", "method": "tools/list", "id": 2},
                                      headers={**lab.data_headers, "Mcp-Session-Id": session_id})
        assert expired.status_code == 404
        print(f"PASS process replacement recovered same identity in {(time.perf_counter()-start)*1000:.0f} ms; old MCP session returned 404",
              flush=True)

        grant = lab.desired["agents"][0]
        grant["phase"] = "revoked"
        lab.update()
        await until(lambda: disconnected(lab))
        assert (await lab.http.post(lab.base("tools"), headers=lab.data_headers)).status_code == 503
        new_token = secrets.token_urlsafe(32)
        grant.update(epoch=2, phase="active", credential_sha256=hashlib.sha256(new_token.encode()).hexdigest())
        lab.update()
        atomic(lab.credentials, {"epoch": 2, "token": new_token})
        await lab.ready("tools")
        assert (await lab.observation())["attached"][lab.agent]["attached_at_unix_ms"] != attach
        assert json.loads(lab.state_file.read_text())["revision"] == 1
        print("PASS whole-agent revoke and epoch recovery reused the durable desired configuration", flush=True)


async def exact_revision(lab, expected):
    status = await lab.target_status("reports")
    return status.get("ready") and status.get("revision") == expected


async def no_call(lab, channel):
    return (await lab.target_status(channel)).get("in_flight") == 0


async def rejoined(lab, old):
    return (await lab.observation())["attached"].get(lab.agent, {}).get("attached_at_unix_ms", old) != old


async def disconnected(lab):
    return lab.agent not in (await lab.observation())["attached"]


if __name__ == "__main__":
    logging.getLogger().setLevel(logging.WARNING)
    for name in ("httpx", "httpx2", "mcp"):
        logging.getLogger(name).setLevel(logging.WARNING)
    asyncio.run(main())
