"""Test which approvals the stock frp Store and server hooks can enforce."""
import asyncio
import hmac
import os
import secrets
import ssl
from pathlib import Path

import httpx
from starlette.applications import Starlette
from starlette.responses import JSONResponse, PlainTextResponse
from starlette.routing import Route

from support import CADDY, HOST, Lab, atomic, check, port, serve, until


async def main():
    frp = Path(os.environ.get("FRP_DIR", ".lab-tools/frp_0.72.0_linux_amd64")).resolve()
    for binary in ("frpc", "frps"):
        assert check([frp / binary, "--version"]).stdout.strip() == b"0.72.0"

    async with Lab() as lab:
        origin, replacement, plugin, relay, ingress, lease, rejected, ui = (port() for _ in range(8))
        shared, member, admin = (secrets.token_hex(24) for _ in range(3))
        state = {"allowed": True, "seen_local": False, "accepted_proxy": 0, "denied_proxy": 0, "fresh_connections": 0}
        env = {key: value for key, value in os.environ.items() if not key.lower().endswith("_proxy")}

        async def hook(request):
            event = await request.json()
            op, body = event["op"], event["content"]
            peer = body if op == "Login" else body["user"]
            ok = state["allowed"] and peer["user"] == "site" and hmac.compare_digest(
                peer.get("metas", {}).get("fixture-identity", ""), member)
            if op == "NewProxy":
                state["seen_local"] |= bool({"local_ip", "local_port", "localIP", "localPort"} & body.keys())
                ok &= (body.get("proxy_name"), body.get("proxy_type"), body.get("remote_port")) == ("site.reports", "tcp", lease)
                state["accepted_proxy"] += int(ok)
                state["denied_proxy"] += int(not ok)
            if op == "NewUserConn":
                state["fresh_connections"] += 1
            return JSONResponse({"reject": not ok, "reject_reason": "outside grant", "unchange": True})

        async def good(_):
            return PlainTextResponse("approved")

        async def other(_):
            return PlainTextResponse("alternate")

        await lab.stack.enter_async_context(serve(Starlette(routes=[Route("/", good)]), origin))
        await lab.stack.enter_async_context(serve(Starlette(routes=[Route("/", other)]), replacement))
        await lab.stack.enter_async_context(serve(Starlette(routes=[Route("/check", hook, methods=["POST"])]), plugin))

        cert, key = lab.dir / "ca.pem", lab.dir / "ca.key"
        check(["openssl", "req", "-x509", "-newkey", "ed25519", "-noenc", "-days", "1", "-subj", "/CN=127.0.0.1",
               "-addext", "subjectAltName=IP:127.0.0.1", "-out", cert, "-keyout", key])
        caddy, server, client, store = (lab.dir / name for name in ("Caddyfile", "frps.toml", "frpc.toml", "store.json"))
        atomic(caddy, f"""{{
    admin off
    auto_https off
}}
https://{HOST}:{ingress} {{
    tls {cert} {key}
    handle /~!frp {{
        reverse_proxy {HOST}:{relay}
    }}
    handle {{
        respond 404
    }}
}}
""")
        atomic(server, f"""bindAddr = "{HOST}"
bindPort = {relay}
proxyBindAddr = "{HOST}"
allowPorts = [{{ single = {lease} }}, {{ single = {rejected} }}]
auth.token = "{shared}"
log.level = "warn"
[[httpPlugins]]
name = "lease-admission"
addr = "{HOST}:{plugin}"
path = "/check"
ops = ["Login", "NewProxy", "NewUserConn"]
""")
        atomic(client, f"""serverAddr = "{HOST}"
serverPort = {ingress}
user = "site"
clientID = "site"
loginFailExit = false
auth.token = "{shared}"
metadatas.fixture-identity = "{member}"
transport.protocol = "wss"
transport.wireProtocol = "v1"
transport.poolCount = 0
transport.tls.enable = true
transport.tls.serverName = "{HOST}"
transport.tls.trustedCaFile = "{cert}"
log.level = "warn"
webServer.addr = "{HOST}"
webServer.port = {ui}
webServer.user = "local"
webServer.password = "{admin}"
[store]
path = "{store}"
""")
        await lab.proc("frps", frp / "frps", "-c", server, env=env)
        await lab.proc("caddy", CADDY, "run", "--config", caddy, env={**env,
                       "XDG_CONFIG_HOME": str(lab.dir / "config"), "XDG_DATA_HOME": str(lab.dir / "caddy")})
        async def upstream_ready():
            _, writer = await asyncio.open_connection(HOST, relay)
            writer.close()
            await writer.wait_closed()
            return True
        await until(upstream_ready)
        tls = ssl.create_default_context(cafile=str(cert))
        async with httpx.AsyncClient(trust_env=False, verify=tls, timeout=1) as https:
            async def ingress_ready():
                return (await https.get(f"https://{HOST}:{ingress}/")).status_code == 404
            await until(ingress_ready)
        worker = await lab.proc("frpc", frp / "frpc", "-c", client, env=env)
        local = ("local", admin)
        api = f"http://{HOST}:{ui}/api/store/proxies"

        async def live():
            return (await lab.http.get(api, auth=local)).is_success
        await until(live)
        assert (await lab.http.get(api)).status_code == 401

        def proxy(name, local_port, remote_port):
            return {"name": name, "type": "tcp", "tcp": {"localIP": HOST, "localPort": local_port, "remotePort": remote_port}}

        async def response(http, listener=lease):
            return await http.get(f"http://{HOST}:{listener}/")

        async with httpx.AsyncClient(trust_env=False, timeout=1, limits=httpx.Limits(max_keepalive_connections=0)) as fresh:
            async def serves(expected):
                return (await response(fresh)).text == expected

            async def blocked(listener):
                try:
                    return (await response(fresh, listener)).status_code >= 500
                except httpx.TransportError:
                    return True

            assert (await lab.http.post(api, auth=local, json=proxy("reports", origin, lease))).is_success
            try:
                await until(lambda: serves("approved"))
            except AssertionError as exc:
                diagnostic = []
                for component in ("frpc", "frps"):
                    logs = (lab.dir / (component + ".log")).read_text(errors="replace")
                    for confidential in (shared, member, admin):
                        logs = logs.replace(confidential, "[redacted]")
                    diagnostic.append(f"{component} {logs[-600:]}")
                raise AssertionError(f"frp did not activate the approved lease: {state} {diagnostic}") from exc
            assert store.is_file()
            assert (await lab.http.post(api, auth=local, json=proxy("other", origin, rejected))).is_success
            async def denied():
                return state["denied_proxy"] and await blocked(rejected)
            await until(denied)
            assert (await lab.http.get(api + "/other", auth=local)).is_success
            assert (await lab.http.delete(api + "/other", auth=local)).is_success
            await lab.stop(worker)
            await until(lambda: blocked(lease))
            await lab.proc("frpc-replaced", frp / "frpc", "-c", client, env=env)
            await until(lambda: serves("approved"))
            print("PASS frp 0.72.0 WSS, loopback Store auth, rejected lease and Store restoration after process replacement", flush=True)

            assert (await lab.http.put(api + "/reports", auth=local, json=proxy("reports", replacement, lease))).is_success
            await until(lambda: serves("alternate"))
            assert not state["seen_local"] and state["accepted_proxy"] >= 3
            print("OBSERVED stock frp accepted a replacement local port behind the same approved lease. NewProxy had no local destination.", flush=True)
            async with httpx.AsyncClient(trust_env=False, timeout=2) as kept:
                assert (await response(kept)).text == "alternate"
                state["allowed"] = False
                await until(lambda: blocked(lease))
                seen = state["fresh_connections"]
                assert (await response(kept)).text == "alternate" and state["fresh_connections"] == seen
            print("OBSERVED stock frp denied new connections after lease withdrawal. Existing HTTP keepalive still reached the origin.", flush=True)


if __name__ == "__main__":
    asyncio.run(main())
