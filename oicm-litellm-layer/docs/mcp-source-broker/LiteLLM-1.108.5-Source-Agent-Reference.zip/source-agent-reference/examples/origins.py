"""Small FastAPI and official MCP SDK fixture origins."""
import base64
import hashlib
import json
import re

from fastapi import FastAPI, HTTPException
from mcp.server import MCPServer
from starlette.responses import Response
from starlette.requests import Request


def json_digest(data):
    canonical = json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
    return hashlib.sha256(canonical).hexdigest()


def proof(request, key, target, digest, agent):
    nonce = request.headers.get("x-source-nonce", "")
    if (not re.fullmatch("[A-Za-z0-9_-]{43}", nonce) or
            request.headers.get("x-source-channel") != target or request.headers.get("x-source-agent") != agent):
        return Response(status_code=400)
    signature = key.sign(f"source-agent-catalog-v1\n{nonce}\n{agent}\n{target}\n{digest}".encode())
    return Response(status_code=204, headers={"X-Source-Catalog": digest,
                    "X-Source-Signature": base64.b64encode(signature).decode()})


def openapi_origin(key, agent, gate, digest_overrides, inspections, target="reports"):
    app = FastAPI(title="Reports fixture", docs_url=None, redoc_url=None)

    @app.get("/reports/lookup", operation_id="read_report")
    async def lookup(request: Request, record: str):
        assert all(h not in request.headers for h in ("authorization", "cookie", "x-api-key", "x-source-broker-key"))
        inspections.append(record)
        if record == "hold":
            await gate.wait()
        return {"record": record, "value": "approved-report"}

    @app.get("/proof", include_in_schema=False)
    async def observe(request: Request):
        digest = digest_overrides.get(target) or json_digest(app.openapi())
        return proof(request, key, target, digest, agent)

    return app


def native_origin(key, agent, target="tools", gate=None, json_response=False, origin_host=None):
    mcp = MCPServer("approved-native-fixture")

    @mcp.tool(structured_output=False)
    async def lookup_tool(record: str) -> str:
        """Read a single approved fixture record."""
        if record == "hold" and gate is not None:
            await gate.wait()
        return "native:" + record

    async def catalog():
        tools = await mcp.list_tools()
        return json_digest([tool.model_dump(mode="json", by_alias=True, exclude_none=True) for tool in tools])

    @mcp.custom_route("/proof", methods=["GET"], include_in_schema=False)
    async def observe(request):
        return proof(request, key, target, await catalog(), agent)

    from mcp.server.transport_security import TransportSecuritySettings
    security = None if origin_host is None else TransportSecuritySettings(allowed_hosts=[origin_host])
    app = mcp.streamable_http_app(stateless_http=False, json_response=json_response, transport_security=security)
    async def boundary(scope, receive, send):
        if scope["type"] == "http":
            names = {name for name, _ in scope["headers"]}
            assert not names & {b"authorization", b"cookie", b"x-api-key", b"x-source-broker-key"}
        await app(scope, receive, send)

    return boundary, catalog, mcp
