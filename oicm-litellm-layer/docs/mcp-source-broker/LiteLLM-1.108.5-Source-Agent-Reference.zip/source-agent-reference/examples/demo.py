"""Run a disposable local relay, agent, and two SDK origins."""
import asyncio
import logging
import shlex
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tests"))
from support import BIN, HOST, Lab


async def main():
    async with Lab() as lab:
        await lab.setup()
        await lab.serve_origins()
        await lab.connector()
        await lab.ready("reports")
        await lab.ready("tools")
        print("Run the local TUI in another terminal.", flush=True)
        print(shlex.join([str(BIN), "tui", "-url", f"http://{HOST}:{lab.control}",
                          "-token-file", str(lab.control_key)]), flush=True)
        print("Press Ctrl+C here to stop the fixture.", flush=True)
        await asyncio.Event().wait()


if __name__ == "__main__":
    for module in ("mcp", "httpx", "httpx2"):
        logging.getLogger(module).setLevel(logging.WARNING)
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
