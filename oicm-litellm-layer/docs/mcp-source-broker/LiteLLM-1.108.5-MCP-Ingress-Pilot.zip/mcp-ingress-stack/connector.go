package main

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"math/rand/v2"
	"net"
	"net/http"
	"time"

	"github.com/gorilla/websocket"
	"github.com/rancher/remotedialer"
)

func enroll(ctx context.Context, path, gateway, ca, ticketPath string) error {
	origin, err := httpsOrigin(gateway)
	if err != nil {
		return err
	}
	tlsConfig, err := trust(ca)
	if err != nil {
		return err
	}
	ticket, err := secretFile(ticketPath)
	if err != nil {
		return err
	}
	body, err := json.Marshal(map[string]string{"ticket": ticket})
	if err != nil {
		return err
	}
	origin.Path = "/connectors/enroll"
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, origin.String(), bytes.NewReader(body))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")
	httpClient := &http.Client{Timeout: 10 * time.Second,
		Transport:     &http.Transport{TLSClientConfig: tlsConfig, Proxy: http.ProxyFromEnvironment},
		CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse },
	}
	defer httpClient.CloseIdleConnections()
	resp, err := httpClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("enrollment returned HTTP %d", resp.StatusCode)
	}
	var cfg connectorConfig
	if err := json.NewDecoder(io.LimitReader(resp.Body, 64<<10)).Decode(&cfg); err != nil {
		return err
	}
	cfg.CA, cfg.Gateway = ca, gateway
	return writeJSON(path, cfg)
}

func slot(source string) string {
	return source + ".source.invalid:1"
}

func runConnector(ctx context.Context, cfg connectorConfig) error {
	origin, err := httpsOrigin(cfg.Gateway)
	if err != nil {
		return err
	}
	if !identifier.MatchString(cfg.Member) || cfg.Generation == 0 || len(cfg.Credential) < 32 || len(cfg.Targets) == 0 {
		return errors.New("invalid connector configuration")
	}
	tlsConfig, err := trust(cfg.CA)
	if err != nil {
		return err
	}
	origin.Scheme, origin.Path = "wss", "/mcp-worker"
	ws := &websocket.Dialer{
		Proxy: http.ProxyFromEnvironment, TLSClientConfig: tlsConfig, HandshakeTimeout: 8 * time.Second,
	}
	headers := http.Header{
		"X-Source-Member":     {cfg.Member},
		"X-Source-Generation": {fmt.Sprint(cfg.Generation)},
		"Authorization":       {"Bearer " + cfg.Credential},
	}
	targets := make(map[string]string, len(cfg.Targets))
	for source, target := range cfg.Targets {
		if _, _, err := net.SplitHostPort(target); err != nil || !identifier.MatchString(source) {
			return errors.New("invalid connector target")
		}
		targets[slot(source)] = target
	}
	allowed := func(network, address string) bool {
		return network == "tcp" && targets[address] != ""
	}
	local := &net.Dialer{Timeout: 4 * time.Second, KeepAlive: 30 * time.Second}
	dial := func(ctx context.Context, network, address string) (net.Conn, error) {
		if !allowed(network, address) {
			return nil, errors.New("target denied by connector")
		}
		return local.DialContext(ctx, "tcp", targets[address])
	}
	delay := 300 * time.Millisecond
	for ctx.Err() == nil {
		start := time.Now()
		err := remotedialer.ConnectToProxyWithDialer(ctx, origin.String(), headers, allowed, ws, dial, nil)
		if ctx.Err() != nil {
			break
		}
		if time.Since(start) > 30*time.Second {
			delay = 300 * time.Millisecond
		}
		log.Printf("connector %s disconnected, reconnecting: %v", cfg.Member, err)
		timer := time.NewTimer(delay + time.Duration(rand.Int64N(int64(delay/2))))
		select {
		case <-ctx.Done():
			timer.Stop()
		case <-timer.C:
		}
		delay = min(15*time.Second, delay*2)
	}
	return nil
}
