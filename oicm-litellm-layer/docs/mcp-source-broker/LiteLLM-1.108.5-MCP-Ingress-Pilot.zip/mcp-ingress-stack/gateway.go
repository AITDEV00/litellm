package main

import (
	"bufio"
	"context"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"

	"github.com/rancher/remotedialer"
)

var identifier = regexp.MustCompile(`^[a-z][a-z0-9-]{0,47}$`)

type gatewayConfig struct {
	Ingress   string                  `json:"ingress_listen"`
	Data      string                  `json:"data_listen"`
	Admin     string                  `json:"admin_listen"`
	AdminKey  string                  `json:"admin_key_file"`
	DataKey   string                  `json:"data_key_file"`
	State     string                  `json:"state_file"`
	Artifacts string                  `json:"artifact_dir,omitempty"`
	Sources   map[string]sourceConfig `json:"sources"`
	Members   map[string]memberConfig `json:"members"`
}

type memberConfig struct {
	Targets map[string]string `json:"targets"`
}

type memberState struct {
	Generation uint64    `json:"generation"`
	Phase      string    `json:"phase"`
	Ticket     string    `json:"ticket_hash,omitempty"`
	Expires    time.Time `json:"expires,omitempty"`
	Credential string    `json:"credential_hash,omitempty"`
	Binding    string    `json:"binding_sha256,omitempty"`
}

type gateway struct {
	cfg       gatewayConfig
	adminKey  string
	dataKey   string
	memberIDs []string
	bindings  map[string]string
	relay     *remotedialer.Server

	mu       sync.Mutex
	serial   uint64
	state    map[string]memberState
	sessions map[string]*workerSession
}

type workerSession struct {
	key       string
	conn      net.Conn
	transport *http.Transport
	ordered   *http.Transport
	ready     map[string]bool
	inFlight  map[string]int
	last      map[string]uint64
}

type workerKey struct{}

func newGateway(cfg gatewayConfig) (*gateway, error) {
	for _, address := range []string{cfg.Ingress, cfg.Data, cfg.Admin} {
		if !loopback(address) {
			return nil, errors.New("gateway listeners must use numeric loopback addresses")
		}
	}
	if cfg.State == "" {
		return nil, errors.New("state_file is required")
	}
	key, err := secretFile(cfg.AdminKey)
	if err != nil {
		return nil, err
	}
	dataKey, err := secretFile(cfg.DataKey)
	if err != nil {
		return nil, err
	}
	if key == dataKey {
		return nil, errors.New("management and data credentials must differ")
	}
	g := &gateway{
		cfg: cfg, adminKey: digest(key), dataKey: digest(dataKey), bindings: make(map[string]string),
		state: make(map[string]memberState), sessions: make(map[string]*workerSession),
	}
	for id, member := range cfg.Members {
		if !identifier.MatchString(id) || len(member.Targets) == 0 {
			return nil, fmt.Errorf("invalid member %q", id)
		}
		for source, target := range member.Targets {
			host, port, err := net.SplitHostPort(target)
			value, portErr := strconv.ParseUint(port, 10, 16)
			if err != nil || portErr != nil || value == 0 || host == "" || strings.ContainsAny(host, "/@* \\%\r\n\t") {
				return nil, fmt.Errorf("invalid target for %s/%s", id, source)
			}
			if _, ok := cfg.Sources[source]; !ok {
				return nil, fmt.Errorf("unknown source %s on member %s", source, id)
			}
		}
		targets, err := json.Marshal(member.Targets)
		if err != nil {
			return nil, err
		}
		g.bindings[id] = digest(string(targets))
		g.memberIDs = append(g.memberIDs, id)
	}
	sort.Strings(g.memberIDs)
	for id, source := range cfg.Sources {
		if err := source.validate(cfg.Members, id); err != nil {
			return nil, fmt.Errorf("source %q: %w", id, err)
		}
	}
	g.relay = remotedialer.New(func(r *http.Request) (string, bool, error) {
		id, ok := r.Context().Value(workerKey{}).(string)
		return id, ok, nil
	}, remotedialer.DefaultErrorWriter)
	return g, nil
}

func (g *gateway) run(ctx context.Context) error {
	if err := os.MkdirAll(filepath.Dir(g.cfg.State), 0700); err != nil {
		return err
	}
	lock, err := os.OpenFile(g.cfg.State+".lock", os.O_CREATE|os.O_RDWR, 0600)
	if err != nil {
		return err
	}
	defer lock.Close()
	if err := syscall.Flock(int(lock.Fd()), syscall.LOCK_EX|syscall.LOCK_NB); err != nil {
		return fmt.Errorf("another gateway holds the state lock: %w", err)
	}
	if err := readJSON(g.cfg.State, &g.state); err != nil && !errors.Is(err, os.ErrNotExist) {
		return err
	}
	if g.state == nil {
		return errors.New("invalid member state")
	}

	ingress := http.NewServeMux()
	ingress.HandleFunc("GET /mcp-worker", g.worker)
	ingress.HandleFunc("POST /connectors/enroll", g.redeem)
	for _, name := range []string{"source-link", "source-link.sha256"} {
		ingress.HandleFunc("GET /connectors/linux-amd64/"+name, func(w http.ResponseWriter, r *http.Request) {
			if g.cfg.Artifacts == "" {
				http.NotFound(w, r)
				return
			}
			w.Header().Set("X-Content-Type-Options", "nosniff")
			http.ServeFile(w, r, filepath.Join(g.cfg.Artifacts, name))
		})
	}

	admin := http.NewServeMux()
	admin.HandleFunc("GET /members", g.status)
	admin.HandleFunc("POST /members/{id}/{action}", g.mutate)
	data := http.NewServeMux()
	data.HandleFunc("GET /readyz", func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(http.StatusNoContent) })
	data.HandleFunc("/sources/{source}/{path...}", func(w http.ResponseWriter, r *http.Request) {
		if !sameDigest(g.dataKey, r.Header.Get("X-Source-Broker-Key")) {
			http.Error(w, "unauthorized", http.StatusUnauthorized)
			return
		}
		g.proxy(w, r)
	})
	servers := []*http.Server{
		privateHTTP(g.cfg.Ingress, ingress),
		privateHTTP(g.cfg.Admin, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			if !sameDigest(g.adminKey, bearer(r)) {
				http.Error(w, "unauthorized", http.StatusUnauthorized)
				return
			}
			admin.ServeHTTP(w, r)
		})),
		privateHTTP(g.cfg.Data, data),
	}
	var listeners []net.Listener
	defer func() {
		for _, listener := range listeners {
			listener.Close()
		}
	}()
	for _, server := range servers {
		listener, err := net.Listen("tcp", server.Addr)
		if err != nil {
			return err
		}
		listeners = append(listeners, listener)
	}
	errorsOut := make(chan error, len(servers)+len(g.cfg.Sources))
	for id, source := range g.cfg.Sources {
		if source.TCPListen != "" {
			listener, err := net.Listen("tcp", source.TCPListen)
			if err != nil {
				return err
			}
			listeners = append(listeners, listener)
			go func() { errorsOut <- g.serveTCP(ctx, id, listener) }()
		}
	}
	for index, server := range servers {
		go func() { errorsOut <- server.Serve(listeners[index]) }()
	}
	defer func() {
		for _, server := range servers {
			server.Close()
		}
		g.mu.Lock()
		defer g.mu.Unlock()
		for _, session := range g.sessions {
			if session.conn != nil {
				session.conn.Close()
			}
			session.transport.CloseIdleConnections()
			session.ordered.CloseIdleConnections()
		}
	}()
	log.Printf("ingress %s, data %s, admin %s", g.cfg.Ingress, g.cfg.Data, g.cfg.Admin)
	select {
	case <-ctx.Done():
		return nil
	case err := <-errorsOut:
		return err
	}
}

func digest(value string) string {
	return fmt.Sprintf("%x", sha256.Sum256([]byte(value)))
}

func sameDigest(expected, supplied string) bool {
	return len(supplied) >= 32 && subtle.ConstantTimeCompare([]byte(expected), []byte(digest(supplied))) == 1
}

func bearer(r *http.Request) string {
	value, ok := strings.CutPrefix(r.Header.Get("Authorization"), "Bearer ")
	if !ok {
		return ""
	}
	return value
}

func randomToken() (string, error) {
	var raw [32]byte
	if _, err := rand.Read(raw[:]); err != nil {
		return "", err
	}
	return base64.RawURLEncoding.EncodeToString(raw[:]), nil
}

func (g *gateway) commit(id string, next memberState) error {
	old, existed := g.state[id]
	g.state[id] = next
	if err := writeJSON(g.cfg.State, g.state); err != nil {
		if existed {
			g.state[id] = old
		} else {
			delete(g.state, id)
		}
		return err
	}
	return nil
}

func (g *gateway) mutate(w http.ResponseWriter, r *http.Request) {
	id, action := r.PathValue("id"), r.PathValue("action")
	if _, ok := g.cfg.Members[id]; !ok {
		http.NotFound(w, r)
		return
	}
	var request struct {
		Generation uint64 `json:"generation"`
	}
	if err := decode(w, r, &request); err != nil {
		http.Error(w, "expected generation", http.StatusBadRequest)
		return
	}

	g.mu.Lock()
	defer g.mu.Unlock()
	next := g.state[id]
	if request.Generation != next.Generation {
		http.Error(w, "stale generation", http.StatusConflict)
		return
	}
	var ticket string
	switch action {
	case "invite", "recover":
		if (action == "invite" && next.Phase != "" && next.Phase != "revoked") ||
			(action == "recover" && next.Phase != "active" && next.Phase != "pending") {
			http.Error(w, "invalid transition", http.StatusConflict)
			return
		}
		var err error
		ticket, err = randomToken()
		if err != nil {
			http.Error(w, "ticket generation failed", http.StatusInternalServerError)
			return
		}
		next = memberState{Generation: next.Generation + 1, Phase: "pending",
			Ticket: digest(ticket), Expires: time.Now().Add(10 * time.Minute)}
	case "drain":
		if next.Phase != "active" {
			http.Error(w, "invalid transition", http.StatusConflict)
			return
		}
		next.Phase = "draining"
	case "revoke":
		if next.Phase == "" || next.Phase == "revoked" {
			http.Error(w, "invalid transition", http.StatusConflict)
			return
		}
		next = memberState{Generation: next.Generation + 1, Phase: "revoked"}
	default:
		http.NotFound(w, r)
		return
	}
	if err := g.commit(id, next); err != nil {
		log.Printf("commit member %s: %v", id, err)
		http.Error(w, "state write failed", http.StatusInternalServerError)
		return
	}
	if session := g.sessions[id]; session != nil && action != "drain" {
		delete(g.sessions, id)
		if session.conn != nil {
			session.conn.Close()
		}
	}
	response := map[string]any{"generation": next.Generation, "phase": next.Phase}
	if ticket != "" {
		response["ticket"] = ticket
		response["expires"] = next.Expires
	}
	reply(w, http.StatusOK, response)
}

func (g *gateway) status(w http.ResponseWriter, r *http.Request) {
	g.mu.Lock()
	defer g.mu.Unlock()
	type status struct {
		Generation uint64          `json:"generation"`
		Phase      string          `json:"phase"`
		Ready      map[string]bool `json:"ready,omitempty"`
		InFlight   map[string]int  `json:"in_flight,omitempty"`
	}
	result := make(map[string]status, len(g.memberIDs))
	for _, id := range g.memberIDs {
		member := g.state[id]
		current := status{Generation: member.Generation, Phase: member.Phase}
		if session := g.sessions[id]; session != nil {
			current.InFlight = session.inFlight
			current.Ready = session.ready
		}
		result[id] = current
	}
	reply(w, http.StatusOK, result)
}

func (g *gateway) redeem(w http.ResponseWriter, r *http.Request) {
	controller := http.NewResponseController(w)
	if err := controller.SetReadDeadline(time.Now().Add(5 * time.Second)); err == nil {
		defer controller.SetReadDeadline(time.Time{})
	}
	var request struct {
		Ticket string `json:"ticket"`
	}
	if err := decode(w, r, &request); err != nil {
		http.Error(w, "invalid ticket", http.StatusBadRequest)
		return
	}
	g.mu.Lock()
	defer g.mu.Unlock()
	for _, id := range g.memberIDs {
		current := g.state[id]
		if current.Phase != "pending" || !time.Now().Before(current.Expires) || !sameDigest(current.Ticket, request.Ticket) {
			continue
		}
		secret, err := randomToken()
		if err != nil {
			http.Error(w, "credential generation failed", http.StatusInternalServerError)
			return
		}
		next := memberState{Generation: current.Generation, Phase: "active", Credential: digest(secret), Binding: g.bindings[id]}
		if err := g.commit(id, next); err != nil {
			log.Printf("commit enrollment for %s: %v", id, err)
			http.Error(w, "state write failed", http.StatusInternalServerError)
			return
		}
		reply(w, http.StatusOK, connectorConfig{Member: id, Generation: next.Generation, Credential: secret,
			Targets: g.cfg.Members[id].Targets})
		return
	}
	http.Error(w, "invalid, expired, or used ticket", http.StatusUnauthorized)
}

type trackedUpgrade struct {
	http.ResponseWriter
	onHijack func(net.Conn) bool
}

func (w trackedUpgrade) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	conn, rw, err := http.NewResponseController(w.ResponseWriter).Hijack()
	if err == nil && !w.onHijack(conn) {
		conn.Close()
		return nil, nil, errors.New("worker revoked before upgrade")
	}
	return conn, rw, err
}

func (g *gateway) worker(w http.ResponseWriter, r *http.Request) {
	if !strings.EqualFold(r.Header.Get("Upgrade"), "websocket") {
		http.Error(w, "WebSocket required", http.StatusUpgradeRequired)
		return
	}
	id := r.Header.Get("X-Source-Member")
	g.mu.Lock()
	state := g.state[id]
	if g.bindings[id] == "" || state.Binding != g.bindings[id] || state.Phase != "active" ||
		r.Header.Get("X-Source-Generation") != fmt.Sprint(state.Generation) ||
		!sameDigest(state.Credential, bearer(r)) {
		g.mu.Unlock()
		http.Error(w, "connector unauthorized", http.StatusUnauthorized)
		return
	}
	if g.sessions[id] != nil {
		g.mu.Unlock()
		http.Error(w, "connector already attached", http.StatusConflict)
		return
	}
	g.serial++
	session := &workerSession{
		key: fmt.Sprintf("%s-%d-%d", id, state.Generation, g.serial), ready: make(map[string]bool),
		inFlight: make(map[string]int), last: make(map[string]uint64),
	}
	session.transport = &http.Transport{
		MaxIdleConns: 32, MaxIdleConnsPerHost: 16, IdleConnTimeout: 25 * time.Second,
		ResponseHeaderTimeout: 30 * time.Second, DisableCompression: true,
		DialContext: func(ctx context.Context, network, address string) (net.Conn, error) {
			source, ok := ctx.Value(sourceKey{}).(string)
			if !ok || g.cfg.Members[id].Targets[source] == "" {
				return nil, errors.New("unassigned source")
			}
			return g.relay.Dialer(session.key)(ctx, "tcp", slot(source))
		},
	}
	session.ordered = session.transport.Clone()
	session.ordered.DisableKeepAlives = true
	g.sessions[id] = session
	g.mu.Unlock()

	ctx, cancel := context.WithCancel(r.Context())
	defer func() {
		cancel()
		g.mu.Lock()
		if g.sessions[id] == session {
			delete(g.sessions, id)
		}
		g.mu.Unlock()
		if session.conn != nil {
			session.conn.Close()
		}
		session.transport.CloseIdleConnections()
		session.ordered.CloseIdleConnections()
	}()
	wrapped := trackedUpgrade{ResponseWriter: w, onHijack: func(conn net.Conn) bool {
		g.mu.Lock()
		defer g.mu.Unlock()
		if g.sessions[id] != session || g.state[id].Phase != "active" {
			return false
		}
		session.conn = conn
		return true
	}}
	go g.checkWorker(ctx, id, session)
	g.relay.ServeHTTP(wrapped, r.WithContext(context.WithValue(ctx, workerKey{}, session.key)))
}
