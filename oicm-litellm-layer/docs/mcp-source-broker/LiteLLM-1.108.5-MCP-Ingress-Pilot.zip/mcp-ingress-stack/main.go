package main

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/signal"
	"path/filepath"
	"strings"
	"syscall"
	"time"
)

type connectorConfig struct {
	Gateway    string            `json:"gateway"`
	CA         string            `json:"ca_file,omitempty"`
	Member     string            `json:"member"`
	Generation uint64            `json:"generation"`
	Credential string            `json:"credential"`
	Targets    map[string]string `json:"targets"`
}

func main() {
	if err := run(os.Args[1:]); err != nil {
		log.Print(err)
		os.Exit(1)
	}
}

func run(args []string) error {
	if len(args) == 0 {
		return errors.New("usage: source-link gateway|connector|enroll")
	}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	flags := flag.NewFlagSet(args[0], flag.ContinueOnError)
	switch args[0] {
	case "gateway":
		config := flags.String("config", "", "gateway manifest path")
		if err := flags.Parse(args[1:]); err != nil {
			return err
		}
		var cfg gatewayConfig
		if err := readJSON(*config, &cfg); err != nil {
			return err
		}
		g, err := newGateway(cfg)
		if err != nil {
			return err
		}
		return g.run(ctx)
	case "connector":
		config := flags.String("config", "", "connector config path")
		if err := flags.Parse(args[1:]); err != nil {
			return err
		}
		var cfg connectorConfig
		if info, err := os.Stat(*config); err != nil || !info.Mode().IsRegular() || info.Mode().Perm()&0077 != 0 {
			return errors.New("connector configuration must be a regular owner-only file")
		}
		if err := readJSON(*config, &cfg); err != nil {
			return err
		}
		return runConnector(ctx, cfg)
	case "enroll":
		config := flags.String("config", "", "write connector config to this path")
		gateway := flags.String("gateway", "", "approved HTTPS ingress origin")
		ca := flags.String("ca", "", "optional CA bundle path")
		ticket := flags.String("ticket-file", "", "read the one-time ticket from a file, or - for stdin")
		if err := flags.Parse(args[1:]); err != nil {
			return err
		}
		return enroll(ctx, *config, *gateway, *ca, *ticket)
	default:
		return fmt.Errorf("unknown command %q", args[0])
	}
}

func httpsOrigin(raw string) (*url.URL, error) {
	u, err := url.Parse(raw)
	if err != nil || u.Scheme != "https" || u.Hostname() == "" || u.User != nil ||
		u.RawQuery != "" || u.Fragment != "" || (u.Path != "" && u.Path != "/") {
		return nil, errors.New("gateway must be an HTTPS origin")
	}
	return u, nil
}

func trust(ca string) (*tls.Config, error) {
	cfg := &tls.Config{MinVersion: tls.VersionTLS12}
	if ca == "" {
		return cfg, nil
	}
	pem, err := os.ReadFile(ca)
	if err != nil {
		return nil, err
	}
	cfg.RootCAs, err = x509.SystemCertPool()
	if err != nil {
		return nil, err
	}
	if !cfg.RootCAs.AppendCertsFromPEM(pem) {
		return nil, errors.New("CA file contains no certificates")
	}
	return cfg, nil
}

func readJSON(path string, value any) error {
	data, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	return json.Unmarshal(data, value)
}

// Each state update is an atomic replacement within a directory owned by the service.
func writeJSON(path string, value any) error {
	if err := os.MkdirAll(filepath.Dir(path), 0700); err != nil {
		return err
	}
	file, err := os.CreateTemp(filepath.Dir(path), ".source-link-")
	if err != nil {
		return err
	}
	defer os.Remove(file.Name())
	defer file.Close()
	if err := json.NewEncoder(file).Encode(value); err != nil {
		return err
	}
	if err := file.Sync(); err != nil {
		return err
	}
	if err := file.Close(); err != nil {
		return err
	}
	if err := os.Rename(file.Name(), path); err != nil {
		return err
	}
	dir, err := os.Open(filepath.Dir(path))
	if err == nil {
		err = dir.Sync()
		dir.Close()
	}
	if err != nil {
		log.Printf("could not sync the state directory: %v", err)
	}
	return nil
}

func loopback(address string) bool {
	host, port, err := net.SplitHostPort(address)
	return err == nil && port != "" && net.ParseIP(host).IsLoopback()
}

func secretFile(path string) (string, error) {
	var input io.Reader = os.Stdin
	if path != "-" {
		file, err := os.Open(path)
		if err != nil {
			return "", err
		}
		defer file.Close()
		if info, err := file.Stat(); err != nil || !info.Mode().IsRegular() || info.Mode().Perm()&0077 != 0 {
			return "", errors.New("secret file must be a regular owner-only file")
		}
		input = file
	}
	raw, err := io.ReadAll(io.LimitReader(input, 513))
	if err != nil || len(raw) > 512 || len(strings.TrimSpace(string(raw))) < 32 {
		return "", errors.New("invalid secret")
	}
	return strings.TrimSpace(string(raw)), nil
}

func reply(w http.ResponseWriter, code int, payload any) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(code)
	if err := json.NewEncoder(w).Encode(payload); err != nil {
		log.Printf("write response: %v", err)
	}
}

func decode(w http.ResponseWriter, r *http.Request, value any) error {
	body := json.NewDecoder(http.MaxBytesReader(w, r.Body, 4096))
	body.DisallowUnknownFields()
	if err := body.Decode(value); err != nil {
		return err
	}
	if err := body.Decode(new(any)); err != io.EOF {
		return errors.New("expected one JSON object")
	}
	return nil
}

func privateHTTP(address string, handler http.Handler) *http.Server {
	return &http.Server{
		Addr: address, Handler: handler, ReadHeaderTimeout: 5 * time.Second,
		IdleTimeout: 60 * time.Second, MaxHeaderBytes: 32 << 10,
	}
}
