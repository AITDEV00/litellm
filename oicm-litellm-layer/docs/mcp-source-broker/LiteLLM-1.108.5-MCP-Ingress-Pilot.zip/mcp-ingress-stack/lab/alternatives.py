import asyncio
import secrets
import subprocess
import tempfile
from contextlib import AsyncExitStack

import httpx

from async_support import launch, launch_ready
from baseline_lifecycle import VALIDATION, eventually, responding, start_nginx
from common import BIN, free_port



async def main():
    async with AsyncExitStack() as stack:
        directory = Path(stack.enter_context(tempfile.TemporaryDirectory(prefix="mcp-alt-relays-")))
        source, payload = await start_nginx(stack, directory)
        rat, wst, ingress, rat_lease, wst_lease = (free_port() for _ in range(5))
        cert, key = directory / "cert.pem", directory / "key.pem"
        ca, ca_key = directory / "ca.pem", directory / "ca.key"
        subprocess.run(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-noenc", "-days", "1",
                        "-subj", "/CN=Lab CA", "-addext", "basicConstraints=critical,CA:TRUE",
                        "-out", str(ca), "-keyout", str(ca_key)], check=True, capture_output=True)
        csr, extensions = directory / "tls.csr", directory / "ext"
        extensions.write_text("basicConstraints=critical,CA:FALSE\nsubjectAltName=IP:127.0.0.1\nextendedKeyUsage=serverAuth\n")
        subprocess.run(["openssl", "req", "-new", "-newkey", "rsa:2048", "-noenc", "-subj", "/CN=127.0.0.1",
                        "-out", str(csr), "-keyout", str(key)], check=True, capture_output=True)
        subprocess.run(["openssl", "x509", "-req", "-in", str(csr), "-CA", str(ca), "-CAkey", str(ca_key),
                        "-CAcreateserial", "-out", str(cert), "-days", "1", "-extfile", str(extensions)],
                       check=True, capture_output=True)
        caddy = directory / "Caddyfile"
        caddy.write_text(f'''{{
    admin off
    auto_https off
}}
https://127.0.0.1:{ingress} {{
    tls {cert} {key}
    handle /mcp-alt/* {{
        reverse_proxy 127.0.0.1:{wst}
    }}
    @rat {{
        path /
        header Upgrade websocket
    }}
    handle @rat {{
        reverse_proxy 127.0.0.1:{rat}
    }}
    handle {{
        respond 404
    }}
}}
''')
        await launch_ready(stack, directory, "caddy", ingress, str(VALIDATION / "caddy"), "run", "--config", str(caddy),
                           overrides={"XDG_CONFIG_HOME": str(directory / "config"), "XDG_DATA_HOME": str(directory / "data")})
        token = secrets.token_hex(20)
        server = directory / "rathole-server.toml"
        server.write_text(f'''[server]
bind_addr = "127.0.0.1:{rat}"
[server.transport]
type = "websocket"
[server.transport.websocket]
tls = false
[server.services.fixture]
token = "{token}"
bind_addr = "127.0.0.1:{rat_lease}"
''')
        await launch_ready(stack, directory, "rathole-server", rat, str(BIN / "rathole"), "--server", str(server))
        rat_conf = directory / "rathole-client.toml"
        rat_conf.write_text(f'''[client]
remote_addr = "127.0.0.1:{ingress}"
[client.transport]
type = "websocket"
[client.transport.websocket]
tls = true
[client.transport.tls]
trusted_root = "{ca}"
hostname = "127.0.0.1"
[client.services.fixture]
token = "{token}"
local_addr = "127.0.0.1:{source}"
''')
        await stack.enter_async_context(launch(directory, "rathole-client", str(BIN / "rathole"), "--client", str(rat_conf)))
        async with httpx.AsyncClient(trust_env=False, timeout=3) as http:
            await eventually(lambda: responding(http, rat_lease, payload["small"]), seconds=8)
            print("PASS rathole 0.5.0 native source GET over Caddy WSS and private lease, WebSocket Upgrade routed at /", flush=True)

            token = secrets.token_hex(20)
            headers = directory / "wstunnel-headers.txt"
            headers.write_text(f"Authorization: Bearer {token}\n")
            headers.chmod(0o600)
            restrictions = directory / "wstunnel.yml"
            restrictions.write_text(f'''restrictions:
  - name: fixture
    match:
      - !PathPrefix "^mcp-alt$"
      - !Authorization "^Bearer {token}$"
    allow:
      - !ReverseTunnel
        protocol: [Tcp]
        port: [{wst_lease}]
        cidr: ["127.0.0.1/32"]
''')
            await launch_ready(stack, directory, "wstunnel-server", wst, str(BIN / "wstunnel"), "server",
                               "--restrict-config", str(restrictions), f"ws://127.0.0.1:{wst}",
                               overrides={"NO_COLOR": "true", "RUST_LOG": "info", "TOKIO_WORKER_THREADS": "2"})
            await stack.enter_async_context(launch(directory, "wstunnel-client", str(BIN / "wstunnel"), "client",
                "--tls-verify-certificate", "--http-upgrade-path-prefix", "mcp-alt", "--http-headers-file", str(headers),
                "-R", f"tcp://127.0.0.1:{wst_lease}:127.0.0.1:{source}", f"wss://127.0.0.1:{ingress}",
                overrides={"SSL_CERT_FILE": str(ca), "NO_COLOR": "true", "RUST_LOG": "info", "TOKIO_WORKER_THREADS": "2"}))
            await eventually(lambda: responding(http, wst_lease, payload["small"]), seconds=9)
            print("PASS wstunnel 11.1.0 native source GET over Caddy WSS with verified TLS and an authorized private lease", flush=True)


if __name__ == "__main__":
    asyncio.run(main())
