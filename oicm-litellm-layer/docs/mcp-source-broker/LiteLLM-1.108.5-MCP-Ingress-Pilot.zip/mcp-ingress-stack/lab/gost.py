import secrets
import uuid

from common import BIN, HOST, private


def relay(lab, port, secret):
    conf = lab.directory / "gost-relay.json"
    private(conf, {"log": {"level": "warn"}, "services": [{
        "name": "relay", "addr": f"{HOST}:{port}",
        "handler": {"type": "tunnel", "auther": "workers",
                    "metadata": {"tunnel.direct": True, "readTimeout": "5s"}},
        "listener": {"type": "ws", "metadata": {"path": "/gost-worker"}},
    }], "authers": [{"name": "workers", "auths": [
        {"username": name, "password": password} for name, password in secret.items()
    ]}]})
    return lab.process("gost-relay", BIN / "gost", "-C", conf, wait=port)


def attach(lab, name, user, secret, tunnel, source, ingress, cert, visitor=None, direct=False, quiet=False):
    conf = lab.directory / f"gost-{name}.json"
    node = {"name": "node", "addr": f"{HOST}:{ingress}",
            "connector": {"type": "tunnel", "auth": {"username": user, "password": secret},
                          "metadata": {"tunnel.id": tunnel}},
            "dialer": {"type": "wss", "tls": {"secure": True, "caFile": str(cert), "serverName": HOST},
                       "metadata": {"path": "/gost-worker"}}}
    if direct:
        node["dialer"] = {"type": "ws", "metadata": {"path": "/gost-worker"}}
    service = {"name": name, "addr": f"{HOST}:{visitor}" if visitor is not None else ":0",
               "handler": {"type": "tcp" if visitor is not None else "rtcp"},
               "listener": {"type": "tcp" if visitor is not None else "rtcp"},
               "forwarder": {"nodes": [{"name": "target", "addr": source}]}}
    service["handler" if visitor is not None else "listener"]["chain"] = "chain"
    private(conf, {"log": {"level": "warn" if quiet else "debug"}, "services": [service],
                   "chains": [{"name": "chain", "hops": [{"name": "hop", "nodes": [node]}]}]})
    return lab.process(f"gost-{name}", BIN / "gost", "-C", conf, wait=visitor)


def grouping_test():
    from collections import Counter
    from common import Lab, eventually, free_port, nginx, request, stop

    with Lab() as lab:
        nginx_a, nginx_b, gost_port, ingress, edge = (free_port() for _ in range(5))
        for name, port in (("alpha", nginx_a), ("beta", nginx_b)):
            root = lab.directory / name
            root.mkdir()
            (root / "hello").write_text(name)
            nginx(lab, port, root, name)
        cert, key = lab.certificates()
        tokens = {name: secrets.token_urlsafe(20) for name in ("alpha", "beta", "consumer")}
        relay(lab, gost_port, tokens)
        lab.caddy({"/gost-worker": gost_port}, ingress, cert, key)
        tunnel = str(uuid.uuid4())
        attach(lab, "alpha", "alpha", tokens["alpha"], tunnel, f"{HOST}:{nginx_a}", ingress, cert)
        attach(lab, "visitor", "consumer", tokens["consumer"], tunnel, "fixture.invalid:80", ingress, cert, visitor=edge)
        try:
            assert eventually(lambda: request(edge, "/hello") == (200, b"alpha"))
            rogue = attach(lab, "wrong-password", "beta", secrets.token_urlsafe(20), tunnel, f"{HOST}:{nginx_b}", ingress, cert)
            assert all(request(edge, "/hello") == (200, b"alpha") for _ in range(12))
            stop(rogue)
            beta = attach(lab, "beta", "beta", tokens["beta"], tunnel, f"{HOST}:{nginx_b}", ingress, cert)
            eventually(lambda: request(edge, "/hello") == (200, b"beta"))
            counts = Counter(request(edge, "/hello")[1].decode() for _ in range(80))
            assert set(counts) == {"alpha", "beta"}, counts
            print("PASS GOST WSS through Caddy, certificate checked, two native tunnel-group members", dict(counts), flush=True)
            print("PASS stock GOST denied incorrect credentials. Another valid identity joined the same configured tunnel ID without an identity-to-group grant", flush=True)
            stop(beta)
            eventually(lambda: request(edge, "/hello") == (200, b"alpha"))
            print("PASS GOST fresh streams reached the remaining publisher after disconnect", flush=True)
        except Exception:
            for name in ["gost-relay", "gost-alpha", "gost-visitor"]:
                print(name, lab.logs[name].read_text()[-1800:])
            raise


if __name__ == "__main__":
    grouping_test()
