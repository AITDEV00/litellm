#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")/.."
export CHECKPOINT_DISABLE=1 PRISMA_DISABLE_TELEMETRY=1 DO_NOT_TRACK=1 NPM_CONFIG_UPDATE_NOTIFIER=false
env_dir=${1:-.venv}
python3 -m venv "$env_dir"
python="$env_dir/bin/python"
export PATH="$(cd -- "$env_dir/bin" && pwd):$PATH"
"$python" -m pip install -r lab/requirements.lock.txt
schema=$("$python" -c 'import importlib.util, pathlib; s=importlib.util.find_spec("litellm"); print(pathlib.Path(s.origin).parent / "proxy" / "schema.prisma")')
test -r "$schema"
"$python" -m prisma generate --schema "$schema"
printf 'Run with LITELLM_SCHEMA=%s %s lab/litellm_integration.py\n' "$schema" "$python"
