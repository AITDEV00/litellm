import json
import os
import secrets
import ssl
import subprocess
import urllib.request
import urllib.error

from common import BIN, HOST, Lab, eventually, free_port, nginx, request

ZITI = BIN / "ziti"


def main(wss):
    with Lab() as lab:
        directory = lab.directory
        pki = directory / "pki"
        controller, ctl_link, router, router_link, origin, proxy, denied, ingress = [free_port() for _ in range(8)]
        password = secrets.token_urlsafe(22)
        env = {"ZITI_CONFIG_DIR": str(directory / "cli")}
        (directory / "cli").mkdir(mode=0o700)

        def ziti(*args, **extra):
            result = subprocess.run([ZITI, *args], cwd=directory, env={**{k: v for k, v in os.environ.items() if not k.lower().endswith("_proxy")}, **env, **extra},
                                    capture_output=True, text=True, timeout=12)
            if result.returncode:
                raise RuntimeError(result.stderr[-1600:] or result.stdout[-1600:])
            return result.stdout

        ziti("pki", "create", "ca", "--pki-root", pki, "--ca-file", "root", "--ca-name", "Test Root", "--curve", "P256")
        ziti("pki", "create", "intermediate", "--pki-root", pki, "--ca-name", "root", "--intermediate-file", "signer",
             "--intermediate-name", "Test Signer", "--curve", "P256", "--max-path-len", "1")
        ziti("pki", "create", "server", "--pki-root", pki, "--ca-name", "signer", "--server-file", "server",
             "--server-name", "Controller", "--dns", "localhost", "--ip", HOST, "--curve", "P256")
        ziti("pki", "create", "client", "--pki-root", pki, "--ca-name", "signer", "--client-file", "client",
             "--client-name", "Controller Client", "--key-file", "server")
        ca = pki / "root/certs/root.cert"
        conf = directory / "controller.yml"
        conf.write_text(f"""
v: 3
db: {directory / "controller.db"}
identity:
  cert: {pki / "signer/certs/client.chain.pem"}
  server_cert: {pki / "signer/certs/server.chain.pem"}
  key: {pki / "signer/keys/server.key"}
  ca: {ca}
ctrl:
  listener: tls:{HOST}:{ctl_link}
edge:
  api:
    address: {HOST}:{controller}
  enrollment:
    signingCert:
      cert: {pki / "signer/certs/signer.cert"}
      key: {pki / "signer/keys/signer.key"}
    edgeIdentity:
      duration: 10m
    edgeRouter:
      duration: 10m
web:
  - name: lab
    bindPoints:
      - interface: {HOST}:{controller}
        address: {HOST}:{controller}
    apis:
      - binding: edge-client
      - binding: edge-management
""")
        ziti("controller", "edge", "init", conf, "-u", "fixture-admin", "-p", password)
        lab.process("ziti-controller", ZITI, "controller", "run", conf, "--cliagent=false", wait=controller, env=env)
        ziti("edge", "login", f"https://{HOST}:{controller}", "-u", "fixture-admin", "-p", password, "--ca", ca)
        ziti("edge", "create", "edge-router", "router", "-a", "lab", "-o", "router.jwt")
        ziti("create", "config", "router", "edge", *(["--wss"] if wss else []), "-n", "router", "-o", "router.yml", **{
            "ZITI_HOME": str(directory), "ZITI_CTRL_ADVERTISED_ADDRESS": HOST,
            "ZITI_CTRL_ADVERTISED_PORT": str(ctl_link), "ZITI_ROUTER_ADVERTISED_ADDRESS": HOST,
            "ZITI_ROUTER_PORT": str(router),
        })
        rc = directory / "router.yml"
        rc.write_text(rc.read_text().replace(f"0.0.0.0:{router}", f"{HOST}:{router}").replace("10080", str(router_link))
                      .replace(f"0.0.0.0:{router_link}", f"{HOST}:{router_link}"))
        ziti("router", "enroll", rc, "-j", "router.jwt")
        lab.process("ziti-router", ZITI, "router", "run", rc, "--cliagent=false", wait=router, env=env)
        ziti("edge", "create", "edge-router-policy", "router-access", "--edge-router-roles", "#lab",
             "--identity-roles", "#all")
        ziti("edge", "create", "service-edge-router-policy", "service-router", "--edge-router-roles", "#lab",
             "--service-roles", "#all")
        ziti("edge", "create", "config", "origin", "host.v1",
             json.dumps({"protocol": "tcp", "address": HOST, "port": origin}))
        ziti("edge", "create", "service", "documents", "--configs", "origin")
        ziti("edge", "create", "service-policy", "documents-bind", "Bind", "--service-roles", "@documents",
             "--identity-roles", "#publisher")
        ziti("edge", "create", "service-policy", "documents-dial", "Dial", "--service-roles", "@documents",
             "--identity-roles", "#consumer")
        for identity in ("publisher", "consumer", "unprivileged"):
            ziti("edge", "create", "identity", identity, "-a", identity, "-o", f"{identity}.jwt")
            ziti("edge", "enroll", f"{identity}.jwt", "-o", f"{identity}.json")
        www = directory / "www"
        www.mkdir()
        (www / "hello").write_text("ziti-nginx")
        nginx(lab, origin, www)
        lab.process("ziti-publisher", ZITI, "tunnel", "host", "--cli-agent=false", "-i", "publisher.json", "--svcPollRate", "1")
        lab.process("ziti-consumer", ZITI, "tunnel", "proxy", "--cli-agent=false", f"documents:{proxy}",
                    "-i", "consumer.json", "--svcPollRate", "1")
        unprivileged = lab.process("ziti-no-dial", ZITI, "tunnel", "proxy", "--cli-agent=false", f"documents:{denied}",
                                   "-i", "unprivileged.json", "--svcPollRate", "1")
        try:
            eventually(lambda: request(proxy, "/hello", timeout=1.5) == (200, b"ziti-nginx"), timeout=18)
        except Exception:
            for name in ("ziti-publisher", "ziti-consumer", "ziti-router"):
                lines = lab.logs[name].read_text().splitlines()
                relevant = [x for x in lines if any(word in x for word in ("scheme", "protocol", "dialer", "address", "listener", "WSS", "websocket", "x509"))]
                print(name, "\n".join(relevant[:10])[-4700:])
            raise
        assert unprivileged.poll() is None
        try:
            unauthorized = request(denied, "/hello", timeout=1.5)[0] == 200
        except OSError:
            unauthorized = False
        assert not unauthorized
        print(f"PASS OpenZiti host.v1 with stock tunnel binaries, {"WSS" if wss else "TLS"} edge router, Nginx and separate Dial/Bind policies", flush=True)
        cert, key = lab.certificates()
        extra = f"""    handle /edge/client/v1/* {{
        reverse_proxy https://{HOST}:{controller} {{
            transport http {{
                tls_trust_pool file {ca}
            }}
        }}
    }}"""
        lab.caddy({}, ingress, cert, key, extra)
        assert request(ingress, "/edge/client/v1/version", ca=cert)[0] == 200
        identity = json.loads((directory / "consumer.json").read_text())["id"]
        context = ssl.create_default_context(cafile=str(ca))
        client_cert, client_key = directory / "consumer.pem", directory / "consumer.key"
        client_cert.write_text(identity["cert"].removeprefix("pem:"))
        client_key.write_text(identity["key"].removeprefix("pem:"))
        context.load_cert_chain(client_cert, client_key)
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), urllib.request.HTTPSHandler(context=context))
        def auth(port, client):
            req = urllib.request.Request(
                f"https://{HOST}:{port}/edge/client/v1/authenticate?method=cert",
                data=b"{}", headers={"Content-Type": "application/json"}, method="POST",
            )
            try:
                with client.open(req, timeout=4) as response:
                    return response.status
            except urllib.error.HTTPError as exc:
                return exc.code
        assert auth(controller, opener) == 200
        context.load_verify_locations(cafile=str(cert))
        assert auth(ingress, opener) in (400, 401, 403)
        print("PASS OpenZiti controller cert authentication worked directly and failed behind the ordinary TLS-terminating path proxy", flush=True)


if __name__ == "__main__":
    import sys
    main("--wss" in sys.argv)
