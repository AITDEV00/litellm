import asyncio
import hmac
import json
import os
import resource
import secrets
import statistics
import subprocess
import sys
import tempfile
import time
from contextlib import AsyncExitStack
from pathlib import Path

import httpx
from starlette.applications import Starlette
from starlette.responses import JSONResponse, Response
from starlette.routing import Route

from async_support import launch, launch_ready, serve_http, wait_for_log
from common import BIN, free_port

FRP = BIN
CHISEL = str(BIN / "chisel")
VALIDATION = BIN
NGINX = BIN / "nginx"
LOOPBACK = "127.0.0.1"


def url(port, path=""):
    return f"http://{LOOPBACK}:{port}{path}"


def atomic_json(path, data):
    temp = path.with_suffix(".next")
    temp.write_text(json.dumps(data))
    temp.chmod(0o600)
    temp.replace(path)


async def eventually(check, seconds=12):
    until = time.monotonic() + seconds
    while True:
        try:
            if await check():
                return
        except httpx.HTTPError:
            pass
        if time.monotonic() >= until:
            raise AssertionError("condition did not become true")
        await asyncio.sleep(0.09)


async def responding(client, port, expected, path="/small"):
    response = await client.get(url(port, path), timeout=1.2)
    return response.status_code == 200 and response.content == expected


async def unavailable(client, port):
    try:
        response = await client.get(url(port, "/small"), timeout=0.8)
        return response.status_code >= 500
    except httpx.RequestError:
        return True


async def start_nginx(stack, directory):
    (directory / "www").mkdir()
    payloads = {"small": b'{"value":"mcp-transport"}', "large": b'{"value":"' + b"x" * (128 * 1024 - 12) + b'"}\n'}
    for name, payload in payloads.items():
        (directory / "www" / name).write_bytes(payload)
    port = free_port()
    path = directory / "nginx.conf"
    path.write_text(f"""master_process off;
daemon off;
pid nginx.pid;
error_log stderr;
events {{ worker_connections 256; }}
http {{
  access_log off;
  client_body_temp_path body;
  proxy_temp_path proxy;
  fastcgi_temp_path fastcgi;
  uwsgi_temp_path uwsgi;
  scgi_temp_path scgi;
  keepalive_requests 4096;
  server {{
    listen 127.0.0.1:{port};
    root "{directory / 'www'}";
    default_type application/json;
  }}
}}
""")
    await launch_ready(stack, directory, "fixture-nginx", port, str(NGINX), "-p", f"{directory}/", "-c", str(path), "-e", "stderr")
    return port, payloads


def frp_proxy(name, port, local):
    return {"name": name, "type": "tcp", "tcp": {"localIP": LOOPBACK, "localPort": local, "remotePort": port}}


def proc_stats(pid):
    raw = Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()
    cpu = int(raw[11]) + int(raw[12])
    rss = next(
        int(line.split()[1])
        for line in Path(f"/proc/{pid}/status").read_text().splitlines()
        if line.startswith("VmRSS:")
    )
    return cpu, rss


def percentile(values, pct):
    values = sorted(values)
    return values[min(len(values) - 1, int((len(values) - 1) * pct + 0.999999))]


async def measure(name, mode, run, port, pids, payloads):
    limits = httpx.Limits(max_connections=32, max_keepalive_connections=0 if mode == "fresh" else 32)
    path = "/large" if mode == "concurrent" else "/small"
    count = 100 if mode == "concurrent" else 80
    latency = []
    async with httpx.AsyncClient(limits=limits, trust_env=False, timeout=4) as client:
        async def request():
            t0 = time.perf_counter()
            response = await client.get(url(port, path))
            assert response.status_code == 200 and response.content == payloads[path[1:]]
            latency.append((time.perf_counter() - t0) * 1000)

        await request()
        latency.clear()
        before = [proc_stats(pid) for pid in pids]
        started = time.perf_counter()
        if mode == "concurrent":
            for start in range(0, count, 20):
                await asyncio.gather(*(request() for _ in range(start, min(count, start + 20))))
        else:
            for _ in range(count):
                await request()
        seconds = time.perf_counter() - started
        after = [proc_stats(pid) for pid in pids]
    assert len(latency) == count
    return {"transport": name, "mode": mode, "run": run, "requests": count,
            "p50_ms": round(statistics.median(latency), 3), "p95_ms": round(percentile(latency, .95), 3),
            "rps": round(count / seconds, 1), "seconds": round(seconds, 3),
            "cpu_ms": round(1000 * sum(a[0] - b[0] for a, b in zip(after, before)) / os.sysconf("SC_CLK_TCK"), 1),
            "rss_mib": [round(end[1] / 1024, 1) for end in after]}


async def test():
    async with AsyncExitStack() as stack:
        directory = Path(stack.enter_context(tempfile.TemporaryDirectory(prefix="mcp-transport-")))
        source_port, payloads = await start_nginx(stack, directory)
        small = payloads["small"]

        async def alternative(request):
            return Response(b'{"value":"different-endpoint"}', media_type="application/json")

        alt_port = await serve_http(stack, Starlette(routes=[Route("/small", alternative)]))
        cert, key = directory / "tls.pem", directory / "tls.key"
        subprocess.run(["openssl", "req", "-x509", "-newkey", "ed25519", "-noenc", "-days", "1",
                        "-subj", "/CN=127.0.0.1", "-addext", "subjectAltName=IP:127.0.0.1",
                        "-out", str(cert), "-keyout", str(key)], check=True, capture_output=True)
        chisel_relay, frps_port, ingress_port, chisel_lease, frp_lease, other_lease, admin, wrong_admin = (
            free_port() for _ in range(8)
        )
        chisel_auth = f"lab-connector:{secrets.token_hex(18)}"
        auth_file, chisel_key = directory / "users.json", directory / "relay.key"
        sentinel = {"deny-only:" + secrets.token_hex(24): []}
        chisel_grants = {**sentinel, chisel_auth: [rf"^R:127[.]0[.]0[.]1:{chisel_lease}$"]}
        atomic_json(auth_file, chisel_grants)
        subprocess.run([CHISEL, "server", "--keygen", str(chisel_key)], check=True, capture_output=True)
        chisel, chisel_log = await launch_ready(stack, directory, "chisel-relay", chisel_relay, CHISEL, "server",
                                               "--host", LOOPBACK, "--port", str(chisel_relay), "--reverse", "--verbose",
                                               "--authfile", str(auth_file), "--keyfile", str(chisel_key))
        fingerprint = (await wait_for_log(chisel, chisel_log, r"Fingerprint\s+(\S+)")).group(1)
        state = {"active": True, "unavailable": False, "local_fields": False, "close_plugin_connection": False}
        calls = {}
        member_token = secrets.token_hex(24)

        async def admit(request):
            request_data = await request.json()
            op, content = request_data["op"], request_data["content"]
            calls[op] = calls.get(op, 0) + 1
            if state["unavailable"]:
                return Response(status_code=503)
            if op == "Login":
                ident = content["user"]
                credential = content.get("metas", {}).get("lab-credential", "")
            else:
                identity = content["user"]
                ident = identity["user"]
                credential = identity.get("metas", {}).get("lab-credential", "")
            ok = state["active"] and ident == "member-a" and hmac.compare_digest(credential, member_token)
            if op == "NewProxy":
                state["local_fields"] |= bool({"local_ip", "local_port", "localIP", "localPort"} & content.keys())
                ok &= (content.get("proxy_name"), content.get("proxy_type"), content.get("remote_port")) == (
                    "member-a.source", "tcp", frp_lease
                ) and not content.get("group")
            headers = {"Connection": "close"} if state["close_plugin_connection"] else {}
            return JSONResponse({"reject": not ok, "reject_reason": "lease rejected" if not ok else "", "unchange": True},
                                headers=headers)

        plugin_port = await serve_http(stack, Starlette(routes=[Route("/admit", admit, methods=["POST"])]))
        shared = secrets.token_hex(24)
        frps_path = directory / "frps.toml"
        frps_path.write_text(f'''bindAddr = "{LOOPBACK}"
bindPort = {frps_port}
proxyBindAddr = "{LOOPBACK}"
auth.token = "{shared}"
allowPorts = [{{ single = {frp_lease} }}, {{ single = {other_lease} }}]
transport.maxPoolCount = 8
log.level = "warn"
[[httpPlugins]]
name = "fixture-admission"
addr = "{LOOPBACK}:{plugin_port}"
path = "/admit"
ops = ["Login", "NewProxy", "NewUserConn"]
''')
        frps, _ = await launch_ready(stack, directory, "frps", frps_port, str(FRP / "frps"), "-c", str(frps_path))
        caddy_path = directory / "Caddyfile"
        caddy_path.write_text(f'''{{
    admin off
    auto_https off
}}
https://{LOOPBACK}:{ingress_port} {{
    tls {cert} {key}
    handle /mcp-worker {{
        reverse_proxy {LOOPBACK}:{chisel_relay}
    }}
    handle /~!frp {{
        reverse_proxy {LOOPBACK}:{frps_port}
    }}
    handle {{
        respond 404
    }}
}}
''')
        await launch_ready(stack, directory, "caddy", ingress_port, str(VALIDATION / "caddy"), "run", "--config", str(caddy_path),
                           overrides={"XDG_CONFIG_HOME": str(directory / "config"), "XDG_DATA_HOME": str(directory / "data")})
        https = f"https://{LOOPBACK}:{ingress_port}"
        frpc_config, frpc_store = directory / "frpc.toml", directory / "store.json"
        local_auth = ("local-admin", secrets.token_hex(22))

        wire = "v2" if "--frp-v2" in sys.argv else "v1"

        def write_frpc(path, admin_port, store, ca, credential=member_token, pool=0):
            path.write_text(f'''serverAddr = "{LOOPBACK}"
serverPort = {ingress_port}
user = "member-a"
clientID = "member-a"
loginFailExit = true
auth.token = "{shared}"
metadatas.lab-credential = "{credential}"
transport.protocol = "wss"
transport.wireProtocol = "{wire}"
transport.poolCount = {pool}
transport.tls.enable = true
transport.tls.serverName = "{LOOPBACK}"
{ca}
log.level = "warn"
webServer.addr = "{LOOPBACK}"
webServer.port = {admin_port}
webServer.user = "{local_auth[0]}"
webServer.password = "{local_auth[1]}"
[store]
path = "{store}"
''')
            path.chmod(0o600)

        write_frpc(frpc_config, admin, frpc_store, f'transport.tls.trustedCaFile = "{cert}"')
        wrong_config = directory / "wrong-ca.toml"
        write_frpc(wrong_config, wrong_admin, directory / "wrong-store.json", "transport.tls.useSystemCa = true")
        wrong_id = directory / "wrong-id.toml"
        write_frpc(wrong_id, wrong_admin, directory / "wrong-id-store.json", f'transport.tls.trustedCaFile = "{cert}"', "invalid-fixture")

        async def fail_login(config, pattern):
            p = await asyncio.create_subprocess_exec(str(FRP / "frpc"), "-c", str(config), stdout=asyncio.subprocess.PIPE,
                                                    stderr=asyncio.subprocess.STDOUT,
                                                    env={k: v for k, v in os.environ.items() if not k.lower().endswith("_proxy")})
            out, _ = await asyncio.wait_for(p.communicate(), timeout=8)
            assert p.returncode and pattern in out.decode(), (p.returncode, out.decode())

        await fail_login(wrong_config, "certificate signed by unknown authority")
        await fail_login(wrong_id, "lease rejected")
        print("PASS frp WSS through Caddy with private CA, rejects untrusted CA and connector identity", flush=True)
        http = await stack.enter_async_context(httpx.AsyncClient(
            trust_env=False, timeout=3, limits=httpx.Limits(max_keepalive_connections=0)
        ))
        frpc_scope = await stack.enter_async_context(AsyncExitStack())
        frpc, _ = await launch_ready(frpc_scope, directory, "frpc-first", admin, str(FRP / "frpc"), "-c", str(frpc_config))
        api = url(admin, "/api/store/proxies")
        assert (await http.get(api)).status_code == 401
        read_config = await http.get(url(admin, "/api/config"), auth=local_auth)
        assert read_config.status_code == 200 and member_token in read_config.text
        status = await http.post(api, auth=local_auth, json=frp_proxy("source", frp_lease, source_port))
        assert status.status_code == 200, status.text
        await eventually(lambda: responding(http, frp_lease, small))
        assert frpc_store.is_file()
        print("PASS frpc loopback admin API requires auth, authorized raw-config read exposes config, Store create serves Nginx", flush=True)

        status = await http.post(api, auth=local_auth, json=frp_proxy("unapproved", other_lease, source_port))
        assert status.status_code == 200
        await eventually(lambda: unavailable(http, other_lease), seconds=4)
        deadline = time.monotonic() + 5
        while calls.get("NewProxy", 0) < 2 and time.monotonic() < deadline:
            await asyncio.sleep(.05)
        assert calls.get("NewProxy", 0) >= 2
        assert (await http.get(f"{api}/unapproved", auth=local_auth)).status_code == 200
        assert (await http.delete(f"{api}/unapproved", auth=local_auth)).is_success
        print("PASS denied frp lease stays unbound even though Store accepted and saved local desired config", flush=True)

        status = await http.put(f"{api}/source", auth=local_auth, json=frp_proxy("source", frp_lease, alt_port))
        assert status.is_success, status.text
        await eventually(lambda: responding(http, frp_lease, b'{"value":"different-endpoint"}'))
        assert not state["local_fields"], state
        print("PASS same approved frp listener carried an ordinary local target update; relay hook received no local destination", flush=True)
        assert (await http.put(f"{api}/source", auth=local_auth, json=frp_proxy("source", frp_lease, source_port))).is_success
        await eventually(lambda: responding(http, frp_lease, small))

        t0 = time.perf_counter()
        await frpc_scope.aclose()
        await eventually(lambda: unavailable(http, frp_lease))
        frpc_scope = await stack.enter_async_context(AsyncExitStack())
        frpc, _ = await launch_ready(frpc_scope, directory, "frpc-restored", admin, str(FRP / "frpc"), "-c", str(frpc_config))
        await eventually(lambda: responding(http, frp_lease, small))
        print(f"PASS frpc process restart restored Store proxy without another API write ({time.perf_counter() - t0:.3f} s)", flush=True)

        deleted = await http.delete(f"{api}/source", auth=local_auth)
        assert deleted.is_success
        await eventually(lambda: unavailable(http, frp_lease))
        assert (await http.get(f"{api}/source", auth=local_auth)).status_code == 404
        assert (await http.post(api, auth=local_auth, json=frp_proxy("source", frp_lease, source_port))).is_success
        await eventually(lambda: responding(http, frp_lease, small))
        print("PASS frpc Store DELETE withdrew the listener and re-create restored it", flush=True)

        async def start_chisel(cleanup, name):
            worker, log = await cleanup.enter_async_context(launch(directory, name, CHISEL, "client",
                "--fingerprint", fingerprint, "--tls-ca", str(cert), https + "/mcp-worker",
                f"R:{LOOPBACK}:{chisel_lease}:{LOOPBACK}:{source_port}", overrides={"AUTH": chisel_auth}))
            await wait_for_log(worker, log, r"Connected \(Latency")
            await eventually(lambda: responding(http, chisel_lease, small))
            return worker

        chisel_scope = await stack.enter_async_context(AsyncExitStack())
        worker = await start_chisel(chisel_scope, "chisel-client")
        if "--skip-bench" not in sys.argv:
            frp_name = "frp_v2" if wire == "v2" else "frp"
            states = {"chisel": (chisel_lease, [chisel.pid, worker.pid]), frp_name: (frp_lease, [frps.pid, frpc.pid])}
            print(f"BENCH source=Nginx small={len(small)} large={len(payloads['large'])} cpu_clock_hz={os.sysconf('SC_CLK_TCK')}"
                  f" cpu_affinity={len(os.sched_getaffinity(0))} rusage={resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}", flush=True)
            for trial in range(1, 4):
                for mode in ("fresh", "warm", "concurrent"):
                    for name in (("chisel", frp_name) if trial % 2 else (frp_name, "chisel")):
                        port, pids = states[name]
                        print("BENCH " + json.dumps(await measure(name, mode, trial, port, pids, payloads)), flush=True)
            await frpc_scope.aclose()
            await eventually(lambda: unavailable(http, frp_lease))
            write_frpc(frpc_config, admin, frpc_store, f'transport.tls.trustedCaFile = "{cert}"', pool=8)
            frpc_scope = await stack.enter_async_context(AsyncExitStack())
            frpc, _ = await launch_ready(frpc_scope, directory, "frpc-pooled", admin, str(FRP / "frpc"), "-c", str(frpc_config))
            await eventually(lambda: responding(http, frp_lease, small))
            await asyncio.sleep(0.3)
            for trial in range(1, 4):
                for mode in ("fresh", "warm", "concurrent"):
                    print("BENCH " + json.dumps(await measure(
                        f"{frp_name}_pool8", mode, trial, frp_lease, [frps.pid, frpc.pid], payloads,
                    )), flush=True)

        async with httpx.AsyncClient(trust_env=False, timeout=3) as keepalive:
            assert await responding(keepalive, frp_lease, small)
            state["active"] = False
            await eventually(lambda: unavailable(http, frp_lease))
            hook_count = calls["NewUserConn"]
            assert await responding(keepalive, frp_lease, small)
            assert calls["NewUserConn"] == hook_count
        state["active"] = True
        state["unavailable"] = True
        await eventually(lambda: unavailable(http, frp_lease))
        state["unavailable"] = False
        await eventually(lambda: responding(http, frp_lease, small))
        assert frpc.returncode is None
        print("PASS frps NewUserConn hook blocked new TCP streams after revoke and failed closed on plugin error; existing HTTP keepalive still served a read", flush=True)

        atomic_json(auth_file, sentinel)
        await wait_for_log(chisel, chisel_log, "Users configuration successfully reloaded")
        assert await responding(http, chisel_lease, small)
        await chisel_scope.aclose()
        await eventually(lambda: unavailable(http, chisel_lease))
        async with AsyncExitStack() as revoked:
            process, log = await revoked.enter_async_context(launch(directory, "chisel-revoked", CHISEL, "client",
                "--fingerprint", fingerprint, "--tls-ca", str(cert), https + "/mcp-worker",
                f"R:{LOOPBACK}:{chisel_lease}:{LOOPBACK}:{source_port}", overrides={"AUTH": chisel_auth}))
            await wait_for_log(process, log, r"authentication failed|unable to authenticate|permission denied")
        print("PASS Chisel deny-only entry preserved authentication when final connector was removed; established tunnel remained usable until disconnected", flush=True)
        atomic_json(auth_file, chisel_grants)
        deadline = time.monotonic() + 5
        while chisel_log.read_text().count("Users configuration successfully reloaded") < 2 and time.monotonic() < deadline:
            await asyncio.sleep(.05)
        t0 = time.perf_counter()
        restored = await start_chisel(stack, "chisel-restored")
        print(f"PASS Chisel reconnected on the same lease ({time.perf_counter() - t0:.3f} s after starting client)", flush=True)

        secondary_secret = f"lab-reports:{secrets.token_hex(18)}"
        secondary_grant = {secondary_secret: [rf"^R:127[.]0[.]0[.]1:{other_lease}$"]}
        atomic_json(auth_file, {**chisel_grants, **secondary_grant})
        deadline = time.monotonic() + 5
        while chisel_log.read_text().count("Users configuration successfully reloaded") < 3 and time.monotonic() < deadline:
            await asyncio.sleep(.05)
        async with AsyncExitStack() as secondary:
            extra, log = await secondary.enter_async_context(launch(directory, "chisel-reports", CHISEL, "client",
                "--fingerprint", fingerprint, "--tls-ca", str(cert), https + "/mcp-worker",
                f"R:{LOOPBACK}:{other_lease}:{LOOPBACK}:{alt_port}", overrides={"AUTH": secondary_secret}))
            await wait_for_log(extra, log, r"Connected \(Latency")
            await eventually(lambda: responding(http, other_lease, b'{"value":"different-endpoint"}'))
            assert restored.returncode is None and await responding(http, chisel_lease, small)
        atomic_json(auth_file, chisel_grants)
        await eventually(lambda: unavailable(http, other_lease))
        assert restored.returncode is None and await responding(http, chisel_lease, small)
        print("PASS adding and removing a separate preapproved Chisel lease left the existing connector and relay serving", flush=True)

        if "--hook-control" in sys.argv:
            controlled = (
                ("frp_login_lease_hooks", frps_path.read_text().replace('["Login", "NewProxy", "NewUserConn"]',
                                                                        '["Login", "NewProxy"]'), False),
                ("frp_all_hooks_close_http", frps_path.read_text(), True),
                ("frp_all_hooks_keepalive", frps_path.read_text(), False),
            )
        elif "--no-plugin-control" in sys.argv:
            controlled = (("frp_v1_no_plugin", frps_path.read_text().split("[[httpPlugins]]", 1)[0], False),)
        else:
            controlled = ()

        if controlled:
            await frpc_scope.aclose()
            await eventually(lambda: unavailable(http, frp_lease))
            frps.terminate()
            await asyncio.wait_for(frps.wait(), timeout=8)
            for name, config, close_http in controlled:
                state["close_plugin_connection"] = close_http
                control_path = directory / f"{name}.toml"
                control_path.write_text(config)
                async with AsyncExitStack() as comparison:
                    control_server, _ = await launch_ready(comparison, directory, name + "-server", frps_port, str(FRP / "frps"),
                                                          "-c", str(control_path))
                    write_frpc(frpc_config, admin, frpc_store, f'transport.tls.trustedCaFile = "{cert}"')
                    control_client, _ = await launch_ready(comparison, directory, name + "-client", admin, str(FRP / "frpc"),
                                                          "-c", str(frpc_config))
                    await eventually(lambda: responding(http, frp_lease, small))
                    for trial in range(1, 4):
                        for mode in ("fresh", "warm", "concurrent"):
                            print("BENCH " + json.dumps(await measure(name, mode, trial, frp_lease,
                                                                      [control_server.pid, control_client.pid], payloads)), flush=True)
                    if "NewUserConn" in config:
                        state["active"] = False
                        await eventually(lambda: unavailable(http, frp_lease))
                        state["active"] = True
                        await eventually(lambda: responding(http, frp_lease, small))
                        print(f"PASS {name} still denied new streams when membership was revoked", flush=True)


if __name__ == "__main__":
    asyncio.run(test())
