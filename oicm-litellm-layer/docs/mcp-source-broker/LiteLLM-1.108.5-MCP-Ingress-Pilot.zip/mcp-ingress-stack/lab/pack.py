"""Build the single handoff archive without local fixtures, caches or credentials."""
import argparse
import zipfile
from pathlib import Path

from common import ROOT

OUTPUT = ROOT.parent / "LiteLLM-1.108.5-MCP-Ingress-Pilot.zip"
TOP = ("README.md", "RESULTS.md", "Makefile", "go.mod", "go.sum", "main.go", "gateway.go", "connector.go",
       "pool.go", "install.sh", "register_mcp.py", "bin/source-link", "bin/source-link.sha256")
DIRECTORIES = ("lab", "systemd", "examples", "evidence", "third-party-licenses")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=OUTPUT)
    args = parser.parse_args()
    files = [ROOT / name for name in TOP]
    for directory in DIRECTORIES:
        files.extend(
            path for path in (ROOT / directory).rglob("*")
            if path.is_file() and not path.is_symlink() and "__pycache__" not in path.parts
            and path.suffix not in {".pyc", ".tmp"}
        )
    with zipfile.ZipFile(args.output, "w", zipfile.ZIP_DEFLATED, compresslevel=8) as archive:
        for path in sorted(files):
            archive.write(path, Path("mcp-ingress-stack") / path.relative_to(ROOT))
    with zipfile.ZipFile(args.output) as archive:
        assert archive.testzip() is None
    print(f"{args.output.name}: {len(files)} files, {args.output.stat().st_size:,} bytes")


if __name__ == "__main__":
    main()
