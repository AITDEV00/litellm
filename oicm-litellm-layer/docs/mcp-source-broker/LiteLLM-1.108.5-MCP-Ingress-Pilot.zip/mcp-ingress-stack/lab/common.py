import contextlib
import http.client
import json
import os
import secrets
import socket
import ssl
import subprocess
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BIN = Path(os.environ.get("MCP_LAB_BIN", ROOT / ".lab-bin"))
SOURCE_LINK = Path(os.environ.get("SOURCE_LINK", ROOT / "bin/source-link"))
HOST = "127.0.0.1"


def free_port():
    with socket.socket() as sock:
        sock.bind((HOST, 0))
        return sock.getsockname()[1]


def private(path, data):
    if not isinstance(data, str):
        data = json.dumps(data)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as file:
        file.write(data)


def eventually(check, timeout=12):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        try:
            if result := check():
                return result
        except (OSError, http.client.HTTPException):
            pass
        time.sleep(0.05)
    raise AssertionError("condition did not become true")


def wait_port(port):
    def connected():
        with socket.create_connection((HOST, port), timeout=0.5):
            return True

    eventually(connected)


def stop(process):
    if process.poll() is None:
        process.terminate()
        try:
            process.wait(4)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(5)


class Lab:
    def __enter__(self):
        self.stack = contextlib.ExitStack()
        self.directory = Path(self.stack.enter_context(tempfile.TemporaryDirectory(prefix="source-link-")))
        self.logs = {}
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.stack.close()
        if exc_type is not None:
            # Logs can include short-lived fixture credentials. Print only paths and statuses by default.
            print("Failed lab commands:", ", ".join(self.logs), flush=True)

    def process(self, name, *command, wait=None, env=None, **kwargs):
        path = self.directory / (name + ".log")
        self.logs[name] = path
        with path.open("w") as output:
            process = subprocess.Popen(
                command, stdout=output, stderr=subprocess.STDOUT, cwd=self.directory,
                env={**{k: v for k, v in os.environ.items() if not k.lower().endswith("_proxy")}, **(env or {})}, **kwargs,
            )
        self.stack.callback(stop, process)
        if wait is not None:
            wait_port(wait)
        return process

    def certificates(self):
        cert, key = self.directory / "tls.pem", self.directory / "tls.key"
        subprocess.run([
            "openssl", "req", "-x509", "-newkey", "ed25519", "-noenc", "-days", "1",
            "-subj", "/CN=127.0.0.1", "-addext", "subjectAltName=IP:127.0.0.1,DNS:localhost",
            "-out", str(cert), "-keyout", str(key),
        ], check=True, capture_output=True)
        return cert, key

    def caddy(self, routes, port, cert, key, extra=""):
        conf = self.directory / "Caddyfile"
        parts = "\n".join(
            f"    handle {path} {{\n        reverse_proxy {HOST}:{target}\n    }}"
            for path, target in routes.items()
        )
        conf.write_text(f"""{{
    admin off
    auto_https off
}}
https://{HOST}:{port} {{
    bind {HOST}
    tls {cert} {key}
{parts}
{extra}
    handle {{
        respond 404
    }}
}}
""")
        return self.process("caddy", BIN / "caddy", "run", "--adapter", "caddyfile", "--config", conf, wait=port,
                            env={"XDG_CONFIG_HOME": str(self.directory), "XDG_DATA_HOME": str(self.directory)})


def request(port, path, method="GET", body=None, headers=None, ca=None, timeout=4):
    tls = ssl.create_default_context(cafile=str(ca)) if ca else None
    scheme = "https" if tls else "http"
    handler = urllib.request.HTTPSHandler(context=tls) if tls else urllib.request.HTTPHandler()
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), handler)
    req = urllib.request.Request(
        f"{scheme}://{HOST}:{port}{path}",
        data=json.dumps(body).encode() if body is not None else None,
        method=method,
        headers={"Content-Type": "application/json", **(headers or {})},
    )
    try:
        with opener.open(req, timeout=timeout) as response:
            return response.status, response.read()
    except urllib.error.HTTPError as exc:
        with exc:
            return exc.code, exc.read()


class Gateway:
    def __init__(self, lab, sources, members):
        self.lab = lab
        self.ingress, self.data, self.admin = [free_port() for _ in range(3)]
        self.admin_key = secrets.token_urlsafe(32)
        self.data_key = secrets.token_urlsafe(32)
        data_key = lab.directory / "data.secret"
        private(data_key, self.data_key)
        key = lab.directory / "admin.secret"
        self.config = lab.directory / "gateway.json"
        self.state = lab.directory / "state.json"
        private(key, self.admin_key)
        private(self.config, {
            "ingress_listen": f"{HOST}:{self.ingress}", "data_listen": f"{HOST}:{self.data}",
            "admin_listen": f"{HOST}:{self.admin}", "admin_key_file": str(key),
            "data_key_file": str(data_key), "state_file": str(self.state), "artifact_dir": str(SOURCE_LINK.parent),
            "sources": sources, "members": members,
        })

    def start(self, name="gateway"):
        return self.lab.process(name, SOURCE_LINK, "gateway", "-config", self.config, wait=self.admin)

    def admin_request(self, path, method="GET", body=None):
        return request(self.admin, path, method, body, {"Authorization": "Bearer " + self.admin_key})

    def data_request(self, path, method="GET", body=None):
        return request(self.data, path, method, body, {"X-Source-Broker-Key": self.data_key})

    def status(self):
        code, body = self.admin_request("/members")
        assert code == 200, (code, body)
        return json.loads(body)

    def mutate(self, member, action, generation, expected=200):
        code, body = self.admin_request(f"/members/{member}/{action}", "POST", {"generation": generation})
        assert code == expected, (member, action, code, body)
        return json.loads(body) if code == 200 else None

    def enrollment(self, member, ingress, cert, action="invite", generation=0):
        ticket = self.mutate(member, action, generation)["ticket"]
        return enroll(self.lab, member, ingress, cert, ticket)

    def wait_ready(self, member, source):
        eventually(lambda: self.status().get(member, {}).get("ready", {}).get(source) is True)


def enroll(lab, member, ingress, cert, ticket):
    path = lab.directory / f"{member}.json"
    subprocess.run(
        [SOURCE_LINK, "enroll", "-config", path, "-gateway", f"https://{HOST}:{ingress}",
         "-ca", cert, "-ticket-file", "-"],
        input=(ticket + "\n").encode(), capture_output=True, check=True,
    )
    assert path.stat().st_mode & 0o777 == 0o600
    return path


def connector(lab, path, name):
    return lab.process(name, SOURCE_LINK, "connector", "-config", path)


def nginx(lab, port, root, name="nginx"):
    config = lab.directory / f"{name}.conf"
    config.write_text(f"""
master_process off;
daemon off;
pid {name}.pid;
error_log stderr;
events {{ worker_connections 256; }}
http {{
  access_log off;
  client_body_temp_path {name}-body;
  proxy_temp_path {name}-proxy;
  fastcgi_temp_path {name}-fastcgi;
  uwsgi_temp_path {name}-uwsgi;
  scgi_temp_path {name}-scgi;
  keepalive_requests 8192;
  server {{
    listen 127.0.0.1:{port};
    root "{root}";
    default_type application/json;
  }}
}}
""")
    return lab.process(name, BIN / "nginx", "-p", f"{lab.directory}/", "-c", config, "-e", "stderr", wait=port)
