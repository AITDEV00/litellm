import array
import fcntl
import json
import os
import socket
import struct
import subprocess
import sys
import threading
from pathlib import Path

from common import HOST, Gateway, Lab, connector, enroll, free_port, nginx, request, stop


def inside(control_fd, plan):
    control = socket.socket(fileno=control_fd)
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        request_flags = struct.pack("16sh22x", b"lo", 0)
        flags = struct.unpack("16sh22x", fcntl.ioctl(sock, 0x8913, request_flags))[1]
        fcntl.ioctl(sock, 0x8914, struct.pack("16sh22x", b"lo", flags | 1))
    interfaces = {x.split(":")[0].strip() for x in Path("/proc/net/dev").read_text().splitlines() if ":" in x}
    assert interfaces == {"lo"}, interfaces
    with Lab() as lab:
        cert, key = map(Path, plan["certificate"])
        # The only non-loopback descriptor passed into this namespace is the control socket.
        try:
            request(plan["source_port"], "/hello", timeout=0.5)
        except OSError:
            pass
        else:
            raise AssertionError("gateway unexpectedly dialed outside origin directly")
        g = Gateway(lab, {"hello": {"http_host": "fixture", "probe_path": "/hello", "read_paths": ["/hello"]}},
                    {"worker-a": {"targets": {"hello": f"{HOST}:{plan['source_port']}"}}})
        g.start()
        private_tls = free_port()
        lab.caddy({"/mcp-worker": g.ingress, "/connectors/*": g.ingress}, private_tls, cert, key)

        def copy(source, target):
            try:
                while packet := source.recv(65536):
                    target.sendall(packet)
            except OSError:
                pass
            finally:
                try:
                    target.shutdown(socket.SHUT_WR)
                except OSError:
                    pass

        def bridge(forwarded):
            with socket.socket(fileno=forwarded) as stream, socket.create_connection((HOST, private_tls)) as backend:
                sender = threading.Thread(target=copy, args=(stream, backend), daemon=True)
                sender.start()
                copy(backend, stream)
                sender.join(3)

        def receive():
            while True:
                payload, ancillary, *_ = control.recvmsg(1, socket.CMSG_SPACE(array.array("i", [0]).itemsize))
                if not payload:
                    return
                for level, kind, data in ancillary:
                    if (level, kind) == (socket.SOL_SOCKET, socket.SCM_RIGHTS):
                        fds = array.array("i")
                        fds.frombytes(data[:fds.itemsize])
                        threading.Thread(target=bridge, args=(fds[0],), daemon=True).start()

        ticket = g.mutate("worker-a", "invite", 0)["ticket"]
        print(json.dumps({"namespace": os.readlink("/proc/self/ns/net"), "ticket": ticket}), flush=True)
        thread = threading.Thread(target=receive, daemon=True)
        thread.start()
        g.wait_ready("worker-a", "hello")
        assert g.data_request("/sources/hello/hello") == (200, b"outbound-only-nginx")
        print("PASS gateway inside a loopback-only network namespace could read outside Nginx only over the connector-initiated HTTPS WebSocket", flush=True)


def outside():
    with Lab() as lab, socket.socket() as ingress:
        origin = free_port()
        www = lab.directory / "www"
        www.mkdir()
        (www / "hello").write_text("outbound-only-nginx")
        nginx(lab, origin, www)
        cert, key = lab.certificates()
        ingress.bind((HOST, 0))
        ingress.listen()
        ingress.settimeout(0.25)
        parent, child = socket.socketpair()
        with parent, child:
            plan = json.dumps({"source_port": origin, "certificate": [str(cert), str(key)]})
            inner = subprocess.Popen(["unshare", "-Urn", sys.executable, __file__, "inside", str(child.fileno()), plan],
                                     pass_fds=(child.fileno(),), stdout=subprocess.PIPE, text=True)
            lab.stack.callback(stop, inner)
            child.close()

            def accept():
                while inner.poll() is None:
                    try:
                        stream, _ = ingress.accept()
                    except socket.timeout:
                        continue
                    except OSError:
                        return
                    with stream:
                        try:
                            parent.sendmsg([b"w"], [(socket.SOL_SOCKET, socket.SCM_RIGHTS,
                                                     array.array("i", [stream.fileno()]))])
                        except OSError:
                            return

            thread = threading.Thread(target=accept, daemon=True)
            thread.start()
            assert inner.stdout is not None
            handshake = inner.stdout.readline()
            assert handshake, f"isolated gateway failed: {inner.poll()}"
            state = json.loads(handshake)
            assert state["namespace"] != os.readlink("/proc/self/ns/net")
            # Use the same CLI and enrollment HTTPS path a real connector uses.
            path = enroll(lab, "worker-a", ingress.getsockname()[1], cert, state["ticket"])
            connector(lab, path, "outside-connector")
            output, _ = inner.communicate(timeout=25)
            assert inner.returncode == 0, output
            print(output, end="")


if __name__ == "__main__":
    if sys.argv[1:2] == ["inside"]:
        inside(int(sys.argv[2]), json.loads(sys.argv[3]))
    else:
        outside()
