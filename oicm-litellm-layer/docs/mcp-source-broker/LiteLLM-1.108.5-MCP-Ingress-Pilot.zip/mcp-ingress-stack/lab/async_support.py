import asyncio
import os
import re
from contextlib import asynccontextmanager

import uvicorn

from common import HOST, free_port


@asynccontextmanager
async def launch(directory, name, *command, overrides=None):
    env = {k: v for k, v in os.environ.items() if not k.lower().endswith("_proxy")}
    env.update(overrides or {})
    log = directory / f"{name}.log"
    with log.open("w") as output:
        process = await asyncio.create_subprocess_exec(*command, env=env, stdout=output, stderr=output)
        try:
            yield process, log
        finally:
            if process.returncode is None:
                process.terminate()
                try:
                    await asyncio.wait_for(process.wait(), timeout=5)
                except TimeoutError:
                    process.kill()
                    await process.wait()


async def launch_ready(stack, directory, name, port, *command, overrides=None):
    process, log = await stack.enter_async_context(launch(directory, name, *command, overrides=overrides))
    async with asyncio.timeout(10):
        while True:
            if process.returncode is not None:
                raise RuntimeError(f"{name} stopped before binding (status {process.returncode})")
            try:
                _, writer = await asyncio.open_connection(HOST, port)
            except OSError:
                await asyncio.sleep(0.04)
            else:
                writer.close()
                await writer.wait_closed()
                return process, log


async def wait_for_log(process, log, pattern):
    async with asyncio.timeout(12):
        while not (match := re.search(pattern, log.read_text(), re.MULTILINE)):
            if process.returncode is not None:
                raise RuntimeError(f"{log.name} stopped before logging {pattern} (status {process.returncode})")
            await asyncio.sleep(0.05)
        return match


async def serve_http(stack, app):
    port = free_port()
    server = uvicorn.Server(uvicorn.Config(app, host=HOST, port=port, log_level="error", timeout_graceful_shutdown=2))
    task = asyncio.create_task(server.serve())

    async def stop():
        server.should_exit = True
        await task

    stack.push_async_callback(stop)
    async with asyncio.timeout(7):
        while not server.started:
            if task.done():
                await task
                raise RuntimeError("fixture stopped before binding")
            await asyncio.sleep(0.04)
    return port
