import argparse
import concurrent.futures
import http.client
import json
import math
import os
import re
import secrets
import statistics
import subprocess
import time
import uuid
from pathlib import Path

import gost
from common import BIN, HOST, Gateway, Lab, connector, eventually, free_port, nginx, private, request


def chisel(lab, relay, ingress, local, source, cert):
    secret = "fixture:" + secrets.token_urlsafe(22)
    grants, key = lab.directory / "chisel.json", lab.directory / "chisel.key"
    private(grants, {secret: [rf"^R:127[.]0[.]0[.]1:{local}$"]})
    subprocess.run([BIN / "chisel", "server", "--keygen", key], check=True, capture_output=True)
    relay_process = lab.process("chisel-relay", BIN / "chisel", "server", "--host", HOST, "--port", str(relay),
                                "--reverse", "--authfile", grants, "--keyfile", key, wait=relay)
    fingerprint = eventually(lambda: re.search(r"Fingerprint\s+(\S+)", lab.logs["chisel-relay"].read_text()))[1]
    client = lab.process("chisel-client", BIN / "chisel", "client", "--fingerprint", fingerprint, "--tls-ca", cert,
                         f"https://{HOST}:{ingress}/chisel-worker", f"R:{HOST}:{local}:{HOST}:{source}", env={"AUTH": secret})
    return [relay_process, client]


def frp(lab, relay, ingress, local, source, cert):
    token = secrets.token_urlsafe(32)
    server, client = lab.directory / "frps.toml", lab.directory / "frpc.toml"
    private(server, f"""bindAddr = "{HOST}"
bindPort = {relay}
proxyBindAddr = "{HOST}"
auth.token = "{token}"
allowPorts = [{{ single = {local} }}]
log.level = "warn"
""")
    private(client, f"""serverAddr = "{HOST}"
serverPort = {ingress}
user = "lab"
clientID = "lab"
loginFailExit = false
auth.token = "{token}"
transport.protocol = "wss"
transport.wireProtocol = "v1"
transport.tls.enable = true
transport.tls.serverName = "{HOST}"
transport.tls.trustedCaFile = "{cert}"
log.level = "warn"
[[proxies]]
name = "nginx"
type = "tcp"
localIP = "{HOST}"
localPort = {source}
remotePort = {local}
""")
    return [lab.process("frps", BIN / "frps", "-c", server, wait=relay),
            lab.process("frpc", BIN / "frpc", "-c", client)]


def process_stats(process):
    ticks = os.sysconf("SC_CLK_TCK")
    directory = Path(f"/proc/{process.pid}")
    fields = (directory / "stat").read_text().rsplit(")", 1)[1].split()
    rss = next(int(line.split()[1]) for line in (directory / "status").read_text().splitlines()
               if line.startswith("VmRSS:"))
    return (int(fields[11]) + int(fields[12])) * 1000 / ticks, round(rss / 1024, 1)


def measure(name, port, processes, common, mode, rep, small, large):
    path, payload = ("/large", large) if mode == "concurrent" else ("/hello", small)
    count = 120 if mode == "concurrent" else 100

    def call(connection):
        start = time.perf_counter()
        connection.request("GET", path, headers={"Connection": "close"} if mode == "fresh" else {})
        response = connection.getresponse()
        actual = response.read()
        assert response.status == 200 and actual == payload, (name, response.status, len(actual), len(payload))
        return (time.perf_counter() - start) * 1000

    processes = [*processes, common]
    before = [process_stats(process)[0] for process in processes]
    start = time.perf_counter()
    if mode == "concurrent":
        def workload(_):
            connection = http.client.HTTPConnection(HOST, port, timeout=8)
            try:
                return [call(connection) for _ in range(count // 20)]
            finally:
                connection.close()
        with concurrent.futures.ThreadPoolExecutor(20) as pool:
            latency = sum(pool.map(workload, range(20)), [])
    else:
        connection = http.client.HTTPConnection(HOST, port, timeout=8)
        try:
            latency = [call(connection) for _ in range(count)]
        finally:
            connection.close()
    seconds = time.perf_counter() - start
    after = [process_stats(process) for process in processes]
    return {"stack": name, "mode": mode, "repeat": rep, "requests": count,
            "p50_ms": round(statistics.median(latency), 3),
            "p95_ms": round(sorted(latency)[math.ceil(.95 * count) - 1], 3),
            "requests_per_s": round(count / seconds, 1),
            "cpu_ms": round(sum(x[0] for x in after) - sum(before), 1),
            "rss_mib_by_process_caddy_last": [x[1] for x in after]}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repeats", type=int, default=3)
    args = parser.parse_args()
    with Lab() as lab:
        ingress, source, link_port, gost_port, gost_local, chisel_port, chisel_local, frp_port, frp_local = [
            free_port() for _ in range(9)
        ]
        root = lab.directory / "www"
        root.mkdir()
        small = b'{"status":"ok"}'
        large = b'"' + (b"x" * (128 * 1024 - 2)) + b'"'
        (root / "hello").write_bytes(small)
        (root / "large").write_bytes(large)
        nginx(lab, source, root)
        g = Gateway(lab, {"nginx": {"tcp_listen": f"{HOST}:{link_port}", "leader": "worker-a"}},
                    {"worker-a": {"targets": {"nginx": f"{HOST}:{source}"}}})
        link_server = g.start()
        cert, key = lab.certificates()
        caddy = lab.caddy({"/mcp-worker": g.ingress, "/connectors/*": g.ingress, "/gost-worker": gost_port,
                           "/chisel-worker": chisel_port, "/~!frp": frp_port}, ingress, cert, key)
        link_client = connector(lab, g.enrollment("worker-a", ingress, cert), "link-worker")
        g.wait_ready("worker-a", "nginx")
        tokens = {name: secrets.token_urlsafe(22) for name in ("worker", "visitor")}
        gost_relay = gost.relay(lab, gost_port, tokens)
        tunnel_id = str(uuid.uuid4())
        gost_worker = gost.attach(lab, "worker", "worker", tokens["worker"], tunnel_id,
                                  f"{HOST}:{source}", ingress, cert, quiet=True)
        gost_visitor = gost.attach(lab, "visitor", "visitor", tokens["visitor"], tunnel_id,
                                   "fixture.invalid:80", gost_port, cert, visitor=gost_local, direct=True, quiet=True)
        stacks = {
            "remotedialer": (link_port, [link_server, link_client]),
            "gost": (gost_local, [gost_relay, gost_worker, gost_visitor]),
            "chisel": (chisel_local, chisel(lab, chisel_port, ingress, chisel_local, source, cert)),
            "frp": (frp_local, frp(lab, frp_port, ingress, frp_local, source, cert)),
        }
        for name, (port, _) in stacks.items():
            try:
                eventually(lambda: request(port, "/hello") == (200, small))
            except Exception:
                for label in lab.logs:
                    if name in label or label in ("frps", "frpc", "caddy", "gateway"):
                        print(label, lab.logs[label].read_text()[-1400:])
                raise RuntimeError(f"{name} transport did not become ready") from None
        for rep in range(1, args.repeats + 1):
            order = list(stacks)
            order = order[rep % len(order):] + order[:rep % len(order)]
            for mode in ("fresh", "keepalive", "concurrent"):
                for name in order:
                    port, processes = stacks[name]
                    print(json.dumps(measure(name, port, processes, caddy, mode, rep, small, large)), flush=True)


if __name__ == "__main__":
    main()
