import hashlib
import os
import subprocess
from pathlib import Path

from common import HOST, ROOT, SOURCE_LINK, Gateway, Lab, free_port, nginx, private, request


def main():
    with Lab() as lab:
        origin, ingress = free_port(), free_port()
        fixture = lab.directory / "fixture"
        fixture.mkdir()
        (fixture / "hello").write_text("installed-worker")
        nginx(lab, origin, fixture)
        g = Gateway(lab, {"hello": {"http_host": "fixture", "probe_path": "/hello", "read_paths": ["/hello"]}},
                    {"worker-a": {"targets": {"hello": f"{HOST}:{origin}"}}})
        g.start()
        cert, key = lab.certificates()
        lab.caddy({"/mcp-worker": g.ingress, "/connectors/*": g.ingress}, ingress, cert, key)
        ticket = g.mutate("worker-a", "invite", 0)["ticket"]
        ticket_file = lab.directory / "bootstrap.secret"
        private(ticket_file, ticket)
        service_commands = lab.directory / "service-commands"
        fake = lab.directory / "fake-bin"
        fake.mkdir()
        ctl = fake / "systemctl"
        ctl.write_text('#!/bin/sh\nprintf "%s\n" "$*" >> "$MCP_LAB_SERVICE_COMMANDS"\n')
        ctl.chmod(0o700)
        home = lab.directory / "home"
        home.mkdir()
        env = {k: v for k, v in os.environ.items() if not k.lower().endswith("_proxy")}
        env.update({"HOME": str(home), "PATH": f"{fake}:{os.environ['PATH']}",
                    "MCP_LAB_SERVICE_COMMANDS": str(service_commands)})
        digest = hashlib.sha256(SOURCE_LINK.read_bytes()).hexdigest()

        def install(expected):
            return subprocess.run([ROOT / "install.sh", f"https://{HOST}:{ingress}", expected, ticket_file, cert],
                                  env=env, check=False, capture_output=True, timeout=30)

        assert install("0" * 64).returncode != 0
        assert g.status()["worker-a"]["phase"] == "pending"
        result = install(digest)
        assert result.returncode == 0, result.stderr.decode()
        binary = home / ".local/bin/source-link"
        config = home / ".config/source-link/connector.json"
        unit = home / ".config/systemd/user/source-link-connector.service"
        assert binary.stat().st_mode & 0o777 == 0o700
        assert config.stat().st_mode & 0o777 == 0o600
        assert unit.read_bytes() == (ROOT / "systemd/source-link-connector.service").read_bytes()
        assert "--user enable source-link-connector.service" in service_commands.read_text()
        assert "--user restart source-link-connector.service" in service_commands.read_text()
        installed = lab.process("installed-connector", binary, "connector", "-config", config)
        assert ticket.encode() not in Path(f"/proc/{installed.pid}/cmdline").read_bytes()
        g.wait_ready("worker-a", "hello")
        assert g.data_request("/sources/hello/hello") == (200, b"installed-worker")
        assert request(ingress, "/connectors/enroll", "POST", {"ticket": ticket}, ca=cert)[0] == 401
        print("PASS installer rejected a bad hash, enrolled over verified TLS, wrote owner-only config, requested systemd enable/restart and ran the exact downloaded binary")
        print("NOTE systemctl was stubbed in this fixture. A real machine boot was outside the lab.")


if __name__ == "__main__":
    main()
