import asyncio
import base64
import hashlib
import importlib.metadata
import json
import os
import secrets
import subprocess
import sys
import uuid
from collections import Counter
from contextlib import asynccontextmanager
from pathlib import Path
from importlib.util import find_spec
from urllib.parse import quote

import httpx
import psycopg
import uvicorn
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from starlette.applications import Starlette
from starlette.responses import JSONResponse
from starlette.routing import Route

from common import HOST, ROOT, Gateway, Lab, connector, eventually, free_port, private, request, stop

BLOCK = "block-this-synthetic-topic"
ALIAS = "source_link_fixture"
SCHEMA = Path(os.environ.get("LITELLM_SCHEMA") or Path(find_spec("litellm").origin).parent / "proxy/schema.prisma")


def auth(key):
    return {"Authorization": f"Bearer {key}"}


def catalog():
    return {
        "openapi": "3.0.3", "info": {"title": "Document fixture", "version": "1"},
        "paths": {"/source": {"get": {"operationId": "read_source", "summary": "Read one synthetic document",
                  "parameters": [{"in": "query", "name": "topic", "required": True, "schema": {"type": "string"}}],
                  "responses": {"200": {"description": "Document data"}}}}},
    }


def pg_bin():
    if path := os.environ.get("PG_BIN"):
        return Path(path)
    import embedded_postgres
    return Path(embedded_postgres.__file__).parent / "pginstall/bin"


def start_postgres(lab):
    directory = lab.directory
    port = free_port()
    password = secrets.token_urlsafe(22)
    pw = directory / "pg.secret"
    pg = pg_bin()
    private(pw, password + "\n")
    subprocess.run([pg / "initdb", "-D", directory / "postgres", "-U", "postgres", "--no-sync",
                    "--auth-host=scram-sha-256", "--auth-local=trust", "--pwfile", pw], check=True, capture_output=True)
    pw.unlink()
    lab.process("postgres", pg / "postgres", "-D", directory / "postgres", "-h", HOST, "-p", str(port),
                "-c", "unix_socket_directories=", wait=port)
    eventually(lambda: "database system is ready to accept connections" in lab.logs["postgres"].read_text())
    return f"postgresql://postgres:{quote(password)}@{HOST}:{port}/postgres"


@asynccontextmanager
async def serve(app, port):
    server = uvicorn.Server(uvicorn.Config(app, host=HOST, port=port, log_level="error", timeout_graceful_shutdown=2))
    task = asyncio.create_task(server.serve())
    try:
        async with asyncio.timeout(6):
            while not server.started:
                await asyncio.sleep(0.02)
        yield
    finally:
        server.should_exit = True
        await asyncio.wait_for(task, timeout=8)


class Origin:
    def __init__(self, label, dataset, signing, contract, db):
        self.label, self.dataset, self.signing, self.contract, self.db = label, dataset, signing, contract, db
        self.busy = 0
        self.calls = []
        self.release = asyncio.Event()
        self.release.set()
        self.writes = 0

    async def probe(self, req):
        nonce = req.headers["X-Source-Nonce"]
        sig = self.signing.sign(f"{nonce}\ndocs\n{self.dataset}\n{self.contract}".encode())
        return JSONResponse({"dataset": self.dataset}, headers={"X-Source-Signature": base64.b64encode(sig).decode()})

    async def operation(self, req):
        assert "X-Source-Broker-Key" not in req.headers
        assert "Authorization" not in req.headers
        self.calls.append(req.query_params["topic"])
        self.busy += 1
        try:
            async with asyncio.timeout(8):
                await self.release.wait()
            result = await self.db.execute("SELECT contents FROM lab_documents WHERE dataset=%s", (self.dataset,))
            return JSONResponse({"member": self.label, "dataset": self.dataset, "value": (await result.fetchone())[0]})
        finally:
            self.busy -= 1

    def app(self):
        return Starlette(routes=[Route("/proof", self.probe), Route("/source", self.operation),
                                  Route("/write", self.write, methods=["POST"])])

    async def write(self, req):
        self.writes += 1
        await req.body()
        return JSONResponse({"member": self.label}, status_code=503)


async def main():
    assert importlib.metadata.version("litellm") == "1.108.5"
    with Lab() as lab:
        dsn = start_postgres(lab)
        proxy_port, a_port, b_port, c_port, ingress = [free_port() for _ in range(5)]
        spec = catalog()
        spec_file = lab.directory / "openapi.json"
        spec_raw = json.dumps(spec, sort_keys=True, separators=(",", ":"))
        spec_file.write_text(spec_raw)
        contract = hashlib.sha256(spec_raw.encode()).hexdigest()
        signing = Ed25519PrivateKey.generate()
        public = base64.b64encode(signing.public_key().public_bytes_raw()).decode()
        dataset = str(uuid.uuid4())
        unrelated = str(uuid.uuid4())
        admin = "fixture-admin-" + secrets.token_urlsafe(32)
        proxy_config = lab.directory / "litellm.yaml"
        private(proxy_config, {
            "model_list": [{"model_name": "fixture", "litellm_params": {"model": "openai/fixture",
                            "api_key": "fixture-unused", "api_base": f"http://{HOST}:1/v1"}}],
            "general_settings": {"master_key": admin, "proxy_batch_write_at": 1},
            "guardrails": [{"guardrail_name": "fixture-policy", "litellm_params": {
                "guardrail": "litellm_content_filter", "mode": "pre_mcp_call", "default_on": True,
                "blocked_words": [{"keyword": BLOCK, "action": "BLOCK"}],
            }}],
        })
        env = {"DATABASE_URL": dsn, "CONFIG_FILE_PATH": str(proxy_config), "LITELLM_MASTER_KEY": admin,
               "LITELLM_LOCAL_MODEL_COST_MAP": "True", "LITELLM_TELEMETRY": "False",
               "LITELLM_DONT_SHOW_FEEDBACK_BOX": "true", "PYTHONUNBUFFERED": "1",
               "CHECKPOINT_DISABLE": "1", "PRISMA_DISABLE_TELEMETRY": "1", "DO_NOT_TRACK": "1",
               "PRISMA_HIDE_UPDATE_MESSAGE": "true", "NPM_CONFIG_UPDATE_NOTIFIER": "false",
               "NPM_CONFIG_OFFLINE": "true"}
        migration = subprocess.run([sys.executable, "-m", "prisma", "db", "push", "--skip-generate",
                                    "--schema", SCHEMA], env={**os.environ, **env}, capture_output=True, timeout=60)
        if migration.returncode:
            raise RuntimeError("Prisma migration failed; see README prerequisites: " +
                               migration.stderr.decode(errors="replace").replace(dsn, "[fixture-dsn]")[-2000:])
        p = lab.process("litellm", sys.executable, "-m", "uvicorn", "litellm.proxy.proxy_server:app",
                        "--host", HOST, "--port", str(proxy_port), "--log-level", "warning", env=env)
        def ready():
            if p.poll() is not None:
                detail = lab.logs["litellm"].read_text().replace(dsn, "[fixture-dsn]").replace(admin, "[fixture-admin]")
                raise RuntimeError(detail[-4000:])
            return request(proxy_port, "/health/liveliness")[0] == 200
        eventually(ready, timeout=40)
        g = Gateway(lab, {"docs": {"http_host": "source.fixture", "probe_path": "/proof", "dataset_id": dataset,
                                  "contract_sha256": contract, "proof_public_key": public, "read_paths": ["/source"],
                                  "leader": "worker-a", "leader_routes": {"/write": "POST"}}},
                    {f"worker-{label}": {"targets": {"docs": f"{HOST}:{port}"}}
                     for label, port in zip("abc", (a_port, b_port, c_port), strict=True)})
        g.start()
        cert, key = lab.certificates()
        lab.caddy({"/mcp-worker": g.ingress, "/connectors/*": g.ingress}, ingress, cert, key)
        async with await psycopg.AsyncConnection.connect(dsn, autocommit=True) as db:
            await db.execute("CREATE TABLE lab_documents (dataset uuid PRIMARY KEY, contents text NOT NULL)")
            await db.execute("INSERT INTO lab_documents VALUES (%s, 'same-origin'), (%s, 'different-origin')",
                             (dataset, unrelated))
            a, b, c = [Origin(label, dataset if label != "c" else unrelated, signing, contract, db) for label in "abc"]
            async with serve(a.app(), a_port), serve(b.app(), b_port), serve(c.app(), c_port):
                workers = {}
                for origin in (a, b, c):
                    member = f"worker-{origin.label}"
                    workers[origin.label] = connector(lab, g.enrollment(member, ingress, cert), member)
                await asyncio.to_thread(g.wait_ready, "worker-a", "docs")
                await asyncio.to_thread(g.wait_ready, "worker-b", "docs")
                assert await asyncio.to_thread(eventually, lambda: g.status()["worker-c"].get("ready", {}).get("docs") is False)
                write = await asyncio.to_thread(g.data_request, "/sources/docs/write", "POST", {"value": 1})
                assert write[0] == 503 and json.loads(write[1])["member"] == "a"
                assert (a.writes, b.writes, c.writes) == (1, 0, 0)
                print("PASS a leader-only POST returned its upstream 503 without retrying any other member", flush=True)
                stateful = await asyncio.to_thread(request, g.data, "/sources/docs/source?topic=stateful",
                                                   headers={"X-Source-Broker-Key": g.data_key, "Mcp-Session-Id": "fixture"})
                assert stateful[0] == 400 and not any(origin.calls for origin in (a, b, c))
                print("PASS a request carrying MCP session state was rejected on a pooled read route", flush=True)
                base = f"http://{HOST}:{proxy_port}"
                async with httpx.AsyncClient(base_url=base, trust_env=False, timeout=18) as http:
                    admin_file = lab.directory / "litellm.secret"
                    private(admin_file, admin)
                    register = [sys.executable, ROOT / "register_mcp.py", "--proxy", base, "--admin-key-file", admin_file,
                                "--broker-key-file", lab.directory / "data.secret", "--alias", ALIAS,
                                "--source-url", f"http://{HOST}:{g.data}/sources/docs", "--spec", spec_file,
                                "--tool", "read_source", "--access-group", "source-link-fixture"]
                    async def register_source():
                        process = await asyncio.create_subprocess_exec(*register, stdout=asyncio.subprocess.PIPE,
                                                                       stderr=asyncio.subprocess.PIPE)
                        stdout, stderr = await process.communicate()
                        assert process.returncode == 0, stderr.decode()
                        return json.loads(stdout)["server_id"]
                    server_id = await register_source()
                    assert await register_source() == server_id

                    async def make_key(permissions):
                        result = await http.post("/key/generate", headers=auth(admin), json={
                            "models": ["fixture"], "object_permission": {"mcp_servers": permissions},
                        })
                        assert result.is_success, result.text
                        return result.json()["key"]

                    allowed, denied = await make_key([server_id]), await make_key([])

                    async def tool(key, topic):
                        return await http.post("/mcp-rest/tools/call", headers=auth(key), json={
                            "server_id": server_id, "name": "read_source", "arguments": {"topic": topic},
                        })

                    listed = await http.get("/mcp-rest/tools/list", headers=auth(allowed), params={"server_id": server_id})
                    assert listed.is_success and [t["name"] for t in listed.json()["tools"]] == ["read_source"], listed.text
                    refusal = await tool(denied, "deny")
                    blocked = await tool(allowed, BLOCK)
                    delete = await http.delete(f"/v1/mcp/server/{server_id}", headers=auth(allowed))
                    assert (refusal.status_code, blocked.status_code) == (403, 400), (refusal.text, blocked.text)
                    assert delete.status_code in (401, 403) and not any(origin.calls for origin in (a, b, c))
                    print("PASS LiteLLM v1.108.5 DB-backed MCP virtual key, management boundary, and guardrail denied before origin I/O", flush=True)
                    for origin in (a, b):
                        origin.release.clear()
                    tasks = [asyncio.create_task(tool(allowed, f"document-{i}")) for i in range(12)]
                    try:
                        async with asyncio.timeout(10):
                            while a.busy + b.busy + c.busy < 12:
                                await asyncio.sleep(0.02)
                        assert (a.busy, b.busy, c.busy) == (6, 6, 0)
                    finally:
                        for origin in (a, b):
                            origin.release.set()
                    replies = await asyncio.gather(*tasks)
                    count = Counter()
                    for reply in replies:
                        assert reply.is_success and not reply.json().get("isError"), reply.text
                        data = json.loads(reply.json()["content"][0]["text"])
                        assert data["dataset"] == dataset and data["value"] == "same-origin"
                        count[data["member"]] += 1
                    assert count == {"a": 6, "b": 6} and not c.calls
                    print("PASS idempotent MCP registration, 12 concurrent tool calls across real tunnels, 6 A / 6 B / 0 C, even with same catalog and signing key", flush=True)

                    await db.execute("UPDATE lab_documents SET contents='origin-updated' WHERE dataset=%s", (dataset,))
                    await asyncio.to_thread(stop, workers["b"])
                    await asyncio.to_thread(eventually, lambda: not g.status()["worker-b"].get("ready", {}).get("docs"))
                    reply = await tool(allowed, "failover")
                    result = json.loads(reply.json()["content"][0]["text"])
                    assert result == {"member": "a", "dataset": dataset, "value": "origin-updated"}
                    print("PASS A served fresh shared PostgreSQL data when B disconnected via the same registration", flush=True)

                    rows = await db.execute('SELECT count(*) FROM "LiteLLM_MCPServerTable" WHERE server_id=%s', (server_id,))
                    assert (await rows.fetchone()) == (1,)
                    query = '''SELECT status,count(*) FROM "LiteLLM_SpendLogs"
                               WHERE api_key=%s AND call_type='call_mcp_tool' GROUP BY status'''
                    async with asyncio.timeout(25):
                        while True:
                            rows = await db.execute(query, (hashlib.sha256(allowed.encode()).hexdigest(),))
                            states = dict(await rows.fetchall())
                            if states.get("success", 0) >= 13 and states.get("failure", 0) >= 1:
                                break
                            await asyncio.sleep(0.25)
                    assert p.poll() is None
                    print("PASS PostgreSQL stored LiteLLM MCP success and guardrail failure logs for the permitted virtual key", flush=True)


if __name__ == "__main__":
    asyncio.run(main())
