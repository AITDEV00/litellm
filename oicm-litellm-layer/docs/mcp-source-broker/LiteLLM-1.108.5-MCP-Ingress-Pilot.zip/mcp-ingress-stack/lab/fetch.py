#!/usr/bin/env python3
"""Fetch and verify the optional upstream Linux amd64 lab executables."""
import argparse
import hashlib
import os
import platform
import shutil
import subprocess
import tempfile
from pathlib import Path

from common import BIN

RELEASES = {
    "caddy": ("https://github.com/caddyserver/caddy/releases/download/v2.11.9/caddy_2.11.9_linux_amd64.tar.gz",
              "5b8cb7faf8726a2028ad96a66e54e6e81e8f361bc6175e5d22bbd997cc5177fb", ("caddy",)),
    "nginx": ("https://deb.debian.org/debian/pool/main/n/nginx/nginx_1.26.3-3+deb13u10_amd64.deb",
              "222f1f296cb91a67323fdca0e37c4f34a7be78d14de043f15b2f76acdd8750a9", ("usr/sbin/nginx",)),
    "chisel": ("https://github.com/jpillora/chisel/releases/download/v1.12.0/chisel_1.12.0_linux_amd64.gz",
               "f3f180f1d93aa72cce4e6386f98cc06569a0146fbd65eb4423cf83e6434bcfe6", ("chisel",)),
    "frp": ("https://github.com/fatedier/frp/releases/download/v0.72.0/frp_0.72.0_linux_amd64.tar.gz",
            "daf719b32ca2778770bb92955e231a07414d754378b9af328aa2642862479804", ("frpc", "frps")),
    "gost": ("https://github.com/go-gost/gost/releases/download/v3.3.3/gost_3.3.3_linux_amd64.tar.gz",
             "f4c1255dc892a7014c0ad6e5f1c3573108f7bea4403f04f21873406ab58aa666", ("gost",)),
    "ziti": ("https://github.com/openziti/ziti/releases/download/v2.0.8/ziti-linux-amd64-2.0.8.tar.gz",
             "cf016a9fa19124f1932c1d73435e68e398bae15d6d5c3fef9688a22df61f7aba", ("ziti",)),
    "wstunnel": ("https://github.com/erebe/wstunnel/releases/download/v11.1.0/wstunnel_11.1.0_linux_amd64.tar.gz",
                 "512edf4e7bb64fc133522220123514868fae75b5bae4124b53e396787276aa23", ("wstunnel",)),
    "rathole": ("https://github.com/rathole-org/rathole/releases/download/v0.5.0/rathole-x86_64-unknown-linux-gnu.zip",
                "3e7d0d0f365120cd3cd351d147d1a12ee960c8068b464d4dd533a3821873b80e", ("rathole",)),
}


def materialize(archive, expected, paths):
    import gzip
    import tarfile
    import zipfile

    with archive.open("rb") as original:
        if hashlib.file_digest(original, "sha256").hexdigest() != expected:
            raise RuntimeError(f"checksum mismatch for {archive.name}")
    for path in paths:
        out = BIN / Path(path).name
        with tempfile.NamedTemporaryFile(dir=BIN, prefix=".binary-", delete=False) as dest:
            dest_path = Path(dest.name)
            try:
                if archive.name.endswith(".deb"):
                    with tempfile.TemporaryDirectory() as extracted:
                        subprocess.run(["dpkg-deb", "-x", archive, extracted], check=True)
                        with (Path(extracted) / path).open("rb") as src:
                            shutil.copyfileobj(src, dest)
                elif archive.name.endswith(".tar.gz"):
                    with tarfile.open(archive) as bundle:
                        candidates = [m for m in bundle if m.isfile() and Path(m.name).name == path]
                        assert len(candidates) == 1, path
                        with bundle.extractfile(candidates[0]) as src:
                            shutil.copyfileobj(src, dest)
                elif archive.name.endswith(".zip"):
                    with zipfile.ZipFile(archive) as bundle, bundle.open(path) as src:
                        shutil.copyfileobj(src, dest)
                else:
                    with gzip.open(archive, "rb") as src:
                        shutil.copyfileobj(src, dest)
                dest.flush()
                dest_path.chmod(0o755)
                os.replace(dest_path, out)
            finally:
                dest_path.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("group", nargs="?", choices=["smoke", "all"], default="smoke")
    parser.add_argument("--archives", type=Path, help="directory containing predownloaded original archives")
    args = parser.parse_args()
    assert platform.system() == "Linux" and platform.machine() == "x86_64"
    BIN.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="mcp-lab-upstream-") as temporary:
        for name in (RELEASES if args.group == "all" else ("caddy", "nginx")):
            url, expected, paths = RELEASES[name]
            archive_name = url.rsplit("/", 1)[-1]
            if args.archives:
                archive = args.archives / archive_name
            else:
                archive = Path(temporary) / archive_name
                subprocess.run(["curl", "-fLsS", "--proto", "=https", "--proto-redir", "=https",
                                "--retry", "2", "--max-time", "90", url, "-o", archive], check=True)
            materialize(archive, expected, paths)
            print(f"Verified and installed upstream {name}")


if __name__ == "__main__":
    main()
