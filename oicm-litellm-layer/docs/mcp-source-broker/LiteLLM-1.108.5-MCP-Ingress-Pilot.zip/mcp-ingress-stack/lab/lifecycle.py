import concurrent.futures
import hashlib
import http.client
import json
import stat
import subprocess

from common import Gateway, HOST, Lab, SOURCE_LINK, connector, eventually, free_port, nginx, private, request, stop


def source_http(lab, name):
    directory = lab.directory / name
    directory.mkdir()
    (directory / "hello").write_text('{"source":"nginx"}')
    port = free_port()
    nginx(lab, port, directory, name)
    return port


def main():
    with Lab() as lab:
        port, ingress = source_http(lab, "nginx"), free_port()
        tcp = free_port()
        g = Gateway(lab, {
            "hello": {"http_host": "fixture", "probe_path": "/hello", "read_paths": ["/hello"]},
            "native": {"tcp_listen": f"{HOST}:{tcp}", "leader": "worker-a"},
        }, {"worker-a": {"targets": {"hello": f"{HOST}:{port}", "native": f"{HOST}:{port}"}}})
        gateway = g.start()
        cert, key = lab.certificates()
        lab.caddy({"/mcp-worker": g.ingress, "/connectors/*": g.ingress}, ingress, cert, key)
        assert request(ingress, "/sources/hello/hello", ca=cert)[0] == 404
        assert request(ingress, "/members", ca=cert)[0] == 404
        assert request(ingress, "/mcp-worker", ca=cert)[0] == 426
        assert request(g.admin, "/members")[0] == 401
        assert request(g.data, "/sources/hello/hello")[0] == 401
        artifact_status, artifact = request(ingress, "/connectors/linux-amd64/source-link", ca=cert)
        assert artifact_status == 200 and hashlib.sha256(artifact).digest() == hashlib.sha256(SOURCE_LINK.read_bytes()).digest()
        print("PASS private data/admin routes and TLS artifact download", flush=True)
        ticket = g.mutate("worker-a", "invite", 0)["ticket"]
        untrusted = subprocess.run([SOURCE_LINK, "enroll", "-gateway", f"https://{HOST}:{ingress}",
                                   "-ticket-file", "-", "-config", lab.directory / "untrusted.json"],
                                  input=(ticket + "\n").encode(), capture_output=True, timeout=8)
        assert untrusted.returncode != 0 and b"certificate signed by unknown authority" in untrusted.stderr
        with concurrent.futures.ThreadPoolExecutor(2) as executor:
            responses = list(executor.map(lambda _: request(ingress, "/connectors/enroll", "POST",
                                                           {"ticket": ticket}, ca=cert), range(2)))
        assert sorted(status for status, _ in responses) == [200, 401], responses
        cfg_path = lab.directory / "worker-a.json"
        cfg = json.loads(next(body for status, body in responses if status == 200))
        private(cfg_path, {**cfg, "gateway": f"https://{HOST}:{ingress}", "ca_file": str(cert)})
        assert stat.S_IMODE(cfg_path.stat().st_mode) == 0o600
        print("PASS untrusted TLS rejected and concurrent ticket redemption issued exactly one credential", flush=True)

        a = connector(lab, cfg_path, "worker-a")
        try:
            g.wait_ready("worker-a", "hello")
        except Exception:
            for name in ("worker-a", "gateway", "caddy"):
                print(name, lab.logs[name].read_text()[-2200:])
            raise
        assert g.data_request("/sources/hello/hello") == (200, b'{"source":"nginx"}')
        assert request(tcp, "/hello") == (200, b'{"source":"nginx"}')
        assert g.data_request("/sources/hello/unknown")[0] == 404
        assert request(g.data, "/sources/hello/hello", headers={"X-Source-Broker-Key": g.data_key,
                                                              "Upgrade": "websocket"})[0] == 400
        print("PASS stock Nginx served through HTTPS tunnel as HTTP and as opaque TCP", flush=True)

        conn = http.client.HTTPConnection(HOST, tcp, timeout=3)
        conn.request("GET", "/hello")
        assert conn.getresponse().read() == b'{"source":"nginx"}'
        assert conn.sock is not None
        active_tcp = conn.sock
        g.mutate("worker-a", "drain", 1)
        assert g.data_request("/sources/hello/hello")[0] == 503
        conn.request("GET", "/hello")
        assert conn.getresponse().read() == b'{"source":"nginx"}'
        g.mutate("worker-a", "revoke", 1)
        active_tcp.settimeout(3)
        try:
            assert active_tcp.recv(1) == b""
        except ConnectionResetError:
            pass
        conn.close()
        assert g.data_request("/sources/hello/hello")[0] == 503
        g.mutate("worker-a", "invite", 1, expected=409)
        stop(a)
        stop(gateway)
        gateway = g.start("restarted-gateway")
        stale = connector(lab, cfg_path, "stale")
        eventually(lambda: "HTTP 401" in lab.logs["stale"].read_text() or "401 Unauthorized" in lab.logs["stale"].read_text())
        assert g.status()["worker-a"]["phase"] == "revoked"
        print("PASS drain preserved active TCP, revoke killed it, stale generation and old config were denied across gateway restart", flush=True)

        recovered = g.enrollment("worker-a", ingress, cert, generation=2)
        recovery = connector(lab, recovered, "first-recovery")
        g.wait_ready("worker-a", "hello")
        stop(gateway)
        gateway = g.start("reconnect-gateway")
        g.wait_ready("worker-a", "hello")
        assert recovery.poll() is None
        stop(recovery)
        eventually(lambda: not g.status()["worker-a"].get("ready", {}).get("hello"))
        retry = connector(lab, recovered, "restarted-worker")
        g.wait_ready("worker-a", "hello")
        assert g.data_request("/sources/hello/hello")[0] == 200
        same = g.enrollment("worker-a", ingress, cert, "recover", 3)
        stop(retry)
        connector(lab, same, "wiped-and-reenrolled")
        g.wait_ready("worker-a", "hello")
        assert g.status()["worker-a"]["generation"] == 4
        assert g.data_request("/sources/hello/hello")[0] == 200
        print("PASS connector reattached after gateway restart, connector restart reused config, wipe recovered the same member with a new generation", flush=True)

        stop(gateway)
        manifest = json.loads(g.config.read_text())
        manifest["members"]["worker-a"]["targets"]["hello"] = f"{HOST}:{free_port()}"
        private(g.config, manifest)
        g.start("changed-binding-gateway")
        attempt = connector(lab, same, "stale-binding")
        eventually(lambda: "401 Unauthorized" in lab.logs["stale-binding"].read_text())
        assert attempt.poll() is None
        assert g.data_request("/sources/hello/hello")[0] == 503
        print("PASS changing an approved target invalidated the prior manifest-bound connector credential", flush=True)


if __name__ == "__main__":
    main()
