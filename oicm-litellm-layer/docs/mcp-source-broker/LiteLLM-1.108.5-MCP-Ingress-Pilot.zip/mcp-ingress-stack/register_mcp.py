#!/usr/bin/env python3
"""Apply one reviewed OpenAPI registration through the LiteLLM administrator API."""
import argparse
import ipaddress
import json
import re
import urllib.error
import urllib.request
import uuid
from pathlib import Path
from urllib.parse import urlparse


class DenyRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def read_secret(path):
    stat = path.stat()
    if not path.is_file() or stat.st_mode & 0o077:
        raise SystemExit(f"{path.name} must be owner-only")
    value = path.read_text().strip()
    if len(value) < 32 or any(c in value for c in "\r\n"):
        raise SystemExit(f"Invalid {path.name}")
    return value


def api(proxy, key, method, data=None):
    req = urllib.request.Request(
        f"{proxy.rstrip('/')}/v1/mcp/server",
        headers={"Authorization": "Bearer " + key, "Content-Type": "application/json"},
        data=None if data is None else json.dumps(data).encode(), method=method,
    )
    try:
        opener = urllib.request.build_opener(DenyRedirects())
        with opener.open(req, timeout=15) as result:
            return json.load(result)
    except urllib.error.HTTPError as e:
        raise SystemExit(f"LiteLLM {method} returned {e.status}") from None


def apply(proxy, admin, broker_key, alias, source_url, spec, tool_names, group):
    parsed = urlparse(source_url)
    try:
        local = ipaddress.ip_address(parsed.hostname).is_loopback
    except ValueError:
        local = False
    if parsed.scheme != "http" or not local or parsed.username is not None or parsed.query or parsed.fragment:
        raise SystemExit("Use the private loopback HTTP data listener")
    if parsed.port is None or not re.fullmatch(r"/sources/[a-z][a-z0-9-]{0,47}", parsed.path):
        raise SystemExit("Use the private logical source URL")
    proxy_url = urlparse(proxy)
    if proxy_url.username is not None or proxy_url.query or proxy_url.fragment or not proxy_url.hostname or (
        proxy_url.scheme != "https" and not (proxy_url.scheme == "http" and proxy_url.hostname in {"127.0.0.1", "::1"})
    ):
        raise SystemExit("Use the approved HTTPS LiteLLM URL or its local loopback address")
    spec = spec.resolve(strict=True)
    if not spec.is_file():
        raise SystemExit("The approved spec must be an on-disk file readable by LiteLLM")
    content = json.loads(spec.read_bytes())
    if content.get("servers"):
        raise SystemExit("Remove OpenAPI servers entries and use the approved broker URL")
    if not tool_names or len(set(tool_names)) != len(tool_names):
        raise SystemExit("Specify unique approved tools")
    # A deterministic ID makes retries and lost responses safe without claiming an existing alias.
    server_id = str(uuid.uuid5(uuid.NAMESPACE_URL, "source-link:" + alias))
    body = {
        "server_id": server_id, "server_name": alias, "alias": alias, "transport": "http",
        "url": source_url, "spec_path": str(spec), "allowed_tools": list(tool_names),
        "allow_all_keys": False, "available_on_public_internet": False, "mcp_access_groups": [group],
        "static_headers": {"X-Source-Broker-Key": broker_key},
    }
    existing = api(proxy, admin, "GET")
    matches = [row for row in existing if row.get("alias") == alias or row.get("server_name") == alias or row.get("server_id") == server_id]
    if any(row.get("server_id") != server_id or row.get("url") != source_url for row in matches):
        raise SystemExit("The alias or ID is already managed elsewhere")
    result = api(proxy, admin, "PUT" if matches else "POST", body)
    if result.get("server_id") != server_id:
        raise SystemExit("Unexpected registration ID")
    return server_id


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for option in ("proxy", "admin-key-file", "broker-key-file", "alias", "source-url", "spec", "access-group"):
        parser.add_argument("--" + option, required=True)
    parser.add_argument("--tool", action="append", required=True)
    args = parser.parse_args()
    server_id = apply(args.proxy, read_secret(Path(args.admin_key_file)), read_secret(Path(args.broker_key_file)),
                      args.alias, args.source_url, Path(args.spec), args.tool, args.access_group)
    print(json.dumps({"server_id": server_id, "alias": args.alias}))


if __name__ == "__main__":
    main()
