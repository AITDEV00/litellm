package main

import (
	"context"
	"crypto/ed25519"
	"encoding/base64"
	"errors"
	"io"
	"log"
	"net"
	"net/http"
	"net/http/httputil"
	"net/url"
	"regexp"
	"strings"
	"sync"
	"time"
)

type sourceConfig struct {
	Host          string            `json:"http_host,omitempty"`
	Probe         string            `json:"probe_path,omitempty"`
	ProofKey      string            `json:"proof_public_key,omitempty"`
	Dataset       string            `json:"dataset_id,omitempty"`
	Contract      string            `json:"contract_sha256,omitempty"`
	Leader        string            `json:"leader,omitempty"`
	TCPListen     string            `json:"tcp_listen,omitempty"`
	MaxConcurrent int               `json:"max_per_member,omitempty"`
	Reads         []string          `json:"read_paths,omitempty"`
	LeaderRoutes  map[string]string `json:"leader_routes,omitempty"`
}

var fingerprint = regexp.MustCompile(`^[a-f0-9]{64}$`)

func cleanPath(p string) bool {
	return strings.HasPrefix(p, "/") && !strings.ContainsAny(p, "?#%\\ \r\n\t") &&
		!strings.Contains(p, "//") && !strings.Contains(p+"/", "/../") && !strings.Contains(p+"/", "/./")
}

func (s sourceConfig) validate(members map[string]memberConfig, source string) error {
	if !identifier.MatchString(source) || s.MaxConcurrent < 0 || s.MaxConcurrent > 1024 {
		return errors.New("invalid source ID or concurrency limit")
	}
	n := 0
	for _, member := range members {
		if member.Targets[source] != "" {
			n++
		}
	}
	if n == 0 {
		return errors.New("source needs an assigned member")
	}
	if s.Leader != "" && members[s.Leader].Targets[source] == "" {
		return errors.New("leader must belong to this source")
	}
	if s.ProofKey != "" {
		key, err := base64.StdEncoding.DecodeString(s.ProofKey)
		if err != nil || len(key) != ed25519.PublicKeySize || s.Dataset == "" ||
			strings.ContainsAny(s.Dataset, "\r\n") || !fingerprint.MatchString(s.Contract) || !cleanPath(s.Probe) {
			return errors.New("invalid dataset proof configuration")
		}
	}
	if s.TCPListen != "" {
		if !loopback(s.TCPListen) || s.Leader == "" || n != 1 || s.Probe != "" || len(s.Reads)+len(s.LeaderRoutes) > 0 {
			return errors.New("opaque TCP requires an explicit single member on loopback")
		}
		return nil
	}
	if (n > 1 && s.ProofKey == "") || !cleanPath(s.Probe) {
		return errors.New("HTTP requires a health path and multi-member HTTP requires signed dataset proof")
	}
	if s.Host == "" || strings.ContainsAny(s.Host, "/@?#\\ \r\n\t") {
		return errors.New("invalid configured upstream HTTP Host")
	}
	if len(s.LeaderRoutes) > 0 && s.Leader == "" {
		return errors.New("leader routes require an explicit member")
	}
	for _, path := range s.Reads {
		if !cleanPath(path) {
			return errors.New("invalid read path")
		}
	}
	for path, method := range s.LeaderRoutes {
		if !cleanPath(path) || (method != "GET" && method != "POST" && method != "PUT" && method != "PATCH" && method != "DELETE") {
			return errors.New("invalid leader route")
		}
	}
	return nil
}

type sourceKey struct{}

func (s sourceConfig) probe(ctx context.Context, id string, transport *http.Transport) bool {
	ctx, cancel := context.WithTimeout(ctx, 2*time.Second)
	defer cancel()
	ctx = context.WithValue(ctx, sourceKey{}, id)
	u := &url.URL{Scheme: "http", Host: slot(id), Path: s.Probe}
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, u.String(), nil)
	if err != nil {
		return false
	}
	req.Host = s.Host
	var nonce string
	if s.ProofKey != "" {
		nonce, err = randomToken()
		if err != nil {
			return false
		}
		req.Header.Set("X-Source-Nonce", nonce)
	}
	resp, err := transport.RoundTrip(req)
	if err != nil {
		return false
	}
	defer resp.Body.Close()
	if _, err := io.Copy(io.Discard, io.LimitReader(resp.Body, 65536)); err != nil ||
		resp.StatusCode != http.StatusOK {
		return false
	}
	if s.ProofKey == "" {
		return true
	}
	key, _ := base64.StdEncoding.DecodeString(s.ProofKey)
	signature, err := base64.StdEncoding.DecodeString(resp.Header.Get("X-Source-Signature"))
	return err == nil && ed25519.Verify(key, []byte(nonce+"\n"+id+"\n"+s.Dataset+"\n"+s.Contract), signature)
}

func (g *gateway) checkWorker(ctx context.Context, id string, session *workerSession) {
	// The probe loop first waits for the WebSocket library to register this session.
	boot := time.NewTicker(25 * time.Millisecond)
	defer boot.Stop()
	for !g.relay.HasSession(session.key) {
		select {
		case <-ctx.Done():
			return
		case <-boot.C:
		}
	}
	ticker := time.NewTicker(2 * time.Second)
	defer ticker.Stop()
	for {
		var pending sync.WaitGroup
		for source := range g.cfg.Members[id].Targets {
			cfg := g.cfg.Sources[source]
			pending.Go(func() {
				ready := cfg.TCPListen != "" || cfg.probe(ctx, source, session.transport)
				g.mu.Lock()
				if ctx.Err() == nil && g.sessions[id] == session && g.state[id].Phase == "active" {
					session.ready[source] = ready
				}
				g.mu.Unlock()
			})
		}
		pending.Wait()
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
		}
	}
}

func (g *gateway) pick(source, leader, exclude string) (string, *workerSession) {
	g.mu.Lock()
	defer g.mu.Unlock()
	cfg := g.cfg.Sources[source]
	limit := cfg.MaxConcurrent
	if limit == 0 {
		limit = 64
	}
	var id string
	var chosen *workerSession
	for _, candidate := range g.memberIDs {
		session := g.sessions[candidate]
		if session == nil || !session.ready[source] || g.state[candidate].Phase != "active" ||
			candidate == exclude || (leader != "" && candidate != leader) || session.inFlight[source] >= limit {
			continue
		}
		if chosen == nil || session.inFlight[source] < chosen.inFlight[source] ||
			(session.inFlight[source] == chosen.inFlight[source] && session.last[source] < chosen.last[source]) {
			id, chosen = candidate, session
		}
	}
	if chosen != nil {
		g.serial++
		chosen.last[source] = g.serial
		chosen.inFlight[source]++
	}
	return id, chosen
}

func (g *gateway) release(source string, session *workerSession) {
	g.mu.Lock()
	defer g.mu.Unlock()
	session.inFlight[source]--
}

func (g *gateway) proxy(w http.ResponseWriter, r *http.Request) {
	source, path := r.PathValue("source"), "/"+r.PathValue("path")
	cfg, ok := g.cfg.Sources[source]
	if !ok || cfg.TCPListen != "" || !cleanPath(path) {
		http.NotFound(w, r)
		return
	}
	if r.Header.Get("Upgrade") != "" || r.Method == http.MethodConnect {
		http.Error(w, "unsupported source HTTP operation", http.StatusBadRequest)
		return
	}

	var leader string
	allowRead := (r.Method == "GET" || r.Method == "HEAD") && r.ContentLength == 0
	if cfg.LeaderRoutes[path] == r.Method {
		leader = cfg.Leader
	} else if !allowRead || !contains(cfg.Reads, path) {
		http.NotFound(w, r)
		return
	}
	if cfg.ProofKey != "" && leader == "" && (r.Header.Get("Mcp-Session-Id") != "" ||
		strings.Contains(strings.ToLower(r.Header.Get("Accept")), "text/event-stream")) {
		http.Error(w, "stateful and streaming routes require an explicit leader", http.StatusBadRequest)
		return
	}
	id, session := g.pick(source, leader, "")
	if session == nil {
		w.Header().Set("Retry-After", "1")
		http.Error(w, "no eligible connector", http.StatusServiceUnavailable)
		return
	}
	defer g.release(source, session)
	proxy := httputil.ReverseProxy{
		Rewrite: func(req *httputil.ProxyRequest) {
			req.SetURL(&url.URL{Scheme: "http", Host: slot(source)})
			req.Out.URL.Path, req.Out.URL.RawPath, req.Out.Host = path, "", cfg.Host
			// Build an explicit application header allowlist after stripping gateway headers.
			req.Out.Header = make(http.Header)
			for _, key := range []string{"Accept", "Content-Type", "Mcp-Session-Id", "Mcp-Protocol-Version", "Last-Event-Id"} {
				for _, value := range req.In.Header.Values(key) {
					req.Out.Header.Add(key, value)
				}
			}
			if leader != "" {
				req.Out.Close = true
			}
			req.Out = req.Out.WithContext(context.WithValue(req.Out.Context(), sourceKey{}, source))
		},
		ModifyResponse: func(resp *http.Response) error {
			resp.Header.Del("Set-Cookie")
			return nil
		},
		Transport: roundTripFunc(func(req *http.Request) (*http.Response, error) {
			if leader != "" {
				// Disabling connection reuse prevents implicit transport replay for writes.
				return session.ordered.RoundTrip(req)
			}
			resp, err := session.transport.RoundTrip(req)
			if err == nil || req.Context().Err() != nil {
				return resp, err
			}
			_, other := g.pick(source, "", id)
			if other == nil {
				return nil, err
			}
			resp, err = other.transport.RoundTrip(req)
			if err != nil {
				g.release(source, other)
				return nil, err
			}
			resp.Body = &countedBody{ReadCloser: resp.Body, done: func() { g.release(source, other) }}
			return resp, nil
		}),
		ErrorHandler: func(w http.ResponseWriter, r *http.Request, err error) {
			log.Printf("source %s via %s: %v", source, id, err)
			http.Error(w, "source upstream unavailable", http.StatusBadGateway)
		},
	}
	proxy.ServeHTTP(w, r)
}

type roundTripFunc func(*http.Request) (*http.Response, error)

func (f roundTripFunc) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }

type countedBody struct {
	io.ReadCloser
	done func()
	once sync.Once
}

func (b *countedBody) Close() error {
	err := b.ReadCloser.Close()
	b.once.Do(b.done)
	return err
}

func contains(values []string, value string) bool {
	for _, current := range values {
		if current == value {
			return true
		}
	}
	return false
}

func (g *gateway) serveTCP(ctx context.Context, source string, listener net.Listener) error {
	for {
		incoming, err := listener.Accept()
		if err != nil {
			return err
		}
		_, session := g.pick(source, g.cfg.Sources[source].Leader, "")
		if session == nil {
			incoming.Close()
			continue
		}
		go func() {
			defer g.release(source, session)
			defer incoming.Close()
			dialCtx, cancel := context.WithTimeout(ctx, 5*time.Second)
			upstream, err := g.relay.Dialer(session.key)(dialCtx, "tcp", slot(source))
			cancel()
			if err != nil {
				return
			}
			defer upstream.Close()
			done := make(chan struct{})
			go func() {
				defer close(done)
				io.Copy(upstream, incoming)
				upstream.Close()
			}()
			io.Copy(incoming, upstream)
			incoming.Close()
			<-done
		}()
	}
}
