# LiteLLM source ingress pilot

**Use the packaged Linux connector and broker built on Rancher remotedialer v0.5.2 with the existing HTTPS ingress and LiteLLM v1.108.5 LTS.** It is the best fit found for a single approved HTTPS hostname and path, private source reachability, one registration per logical source, and revocation of live traffic. The [comparison](RESULTS.md) includes the other candidates, exact tests, and limits. This is a single-broker pilot for an isolated staging alias.

## Network and ownership

```mermaid
flowchart LR
  Caller["MCP caller"] --> Lite["LiteLLM v1.108.5"]
  Lite -->|"private HTTP or native adapter"| Broker["Source broker"]
  Host["Source host connector"] -->|"initiates HTTPS WSS"| Edge["Approved HTTPS ingress"]
  Edge -->|"same established tunnel"| Broker
  Host -->|"approved local TCP target"| Origin["Nginx, API, or database"]
```

The source host opens the connection to the gateway. After upgrade, both ends can send bytes over the established WebSocket. The broker asks for a stream to a preassigned source slot and the connector opens the corresponding local socket. A firewall allowing only source-initiated connections can support this if it allows the upgrade and full-duplex traffic. A data diode or an ingress policy allowing only ordinary inference requests makes this design unavailable until the network owner approves an appropriate path.

The connector has no inbound listener, requires no TUN device, and carries native TCP. It never runs MCP tools. The broker verifies the assigned member, credential generation, and the current approved target manifest. The connector resolves a requested slot only through its local allowlist. The managed source account and origin remain trust boundaries. The LiteLLM admin configures the source's OpenAPI or gateway-hosted adapter once and grants access using existing MCP controls. Nginx serves a static file in this pilot.

## Reproduce locally

Linux amd64, Python 3.12, OpenSSL, curl, util-linux and `make` are enough for the basic smoke tests. Use Go **1.27.4** to rebuild the included amd64 binary. The default lab downloads pinned upstream versions and checks SHA-256 before extracting. The Debian Nginx binary requires its shared libraries. If you supply installed binaries using `MCP_LAB_BIN`, record their versions for comparison.

```bash
(cd bin && sha256sum -c source-link.sha256)
python3 lab/fetch.py smoke
make build
make test
```

`lab/isolation.py` requires Linux user/network namespaces and passes an accepted ingress socket across a local test boundary. The gateway has only its own loopback interface. It checks that direct access to outside Nginx fails and confirms the same HTTP read succeeds through the source-initiated WSS path. Installer verification uses the real download, digest, enrollment and resulting binary, with a stub for systemctl in this environment.

For the LiteLLM integration and alternatives, use a non-root test account with a working Python venv and Node/npm for Prisma. Run the Prisma setup once while permitted to fetch dependencies. The integration uses a disposable local PostgreSQL. A distro PostgreSQL can be selected with `PG_BIN=/path/to/postgresql/bin`. The lab disables Prisma checkpoint telemetry and LiteLLM telemetry.

```bash
./lab/setup_litellm.sh
.venv/bin/python lab/litellm_integration.py
python3 lab/fetch.py all
make compare PYTHON=.venv/bin/python
```

Run `python3 lab/ziti.py --wss` to try the separately recorded stock OpenZiti WSS configuration. It is a comparison probe with a failed data path in this fixture. `python3 lab/benchmark.py` prints JSON lines including per-process RSS and CPU ticks. `python3 lab/fetch.py all --archives /path/to/archives` validates original archives on an offline lab machine.

## Try Server A and stock Nginx

1. On Server A, run the supplied Nginx configuration or an equivalent existing Nginx instance. The default fixture listens only on `127.0.0.1:18080`.

   ```bash
   mkdir -p "$PWD/fixture/www"
   printf '%s\n' '{"hello":"server-a"}' > "$PWD/fixture/www/hello"
   nginx -p "$PWD/fixture/" -c "$PWD/examples/nginx.conf"
   ```

2. On the gateway host or in LiteLLM's pod network namespace, place the binary and checksum in an immutable release directory. Start the broker with `examples/gateway.json` updated for that directory and with a new private state directory. Generate independent admin and data credentials. For example, from the extracted directory:

   ```bash
   umask 077
   install -d -m 700 "$HOME/.config/source-link"
   openssl rand -hex 32 > "$HOME/.config/source-link/admin.secret"
   openssl rand -hex 32 > "$HOME/.config/source-link/data.secret"
   cp examples/gateway.json "$HOME/.config/source-link/gateway.json"
   ```

   Replace the four example paths in `gateway.json` with absolute paths. Start `./bin/source-link gateway -config "$HOME/.config/source-link/gateway.json"`. The optional gateway user-systemd unit expects the binary under `~/.local/bin`. Use the path matchers in `examples/Caddyfile` as a fragment in the approved ingress. Only the connector upgrade, enrollment POST, and two artifact GETs go to the broker's ingress listener. The broker data and admin listeners are private. Optional raw TCP listeners also stay loopback-only and depend on the native protocol's authentication and local process isolation.

3. Issue a ticket from the gateway host. Keep the management secret and ticket out of the argument list. This shell form writes the one-time ticket to a mode-600 file. Give the ticket to the Server A owner through your existing secure handoff.

   ```bash
   umask 077
   printf 'Authorization: Bearer %s\n' "$(cat "$HOME/.config/source-link/admin.secret")" |
     curl -fsS -H @- -H 'Content-Type: application/json' \
       --data '{"generation":0}' http://127.0.0.1:17642/members/worker-a/invite |
     python3 -c 'import json,sys; print(json.load(sys.stdin)["ticket"])' > ./worker-a.ticket
   ```

4. Provide the approved ingress origin and the expected binary hash from `bin/source-link.sha256` using a trusted release channel. On A, run `./install.sh https://gateway.example.com EXPECTED_SHA256`. The script prompts without echo. For noninteractive installation, supply a mode-600 ticket file as the third argument. Supply an optional CA bundle as the fourth argument. Use an empty third argument for the prompt with a private CA. The installer downloads the binary, verifies the pinned digest, redeems the ticket, writes a mode-600 config and enables the connector under user systemd. To start at machine boot before an interactive login, have the host administrator enable linger for that service account. One shell command can carry out setup. An HTTP response alone cannot execute a binary on a source host.

5. Register the Nginx source once from the LiteLLM administration side. `--spec` must point to the reviewed, local JSON spec readable by the running LiteLLM process. The data URL must resolve from LiteLLM's own network namespace. Mount the spec into that namespace when deploying in containers.

   ```bash
   python3 register_mcp.py \
     --proxy http://127.0.0.1:4000 \
     --admin-key-file /absolute/path/litellm-admin.secret \
     --broker-key-file "$HOME/.config/source-link/data.secret" \
     --alias nginx_hello --access-group approved-nginx \
     --source-url http://127.0.0.1:17641/sources/nginx-hello \
     --spec "$PWD/examples/nginx-openapi.json" --tool read_hello
   ```

   The script uses a stable server ID and applies the same registration on retry. Grant the resulting source or access group to the intended LiteLLM team or virtual key. Normal users continue to call LiteLLM's MCP endpoints. Only administrators have the separate enrollment credential and the LiteLLM registration credential.

## Lifecycle and routing

| Action | Behavior in this pilot |
|---|---|
| Restart or short network loss | Enabled connector reconnects with backoff using the local credential. The broker requires a new successful source probe for HTTP. |
| Disk wipe or changed target | Admin requests `POST /members/{id}/recover` with the current generation. The broker issues a one-use ticket for the same member and approved manifest, advances the generation and closes the old session. Run the installer again. The broker stores credential hashes and retains the configuration, so recovery rotates credentials. |
| Drain | `POST /members/{id}/drain` excludes new dispatches and preserves active streams. Read `GET /members` until in-flight work finishes or the agreed deadline expires. |
| Revoke | `POST /members/{id}/revoke` persists a tombstone and generation, closes the active WebSocket, and rejects the old config after restart. Use `invite` with the current generation only for explicit readmission. |
| Retire a whole source | Drain or revoke the relevant memberships, then remove the LiteLLM row through its admin API. This package manages one member connection that can carry several sources. Draining a member affects all its bindings. Keep the service catalog and a per-binding reconciler in the existing broker for independent source retirement. |
| Add another member | Update the reviewed gateway manifest, enroll B with a separate identity, and let the proof earn routing eligibility. One LiteLLM row serves A and B. |

Management POSTs accept a JSON `generation` and the same management header as the invite example. The response from a successful invite or recover contains a ticket that should be handled as a secret. The static gateway manifest takes effect on process restart. The state file is a single-node staging implementation with a lock and atomic updates. Keep the existing PostgreSQL control plane for production and coordinate each live session closure with generation changes there.

For pooled HTTP, configure the expected dataset ID, reviewed contract digest, an origin proof public key and a proof path. The trusted application receives `X-Source-Nonce` and returns `X-Source-Signature`, standard Base64 of the Ed25519 signature over `nonce + "\n" + logical_source_id + "\n" + dataset_id + "\n" + contract_sha256`. Keep the signing key under control of the service that owns the dataset. For authenticated production evidence also verify the serving origin identity, tenant and credential scope, replica lineage or revision, and freshness where needed. A connector with a signing key or a separately spoofable proof endpoint can misrepresent the data plane.

Pool only reviewed, independent reads with equivalent scope and results. The broker uses least in-flight, rotates ties, and can retry a bodyless read once on another healthy member on a transport error before response headers. An HTTP status, even 5xx, is returned as-is. Leader-only routes never retry onto a sibling. Use a fixed member or an adapter that pins each native MCP session and fails closed when that member disappears. This pilot does not implement multi-member session affinity, automatic promotion, or opaque TCP read/write classification. Put native SQL or other protocol routing in a gateway-hosted adapter using its own read-only credential and native TLS as appropriate. Two hosts merely having internet access only proves reachability. Pool by the same upstream, tenant, credential scope, method and semantics, then consider shared quotas, egress IP, and billing before adding another route.

## Files your agent will change

| File | Role |
|---|---|
| `connector.go`, `main.go` | Enrollment, trusted TLS, approved target dialing and process lifecycle. |
| `gateway.go`, `pool.go` | Private listeners, config recovery, target binding, drain/revoke, probes, and request selection. |
| `bin/source-link`, `bin/source-link.sha256` | Exact amd64 binary and digest, with licenses in `third-party-licenses/`. |
| `install.sh`, `systemd/`, `examples/` | Connector installation, service units, Caddy routes, Nginx and source examples. |
| `register_mcp.py` | Existing LiteLLM admin API integration. LiteLLM source changes required for the tested pilot are zero. |
| `lab/`, `evidence/`, `RESULTS.md` | Runnable tests, raw results, dependency pins and comparison. |

For the company version, reuse its approved installer and PostgreSQL model in place of the pilot file store, and keep the existing authorization UI and LiteLLM registration client. The gates that remain are the actual corporate ingress route, a reboot with the real service manager, workload-level WAN and durability tests, and shared state plus relay ownership for multi-replica deployment. Lab measurements and process restarts alone establish the pilot behavior.
