#!/usr/bin/env bash
set -euo pipefail
umask 077

if [[ $# -lt 2 || $# -gt 4 ]]; then
    echo 'Usage: ./install.sh HTTPS_ORIGIN EXPECTED_SHA256 [TICKET_FILE] [CA_BUNDLE]' >&2
    exit 2
fi
gateway=${1%/}
expected=$2
ticket_file=${3:-}
ca_file=${4:-}
if [[ $(uname -s) != Linux || $(uname -m) != x86_64 ]]; then
    echo 'This release contains the Linux amd64 build.' >&2
    exit 2
fi
if [[ ! $gateway =~ ^https://([A-Za-z0-9.-]+|\[[A-Fa-f0-9:]+\])(:[0-9]{1,5})?$ || ! $expected =~ ^[a-f0-9]{64}$ ]]; then
    echo 'Supply an approved HTTPS origin and a separately trusted SHA-256 digest.' >&2
    exit 2
fi
systemctl --user show-environment >/dev/null
here=$(cd -- "$(dirname -- "$0")" && pwd)
config="$HOME/.config/source-link"
units="$HOME/.config/systemd/user"
executables="$HOME/.local/bin"
install -d -m 700 "$config"
mkdir -p "$units" "$executables"
exec 9>"$config/install.lock"
flock -n 9
work=$(mktemp -d "$config/install.XXXXXXXX")
trap 'rm -rf -- "$work"' EXIT
tls=()
enroll_tls=()
if [[ -n $ca_file ]]; then
    install -m 600 "$ca_file" "$work/ingress-ca.pem"
    tls=(--cacert "$work/ingress-ca.pem")
fi
curl -fSs --proto '=https' --tlsv1.2 --max-time 30 "${tls[@]}" \
    "$gateway/connectors/linux-amd64/source-link" -o "$work/source-link"
printf '%s  %s\n' "$expected" "$work/source-link" | sha256sum --check --status
chmod 700 "$work/source-link"
if [[ -n $ca_file ]]; then
    # Different CA files can coexist while a replacement connector enrolls.
    ca_hash=$(sha256sum "$work/ingress-ca.pem" | cut -d' ' -f1)
    ca_copy="$config/ingress-ca-$ca_hash.pem"
    mv -f -- "$work/ingress-ca.pem" "$ca_copy"
    enroll_tls=(-ca "$ca_copy")
fi
if [[ -n $ticket_file ]]; then
    "$work/source-link" enroll -gateway "$gateway" "${enroll_tls[@]}" \
        -ticket-file "$ticket_file" -config "$work/connector.json"
else
    read -rs -p 'One-time connector ticket: ' ticket
    printf '\n' >&2
    printf '%s\n' "$ticket" | "$work/source-link" enroll -gateway "$gateway" "${enroll_tls[@]}" \
        -ticket-file - -config "$work/connector.json"
    unset ticket
fi
install -m 700 "$work/source-link" "$executables/source-link.new"
mv -f -- "$executables/source-link.new" "$executables/source-link"
mv -f -- "$work/connector.json" "$config/connector.json"
install -m 644 "$here/systemd/source-link-connector.service" "$units/source-link-connector.service"
systemctl --user daemon-reload
systemctl --user enable source-link-connector.service
systemctl --user restart source-link-connector.service
if command -v loginctl >/dev/null && [[ $(loginctl show-user "$(id -un)" -p Linger --value 2>/dev/null || true) != yes ]]; then
    echo 'A host administrator can enable start-at-boot with loginctl enable-linger for this service account.' >&2
fi
