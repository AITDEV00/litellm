// Package transport carries bounded, typed streams over a single authenticated WebSocket.
package transport

import (
	"context"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"strings"
	"time"

	"github.com/coder/websocket"
	yamux "github.com/libp2p/go-yamux/v5"
)

const Protocol = "source-agent.v1"
const MaxControl = 48 << 10
const Handshake = 3 * time.Second
const Heartbeat = time.Second
const InventoryTTL = 5 * time.Second
const BridgeLifetime = 5 * time.Minute
const DefaultDataStreams = 256
const MaxDataStreams = 2048

var ErrTargetBusy = errors.New("target bridge slots are occupied")

type Open struct {
	Target      string `json:"target"`
	Fingerprint string `json:"fingerprint"`
	Probe       bool   `json:"probe,omitempty"`
}

type Inventory struct {
	Revision    uint64       `json:"revision"`
	Targets     []Advertised `json:"targets"`
	DataStreams int          `json:"data_streams,omitempty"`
}

type Advertised struct {
	ID          string `json:"id"`
	Fingerprint string `json:"fingerprint"`
}

type Observation struct {
	ID       string `json:"id"`
	Phase    string `json:"phase"`
	Revision uint64 `json:"revision,omitempty"`
	InFlight int    `json:"in_flight"`
	Ready    bool   `json:"ready"`
	Problem  string `json:"problem,omitempty"`
}

type Reply struct {
	PolicyRevision uint64        `json:"policy_revision"`
	AttachedAt     int64         `json:"attached_at_unix_ms"`
	Targets        []Observation `json:"targets"`
}

type Session struct {
	*yamux.Session
	socket *websocket.Conn
}

func Connect(ctx context.Context, url string, headers http.Header, client *http.Client, incoming ...uint32) (*Session, error) {
	if !strings.HasPrefix(url, "wss://") {
		return nil, errors.New("connector requires WSS")
	}
	handshake, cancel := context.WithTimeout(ctx, 8*time.Second)
	defer cancel()
	socket, response, err := websocket.Dial(handshake, url, &websocket.DialOptions{
		HTTPClient: client, HTTPHeader: headers, Subprotocols: []string{Protocol},
	})
	if err != nil {
		if response != nil {
			response.Body.Close()
			return nil, fmt.Errorf("worker ingress returned HTTP %d", response.StatusCode)
		}
		return nil, errors.New("worker ingress TLS or connection failed")
	}
	capacity := uint32(160)
	if len(incoming) != 0 {
		capacity = incoming[0]
	}
	return session(ctx, socket, true, capacity)
}

func Accept(ctx context.Context, w http.ResponseWriter, r *http.Request) (*Session, error) {
	socket, err := websocket.Accept(w, r, &websocket.AcceptOptions{Subprotocols: []string{Protocol}})
	if err != nil {
		return nil, err
	}
	return session(ctx, socket, false, 1)
}

func session(ctx context.Context, socket *websocket.Conn, client bool, incoming uint32) (*Session, error) {
	if socket.Subprotocol() != Protocol {
		socket.CloseNow()
		return nil, errors.New("unsupported source agent protocol")
	}
	wire := websocket.NetConn(ctx, socket, websocket.MessageBinary)
	socket.SetReadLimit(1 << 20)
	cfg := yamux.DefaultConfig()
	cfg.AcceptBacklog = 32
	cfg.KeepAliveInterval = 10 * time.Second
	cfg.ConnectionWriteTimeout = 5 * time.Second
	cfg.MaxIncomingStreams = incoming
	cfg.MaxStreamWindowSize = cfg.InitialStreamWindowSize
	cfg.MaxMessageSize = 64 << 10
	cfg.LogOutput = io.Discard
	create := yamux.Server
	if client {
		create = yamux.Client
	}
	mux, err := create(wire, cfg, nil)
	if err != nil {
		socket.CloseNow()
		return nil, err
	}
	return &Session{Session: mux, socket: socket}, nil
}

func (s *Session) Close() error {
	_ = s.socket.CloseNow()
	return s.Session.Close()
}

func (s *Session) Target(ctx context.Context, ref Open) (*yamux.Stream, error) {
	stream, err := s.OpenStream(ctx)
	if err != nil {
		return nil, err
	}
	stop := context.AfterFunc(ctx, func() { _ = stream.Reset() })
	defer stop()
	stream.SetDeadline(time.Now().Add(Handshake))
	if err = Write(stream, ref, 1024); err == nil {
		var ack [1]byte
		_, err = io.ReadFull(stream, ack[:])
		if err == nil {
			switch ack[0] {
			case 1:
			case 2:
				err = ErrTargetBusy
			default:
				err = errors.New("target channel rejected")
			}
		}
	}
	stream.SetDeadline(time.Time{})
	if err != nil || ctx.Err() != nil {
		stream.Reset()
		if err == nil {
			err = ctx.Err()
		}
		return nil, err
	}
	return stream, nil
}

// Control frames carry metadata only. Target payload never goes through JSON.
func Write(w io.Writer, v any, max uint32) error {
	b, err := json.Marshal(v)
	if err != nil {
		return err
	}
	if len(b) == 0 || uint64(len(b)) > uint64(max) {
		return errors.New("control frame exceeds limit")
	}
	frame := make([]byte, 4+len(b))
	binary.BigEndian.PutUint32(frame, uint32(len(b)))
	copy(frame[4:], b)
	_, err = w.Write(frame)
	return err
}

func Read(r io.Reader, v any, max uint32) error {
	var prefix [4]byte
	if _, err := io.ReadFull(r, prefix[:]); err != nil {
		return err
	}
	value := binary.BigEndian.Uint32(prefix[:])
	if value == 0 || value > max {
		return errors.New("control frame exceeds limit")
	}
	b := make([]byte, value)
	if _, err := io.ReadFull(r, b); err != nil {
		return err
	}
	return json.Unmarshal(b, v)
}

func Bridge(stream *yamux.Stream, target *net.TCPConn) {
	finished := make(chan struct{})
	go func() {
		defer close(finished)
		if _, err := Copy(target, stream); err != nil {
			target.Close()
			stream.Reset()
			return
		}
		_ = target.CloseWrite()
	}()
	if _, err := Copy(stream, target); err != nil {
		target.Close()
		stream.Reset()
	} else {
		_ = stream.CloseWrite()
	}
	<-finished
}
