package transport

import (
	"net"
	"sync"
)

// BoundListener limits accepted sockets, including headers that have not yet
// reached ServeHTTP. The kernel's TCP backlog remains the pre-HTTP queue.
func BoundListener(l net.Listener, limit int) net.Listener {
	return &boundedListener{Listener: l, slots: make(chan struct{}, limit), done: make(chan struct{})}
}

type boundedListener struct {
	net.Listener
	slots chan struct{}
	done  chan struct{}
	stop  sync.Once
}

func (l *boundedListener) Accept() (net.Conn, error) {
	select {
	case l.slots <- struct{}{}:
	case <-l.done:
		return nil, net.ErrClosed
	}
	conn, err := l.Listener.Accept()
	if err != nil {
		<-l.slots
		return nil, err
	}
	return &boundedConn{Conn: conn, release: func() { <-l.slots }}, nil
}

func (l *boundedListener) Close() error {
	l.stop.Do(func() { close(l.done) })
	return l.Listener.Close()
}

type boundedConn struct {
	net.Conn
	once    sync.Once
	release func()
}

func (c *boundedConn) Close() error {
	err := c.Conn.Close()
	c.once.Do(c.release)
	return err
}
