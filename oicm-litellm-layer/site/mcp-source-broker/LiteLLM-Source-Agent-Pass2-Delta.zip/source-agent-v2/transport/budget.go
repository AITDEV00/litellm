package transport

import (
	"io"
	"sync"
	"sync/atomic"
)

// Credits include a full receive window per endpoint, including for idle
// pooled streams. The separate request credit covers work outside the stream.
const StreamCharge int64 = 384 << 10
const RequestCharge int64 = 96 << 10

type Budget struct {
	limit int64
	used  atomic.Int64
}

func NewBudget(bytes int64) *Budget {
	return &Budget{limit: bytes}
}

func (b *Budget) Take(bytes, reserve int64) bool {
	for {
		used := b.used.Load()
		if used > b.limit-reserve-bytes {
			return false
		}
		if b.used.CompareAndSwap(used, used+bytes) {
			return true
		}
	}
}

func (b *Budget) Release(bytes int64) {
	b.used.Add(-bytes)
}

const copySize = 16 << 10

var copyBuffers = sync.Pool{New: func() any { return new([copySize]byte) }}

type readerOnly struct{ io.Reader }
type writerOnly struct{ io.Writer }

func Copy(dst io.Writer, src io.Reader) (int64, error) {
	b := copyBuffers.Get().(*[copySize]byte)
	defer copyBuffers.Put(b)
	// The tunnel's stream is userspace I/O. Avoid TCP fallback copy paths
	// that bypass the bounded scratch buffer without giving us splice.
	return io.CopyBuffer(writerOnly{dst}, readerOnly{src}, b[:])
}
