# Measured results

## Provenance and scope

The recovered signed Pass 1 executable has SHA-256 `b43e02ceac7cbb03733ecf1cbd421409e6a193574e6e26f977e35492f1505685`. Its Ed25519 manifest signature verified using the release's published key. All 17 Go source and module files in the release matched the attached export byte for byte. The attachment manifest's 112 file hashes also matched. The artifact contains the resulting attestation and the raw benchmark inputs and outputs. The Go candidate was blocked at the compiler step, so every throughput and latency number below is labeled Pass 1.

Fixture topology used separate relay, source agent, origin replicas, TLS ingress and load driver processes on Linux amd64 with nine visible CPUs and `GOMAXPROCS=4` each for relay and agent. CPU model was AMD EPYC 9V45. A Node TLS terminator carried the WSS bytes over TCP on loopback. The client compared the private relay HTTP API with direct origin HTTP. Requests were GET with empty request bodies and 128-byte responses except in the explicit pressure run. All test origins were local fixtures with real Ed25519 proofs. Real LAN and production LiteLLM/ingress latency remain unmeasured.

The load generator schedules arrivals independently of earlier completions. It reports local concurrency misses, scheduler misses, HTTP status counts, and `Retry-After` counts. Latency is reported for complete 200 responses. The table uses elapsed time from dispatch through the full body. The JSON also reports latency from the planned arrival, which includes scheduler delay. A quantile delta subtracts the direct run's quantile from the relay run's quantile. During shedding this describes only the successful-response samples. CPU is process CPU time divided by the sampled steady elapsed time, and RSS is the median resident memory from `/proc`. All roles share the host.

## Single-channel baseline

| Offered/s | Direct 200/s | Pass 1 200/s | Pass 1 503 and sent count | Wire p50/p95/p99 added, ms | Relay cores | Relay RSS, MiB | Agent cores | Agent RSS, MiB |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 1,000 | 1,000 | 997 | 9 / 3,000 | 0.66 / 2.02 / 4.07 | 0.40 | 14.5 | 0.45 | 14.3 |
| 2,000, 6 s | 2,000 | 1,985 | 91 / 12,000 | 0.71 / 1.75 / 2.76 | 0.66 | 14.8 | 0.73 | 14.5 |
| 5,000 | 4,985 | 4,154 | 2,446 / 14,908 | 1.03 / 2.81 / 3.88 | 1.13 | 15.6 | 1.11 | 14.6 |
| 10,000 | 9,925 | 5,374 | 13,240 / 29,363 | 1.10 / 2.30 / 2.78 | 1.30 | 18.4 | 1.24 | 14.7 |
| 10,000, 6 s | 9,981 | 5,297 | 27,929 / 59,712 | 1.13 / 2.31 / 3.16 | 1.32 | 18.8 | 1.25 | 14.6 |
| 50,000 | 49,187 | 3,277 | 133,510 / 143,340 | 1.93 / 6.19 / 12.48 | 1.72 | 24.8 | 0.83 | 14.7 |
| 50,000, 6 s | 49,531 | 3,713 | 271,917 / 294,197 | 1.81 / 4.87 / 8.36 | 1.76 | 25.3 | 0.87 | 14.6 |
| 100,000 | 89,838 | 1,814 | 242,157 / 247,599 | 4.17 / 12.28 / 21.47 | 2.43 | 25.1 | 0.54 | 14.7 |

Rows use three-second runs unless marked otherwise. The highest Pass 1 point below 1% HTTP shedding in these sweeps was approximately 1,985 successful/s. The highest observed goodput with shedding was 5,374/s. Above the knee, dropped driver arrivals also matter. At 50k offered in the three-second run, the driver sent 143,340 of 150,000 tunnel calls. At 100k it sent 247,599 of 300,000, and the direct run completed 269,515 of 300,000 offered. These measurements characterize the baseline knee and driver headroom. The physical candidate ceiling is still open.

## Where the latency and work went

- One new origin connection per forwarded call was directly confirmed. At 10k offered, the relay passed 16,123 calls and the origin saw 16,127 accepts, of which four were proofs. In the matched direct run, 29,774 successful calls used 212 new data TCP connections. The six-second repeat again matched accepts minus probes to forwarded calls exactly.
- A direct-only ablation at 1,000 offered/s measured dispatch-to-body p50/p95/p99 of 0.24/0.50/1.53 ms with keepalive and 0.32/0.80/1.96 ms with forced close. There were 10 versus 4,000 data TCP accepts. At 250/s the direction of the latency difference reversed, consistent with run-to-run noise at low load. The ablation isolates direct TCP churn. Tunnel stream-open framing and scheduling still contribute to the relay delta.
- An ingress with Nagle left at the Node socket default delivered 141/s at 10k/s offered, with 48.7 ms scheduled p50 for successful forwarding. With TCP_NODELAY on both ingress legs the corresponding run delivered 5,374/s at 1.95 ms scheduled p50. That is a fixture/network sensitivity check. The main table uses TCP_NODELAY throughout.
- At 1k offered, relay CPU was about 397 µs per successful call and agent CPU about 453 µs per successful call, including background work. At 50k offered, relay CPU rose while agent CPU fell relative to the 10k run, as work shifted toward shedding at the private ingress. GC trace logs are included. The reference executable omits profiling hooks and ptrace was denied by the execution environment. Stream-open, transport initialization, header parsing, copy and GC CPU attribution requires the supplied Go profiling launcher. The original nine 64-call Pass 1 cases reported a median added p50 of 2.444 ms and a range of 1.705–3.706 ms on a different fixture.

## Fairness, proofs and recovery

At 10/s for 12 seconds, the sibling completed 119/120 scheduled arrivals alone and 120/120 under 50k offered to the hot channel. The hot channel delivered 3,307/s and returned 545,385 busy responses. Sibling scheduled p50/p95/p99 went from 3.17/10.4/31.3 ms to 3.62/10.8/21.1 ms. The largest measured quantile ratio across these three points was 1.14× at p50. There were 119–120 sibling samples, making the p99 sensitive to isolated stalls. The hot channel delivered 3.3k/s of actual work in this case. A sibling bound at 100k/s of successful forwarded load remains unverified.

The controlled saturation case held all eight slots with 650 ms origin work. The next request returned 503 with `Retry-After: 1`. The sibling returned 200 and all eight admitted calls returned 200. The first new successful hot-channel call arrived 655 ms after the sampled rejection, essentially when held work finished. An independently signed wrong catalog made new hot-channel calls return 503 after 328 ms. The first 200 after restoration arrived after 985 ms. These timings are individual fixture observations. The 4-second proof TTL limits stale eligibility. Recovery time depends on fresh proof completion and tunnel scheduling.

## Channel count and memory

| Pass 1 case | Relay median RSS | Agent median RSS | Relay CPU | Agent CPU | Goodput |
| --- | ---: | ---: | ---: | ---: | ---: |
| One channel idle | 9.7 MiB | 10.0 MiB | ~0 cores | ~0 cores | — |
| 16 channels idle | 12.5 MiB | 12.2 MiB | 0.012 cores | 0.008 cores | — |
| 16 channels under 6,400/s spread load | 17.1 MiB | 14.7 MiB | 1.25 cores | 1.33 cores | 5,938/s |

These are process medians across separate launches. The apparent incremental idle RSS from one to 16 channels was 193 KiB/channel for the relay and 152 KiB/channel for the agent in these runs. The separate pressure runs gave roughly 126 and 114 KiB/channel respectively. Startup, sampled GC phase, and probe allocation are included. The Pass 1 binary accepted a 16-descriptor policy and rejected a 64-descriptor policy. The 64-channel candidate test is included in the harness for the next build.

| Blocked-reader pressure, 8 MiB response per call | Peak in flight | Relay idle → loaded, KiB | Agent idle → loaded, KiB | Increment per in-flight call, relay / agent |
| --- | ---: | ---: | ---: | ---: |
| One channel | 8 | 10,040 → 13,844 | 10,276 → 13,568 | 476 / 412 KiB |
| 16 channels | 128 | 11,936 → 46,096 | 11,988 → 28,740 | 267 / 131 KiB |

Clients set a 4 KiB receive buffer and held their sockets without draining. The table uses the median RSS of snapshots at peak observed occupancy. Kernel socket buffers and TLS ingress and origin memory are separate. The 128-call case presented 1 GiB of nominal response payload. Actual process RSS reflects streamed backpressure, including partially filled windows and retained buffers. The empirical per-call increments are pressure-case working-set figures, with no per-byte or candidate calibration implied.

## Candidate acceptance status

| Required result | Status |
| --- | --- |
| Candidate Go build, race suite and exact unmodified Pass 1 tests | Blocked by Go 1.27.4 and its offline modules. The workspace's `go` is a desktop board game. The official compiler checksum was verified against the Go release listing. The download request timed out under the workspace network policy. |
| Candidate 10k / 50k / 100k per-channel measurements and p50/p95/p99 | Pending a built candidate. The baseline data above is fully measured. |
| 64-channel idle and loaded RSS, candidate body-pressure memory calibration | Pending a built candidate. |
| Actual fast-LAN profile | Pending a runner with a physical network hop. |
| Maximum tested single-process goodput | 5,374/s single-channel and 5,938/s across 16 channels for Pass 1, in this environment. |

[Replay and pinned tools](../README.md) · [Raw evidence](../benchmarks/results/) · [Go 1.27.4 official digests](https://go.dev/dl/#go1.27.4)
