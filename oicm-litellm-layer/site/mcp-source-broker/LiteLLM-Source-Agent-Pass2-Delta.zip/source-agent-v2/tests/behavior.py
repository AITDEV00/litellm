"""Scaled-only integration checks using the real TLS attach and HTTP entry points."""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "benchmarks"))
from run import Lab  # noqa: E402


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("binary", type=lambda p: Path(p).resolve(strict=True))
    cli.add_argument("out", type=Path)
    opts = cli.parse_args()
    args = argparse.Namespace(binary=opts.binary, variant="candidate", body=128, hold_ms=900,
                              parallel=8, sibling_parallel=2, seconds=5, workers=2, concurrency=128,
                              origin_workers=2, go_cores=4, data_memory=96, data_connections=256, agent_streams=160,
                              idle_connections=8, limit_rps=0, channel_memory=0, lag_ms=15,
                              ingress_nagle=False)
    with (lab := Lab(args, 2, opts.out / "saturation")).close:
        lab.setup()
        warm = lab.profile("connection-reuse", [lab.traffic("hot", 150, (0,))])
        data = warm["originDelta"][0]
        assert data["requests"] > 680, warm
        assert data["accepted"] - data["proof"] < data["requests"] / 3, warm
        credentials = lab.traffic("credential-stripping", 25, (0,))
        credentials["headers"] = {
            "Authorization": "Bearer synthetic-test",
            "Cookie": "fixture=redacted",
            "X-API-Key": "fixture-secret",
        }
        stripped = lab.profile("credential-stripping", [credentials])
        assert stripped["groups"][0]["successFraction"] >= 0.98, stripped
        assert stripped["originDelta"][0]["leakedCredentials"] == 0, stripped
        lab.recovery()
    args.limit_rps = 10
    with (lab := Lab(args, 2, opts.out / "rate")).close:
        lab.setup()
        peer = lab.traffic("sibling", 10, (1,), sibling=True)
        idle = lab.profile("sibling-idle", [peer])["groups"][0]
        tested = lab.profile("rate-and-fairness", [lab.traffic("hot", 400), peer])
        hot, sibling = tested["groups"]
        assert hot["statuses"].get("429", 0) > 500, tested
        assert hot["retryAfter"]["429"] == hot["statuses"]["429"], tested
        assert 40 <= hot["statuses"].get("200", 0) <= 60, tested
        assert sibling["successFraction"] >= 0.98, tested
        assert sibling["scheduledMS"]["p99"] <= 2 * idle["scheduledMS"]["p99"] + 5, tested


if __name__ == "__main__":
    main()
