#!/usr/bin/env bash
set -euo pipefail

if [[ $# != 1 ]]; then
  printf 'usage: %s /path/to/patched/reference\n' "$0" >&2
  exit 2
fi
cd -- "$1"
go_bin="${GO:-go}"
export GOTOOLCHAIN=local
if [[ "$("$go_bin" env GOVERSION)" != go1.27.4 ]]; then
  printf 'the reference pins go1.27.4\n' >&2
  exit 2
fi
make "GO=$go_bin" unit
make "GO=$go_bin" behavior
make "GO=$go_bin" e2e
make "GO=$go_bin" kube
