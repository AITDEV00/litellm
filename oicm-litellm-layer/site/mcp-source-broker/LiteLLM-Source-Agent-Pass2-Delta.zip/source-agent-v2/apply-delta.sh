#!/usr/bin/env bash
set -euo pipefail

if [[ $# != 1 ]]; then
  printf 'usage: %s /path/to/extracted/reference\n' "$0" >&2
  exit 2
fi
bundle="$(cd -- "$(dirname -- "$0")" && pwd)"
reference="$(cd -- "$1" && pwd)"
(
  cd "$reference"
  sha256sum -c "$bundle/BASELINE.sha256"
  git apply --check "$bundle/reference.patch"
  git apply "$bundle/reference.patch"
)
