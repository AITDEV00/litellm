# LiteLLM source-agent Pass 2

This bundle contains a source delta against `reference/` in the attached `d48b97cd2be` export, a reproducible harness, and measured Pass 1 results. The source directories mirror `reference/source-agent/`. The unified patch is the applyable artifact.

- [Seven numbered design answers](docs/SCALE-DESIGN.md)
- [Measurements and acceptance status](docs/MEASURED-RESULTS.md)
- [Raw profiles, process samples and runtime logs](benchmarks/results/)

## Apply and compile

Start from separate pristine and candidate extractions of the attached archive. The apply script verifies the exact original files touched by the delta and checks the patch before writing.

```bash
bash source-agent-v2/apply-delta.sh /path/to/candidate/reference
export GO=/path/to/go1.27.4/bin/go GOTOOLCHAIN=local
make -C /path/to/candidate/reference "GO=$GO" build
```

The compiler is Go 1.27.4, Linux amd64. Its official tarball SHA-256 is `7226736c2339719cda28fbf3a54d71aa63bcefe376e98cef00034268dab24840`. The reference fetch script supports staging with `--archives`. Use the original module pins and sums with an online staging builder or verified offline Go module cache. They pin coder/websocket 1.8.15, go-yamux/v5 5.1.0, buffer-pool 0.0.2 and YAML v3.0.4. Harness runtime pins are Python 3.12.14, Node 24.22.1, OpenSSL 3.5.7, Bash 5.2.37, GNU Make 4.4.1 and Git 2.52.0. The original Python suites use the supplied `tests/requirements.lock.txt` and the original evidence's Caddy 2.11.9, Kubernetes 1.35.0, PostgreSQL 18.6 and LiteLLM v1.108.5 pins. [Go release checksums](https://go.dev/dl/#go1.27.4)

## Opt in per approved channel

The agent's allowlist and the authority's approved descriptor must have the same exact fields. Approve a new descriptor revision through the existing authority path.

```yaml
id: reports
kind: openapi
address: "127.0.0.1:18081"
path: /reports
proof_path: /proof
methods: [GET, POST]
parallel: 128
scale:
  requests_per_second: 10000
  burst: 128
  memory_mib: 64
  idle_connections: 64
  request_timeout_ms: 30000
  header_timeout_ms: 5000
```

Roll out both binaries before adding `scale` or expanding beyond 16 channels. Run the relay with `-data-memory-mib 128 -probe-memory-mib 32 -data-connections 1024` for the 10k planning profile, and leave the agent at `-data-streams 256`. A verified descriptor can set `scale.disable_keep_alive: true` to use the new limits with fresh origin connections. The proof protects readiness and every call still requires the existing channel lease. Size pod memory and FDs separately on both sides.

## Reproduce the measurements

The reference binary can be built from a pristine extraction or obtained from the recovered Pass 1 release. The data-plane benchmark uses synthetic loopback services only and creates short-lived fixture credentials in a temporary directory. Scripts save no credentials in their results.

```bash
b=/path/to/pristine/reference/bin/source-agent
out=/path/to/new/run-directory
h=source-agent-v2/benchmarks/run.py

python3 "$h" --binary "$b" --variant reference --out "$out/sweep"
python3 "$h" --binary "$b" --variant reference --out "$out/repeat" --seconds 6 \
  --rates 1000,1500,2000,7000,10000,50000
python3 "$h" --binary "$b" --variant reference --out "$out/nagle" --ingress-nagle \
  --rates 1000,2500,5000,10000,50000,100000
python3 "$h" --binary "$b" --variant reference --out "$out/tcp" --suite tcp-ablation \
  --rates 250,1000 --seconds 4
python3 "$h" --binary "$b" --variant reference --out "$out/fair" --suite fair \
  --seconds 12 --hot-rate 50000
python3 "$h" --binary "$b" --variant reference --out "$out/width" --suite wide \
  --seconds 8 --hot-rate 6400
python3 "$h" --binary "$b" --variant reference --out "$out/recovery" --suite recovery
python3 "$h" --binary "$b" --variant reference --out "$out/pressure-8" --suite pressure --body 8388608
python3 "$h" --binary "$b" --variant reference --out "$out/pressure-128" --suite pressure \
  --channels 16 --sibling-parallel 8 --body 8388608
```

Use longer runs with independent repetitions for the candidate. The rate driver records client arrival misses. Increase load-driver concurrency or use a separate load host if the direct control cannot deliver the rate with ≥99% success.

```bash
q=/path/to/candidate/reference/bin/source-agent
python3 "$h" --binary "$q" --variant candidate --out "$out/candidate-sweep" \
  --parallel 768 --agent-streams 896 --data-memory 512 --channel-memory 384 \
  --idle-connections 384 --concurrency 1024 --workers 8 --seconds 20 --rates 10000,50000,100000
python3 "$h" --binary "$q" --variant candidate --out "$out/candidate-fair" --suite fair \
  --parallel 768 --agent-streams 896 --data-memory 512 --channel-memory 384 \
  --idle-connections 384 --concurrency 1024 --workers 8 --seconds 20 --hot-rate 100000
python3 "$h" --binary "$q" --variant candidate --out "$out/candidate-width" --suite wide \
  --parallel 256 --agent-streams 512 --data-memory 256 --seconds 20 --hot-rate 6400
python3 "$h" --binary "$q" --variant candidate --out "$out/candidate-pressure" --suite pressure \
  --channels 16 --sibling-parallel 8 --body 8388608
python3 source-agent-v2/tests/behavior.py "$q" "$out/candidate-behavior"
bash source-agent-v2/tests/check-reference.sh /path/to/candidate/reference
```

The unmodified reference test runner expects its pinned Python environment, database and Kubernetes/ingress tools. The new behavior script checks rate/capacity codes, recovery, pool reuse, credential filtering and low-rate sibling latency under a capped neighboring load. For the high-rate fairness gate, evaluate 10/s sibling completion and p99 against the idle-origin comparison in the JSON. A useful acceptance rule is ≥99% sibling completion and p99 ≤2× its idle-run p99 plus 2 ms, at ≥99% of the hot channel's target goodput. Adjust application SLOs independently. Include origin body sizes and relay/agent RSS.

For LAN, put ingress and relay on one lab host, agent and fixture origins on another, and use a separate client host. Configure certificate SAN and CA for the actual ingress hostname. The agent still reaches its fixture over approved local loopback. Run `node source-agent-v2/benchmarks/load.mjs bench-plan.json` on the load host. Each plan has `duration` in seconds, optional `secret` for the private API, and `groups` with `name`, `urls`, `rps`, `workers`, `concurrency`, and `responseBytes`. Run the direct control to the fixture over the same physical network. Keep the plan private and record interface speed, RTT and packet loss. Pair direct and forwarded runs at each offered rate. Sample relay and agent CPU/RSS from Linux `/proc` during the steady window.

## Profile code paths

Compile the optional profiling launcher outside the deployed source tree. Sweep a small enough subset that the lab process can terminate cleanly and write its profiles. Use a different profile directory for each comparison.

```bash
bash source-agent-v2/benchmarks/prepare-profiles.sh /path/to/candidate/reference "$out/profiler"
python3 "$h" --binary "$out/profiler/profile-replica" --variant candidate --out "$out/profile-run" \
  --parallel 512 --idle-connections 128 --seconds 15 --rates 10000
"$GO" tool pprof -top "$out/profiler/replica.test" "$out/profiler/relay.cpu.pprof"
"$GO" tool pprof -top "$out/profiler/replica.test" "$out/profiler/run.cpu.pprof"
"$GO" tool pprof -alloc_space -top "$out/profiler/replica.test" "$out/profiler/relay.mem.pprof"
```

The Go profile launcher wraps the original `run` entry point. Run the same launcher against the pristine reference to attribute stream-open, HTTP transport, header, copy and allocation costs comparatively. The benchmark uses a driver that sheds local misses rather than hiding them in client-side queues.
