// Bounded open-loop HTTP/1.1 load generator. Node 24.22.1, no npm packages.
import { Agent, request } from 'node:http';
import { readFileSync } from 'node:fs';
import { Worker, isMainThread, parentPort, workerData } from 'node:worker_threads';

const clock = () => Number(process.hrtime.bigint()) / 1e6;

function increment(map, key, n = 1) {
  map[key] = (map[key] ?? 0) + n;
}

function bucket(histogram, ms) {
  const us = Math.max(0, Math.round(ms * 1e3));
  const width = us < 10_000 ? 10 : us < 100_000 ? 100 : us < 1e6 ? 1000 : 10_000;
  increment(histogram, Math.round(us / width) * width);
}

function percentiles(histogram) {
  const sorted = Object.entries(histogram).map(([k, v]) => [Number(k), v]).sort((a, b) => a[0] - b[0]);
  const count = sorted.reduce((n, [, value]) => n + value, 0);
  return Object.fromEntries([50, 95, 99].map(p => {
    let cumulative = 0;
    const result = sorted.find(([, n]) => (cumulative += n) >= Math.ceil(count * p / 100));
    return ['p' + p, result ? result[0] / 1000 : null];
  }));
}

function run({ group, start, duration, worker, workers, maxLagMS, timeoutMS, secret }) {
  const all = Math.round(group.rps * duration);
  const spacing = 1000 / group.rps;
  const cap = Math.ceil(group.concurrency / workers);
  const agent = new Agent({
    keepAlive: true, maxSockets: cap, maxTotalSockets: cap, maxFreeSockets: cap,
  });
  const report = {
    scheduled: 0, sent: 0, capacityMiss: 0, schedulerMiss: 0, peak: 0,
    statuses: {}, retryAfter: {}, scheduledMS: {}, wireMS: {}, lagMS: {}, seconds: {},
  };
  let index = worker;
  let active = 0;
  let finished = false;

  function done() {
    if (finished && active === 0) {
      agent.destroy();
      parentPort.postMessage(report);
    }
  }

  function send(slot, plannedAt) {
    report.sent++;
    active++;
    report.peak = Math.max(report.peak, active);
    const begin = clock();
    bucket(report.lagMS, begin - plannedAt);
    const second = Math.floor(Math.max(0, plannedAt - start) / 1000);
    const perSecond = (report.seconds[second] ??= {});
    let complete = false;
    function end(status, headers) {
      if (complete) return;
      complete = true;
      increment(report.statuses, status);
      increment(perSecond, status);
      if (headers?.['retry-after']) increment(report.retryAfter, status);
      if (status === 200) {
        const end = clock();
        bucket(report.scheduledMS, end - plannedAt);
        bucket(report.wireMS, end - begin);
      }
      active--;
      done();
    }
    const index = slot % group.urls.length;
    const req = request(group.urls[index], {
      agent, method: 'GET', headers: {
        ...(secret ? { 'X-Source-Broker-Key': secret } : {}),
        ...(group.headers ?? {}),
      },
    }, res => {
      let received = 0;
      res.on('data', chunk => { received += chunk.length; });
      res.once('error', () => end('body_error'));
      res.once('end', () => end(
        res.statusCode === 200 && received !== group.responseBytes ? 'wrong_body' : res.statusCode,
        res.headers));
    });
    req.setTimeout(timeoutMS, () => req.destroy(new Error('timeout')));
    req.once('error', e => end(e.code ?? e.message));
    req.end();
  }

  function tick() {
    const now = clock();
    const due = Math.min(all, Math.floor((now - start) / spacing) + 1);
    for (; index < due; index += workers) {
      const plannedAt = start + index * spacing;
      report.scheduled++;
      if (now - plannedAt > maxLagMS) report.schedulerMiss++;
      else if (active === cap) report.capacityMiss++;
      else send(index, plannedAt);
    }
    if (index >= all) {
      finished = true;
      done();
    } else {
      setTimeout(tick, Math.max(1, Math.min(10, start + index * spacing - clock())));
    }
  }
  tick();
}

async function main() {
  const options = JSON.parse(readFileSync(process.argv[2]));
  const start = clock() + 850;
  const results = await Promise.all(options.groups.map(async group => {
    const workers = group.workers ?? 1;
    const items = await Promise.all(Array.from({ length: workers }, (_, worker) => new Promise((resolve, reject) => {
      const w = new Worker(new URL(import.meta.url), {
        workerData: { start, duration: options.duration, worker, workers,
          maxLagMS: options.maxLagMS ?? 10, timeoutMS: options.timeoutMS ?? 3000,
          group, secret: options.secret },
      });
      w.on('error', reject);
      w.on('message', resolve);
      w.on('exit', code => { if (code !== 0) reject(new Error('worker exit ' + code)); });
    })));
    const total = { name: group.name, offeredRPS: group.rps, workers, concurrency: group.concurrency,
      scheduled: 0, sent: 0, capacityMiss: 0, schedulerMiss: 0, statuses: {}, retryAfter: {}, seconds: {} };
    const histograms = { scheduledMS: {}, wireMS: {}, lagMS: {} };
    for (const item of items) {
      for (const key of ['scheduled', 'sent', 'capacityMiss', 'schedulerMiss']) total[key] += item[key];
      for (const key of ['statuses', 'retryAfter']) {
        for (const [k, n] of Object.entries(item[key])) increment(total[key], k, n);
      }
      for (const [second, values] of Object.entries(item.seconds)) {
        for (const [k, n] of Object.entries(values)) increment(total.seconds[second] ??= {}, k, n);
      }
      for (const key of Object.keys(histograms)) {
        for (const [k, n] of Object.entries(item[key])) increment(histograms[key], k, n);
      }
    }
    for (const [key, values] of Object.entries(histograms)) total[key] = percentiles(values);
    total.scheduledStartMonotonicMS = start;
    total.successRPS = (total.statuses['200'] ?? 0) / options.duration;
    total.successFraction = (total.statuses['200'] ?? 0) / Math.max(1, total.scheduled);
    total.workerPeaks = items.map(x => x.peak);
    return total;
  }));
  console.log(JSON.stringify(results));
}

if (isMainThread) await main();
else run(workerData);
