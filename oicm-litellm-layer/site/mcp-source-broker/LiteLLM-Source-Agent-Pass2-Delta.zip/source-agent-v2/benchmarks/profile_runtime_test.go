package main

import (
	"context"
	"os"
	"os/signal"
	"syscall"
	"testing"
)

func TestProfileReplica(t *testing.T) {
	start := 1
	for start < len(os.Args) && os.Args[start] != "--" {
		start++
	}
	if start+1 >= len(os.Args) {
		t.Skip("lab launcher only")
	}
	args := os.Args[start+1:]
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	if err := run(ctx, args[0], args[1:]); err != nil {
		t.Fatal(err)
	}
}
