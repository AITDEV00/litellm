// Disposable HTTP origins and a TLS-terminating ingress. Node 24.22.1, no npm packages.
import { createPrivateKey, sign } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { createServer } from 'node:http';
import { connect } from 'node:net';
import * as tls from 'node:tls';

const [, , role, path] = process.argv;
const config = JSON.parse(readFileSync(path));
const host = config.host ?? '127.0.0.1';

function listen(server, port, bind = host, reusePort = false) {
  return new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen({ port, host: bind, reusePort }, resolve);
  });
}

if (role === 'ingress') {
  const server = tls.createServer({
    cert: readFileSync(config.cert), key: readFileSync(config.key), minVersion: 'TLSv1.2',
  }, socket => {
    const worker = connect(config.worker, host);
    if (config.noDelay) {
      socket.setNoDelay(true);
      worker.setNoDelay(true);
    }
    socket.on('error', () => worker.destroy());
    worker.on('error', () => socket.destroy());
    socket.on('close', () => worker.destroy());
    worker.on('close', () => socket.destroy());
    socket.pipe(worker).pipe(socket);
  });
  await listen(server, config.ingress, config.ingressBind ?? host);
} else if (role === 'origin') {
  const key = createPrivateKey(readFileSync(config.proofKey));
  const response = Buffer.alloc(config.responseBytes, 'x');
  const counts = config.channels.map(() => ({ accepted: 0, proof: 0, requests: 0, leakedCredentials: 0 }));
  await Promise.all(config.channels.map((channel, index) => {
    const counter = counts[index];
    const server = createServer((req, res) => {
      req.resume();
      if (req.url === '/proof') {
        counter.proof++;
        const catalog = existsSync(config.badProof) && index === 0 ? 'f'.repeat(64) : config.catalog;
        const message = ['source-agent-catalog-v1', req.headers['x-source-nonce'],
          req.headers['x-source-agent'], req.headers['x-source-channel'], catalog].join('\n');
        if (req.headers['x-source-channel'] !== channel.id) {
          res.writeHead(400).end();
          return;
        }
        res.writeHead(204, {
          'X-Source-Catalog': catalog,
          'X-Source-Signature': sign(null, Buffer.from(message), key).toString('base64'),
        }).end();
        return;
      }
      if (!req.url.startsWith('/api')) {
        res.writeHead(404).end();
        return;
      }
      counter.requests++;
      if (Object.keys(req.headers).some(h => ['authorization', 'cookie', 'x-api-key', 'x-source-broker-key'].includes(h))) {
        counter.leakedCredentials++;
      }
      const send = () => res.writeHead(200, { 'Content-Type': 'application/octet-stream',
        'Content-Length': response.length }).end(response);
      if (req.url === '/api?hold=1') setTimeout(send, config.holdMS);
      else send();
    });
    server.keepAliveTimeout = 30_000;
    server.on('connection', () => counter.accepted++);
    return listen(server, channel.port, host, true);
  }));
  process.on('SIGUSR2', () => {
    writeFileSync(config.statsPrefix + process.pid + '.json', JSON.stringify(counts));
  });
} else {
  throw new Error('expected origin or ingress');
}
console.log('READY');
