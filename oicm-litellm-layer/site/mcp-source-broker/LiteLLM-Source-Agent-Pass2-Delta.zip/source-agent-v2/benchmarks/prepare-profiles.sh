#!/usr/bin/env bash
set -euo pipefail

if [[ $# != 2 ]]; then
  printf 'usage: %s /path/to/reference /path/to/new-profile-dir\n' "$0" >&2
  exit 2
fi
here="$(cd -- "$(dirname -- "$0")" && pwd)"
source_dir="$(cd -- "$1" && pwd)"
profile_dir="$(mkdir -p -- "$2" && cd -- "$2" && pwd)"
scratch="$(mktemp -d)"
trap 'rm -rf -- "$scratch"' EXIT
go_bin="${GO:-go}"
export GOTOOLCHAIN=local
if [[ "$("$go_bin" env GOVERSION)" != go1.27.4 ]]; then
  printf 'the reference and this harness pin go1.27.4\n' >&2
  exit 2
fi
cp -a -- "$source_dir/source-agent" "$scratch/source-agent"
cp -- "$here/profile_runtime_test.go" "$scratch/source-agent/cmd/source-agent/"
(
  cd "$scratch/source-agent"
  "$go_bin" test -mod=readonly -c -o "$profile_dir/replica.test" ./cmd/source-agent
)
cat > "$profile_dir/profile-replica" <<'LAUNCH'
#!/usr/bin/env bash
set -euo pipefail
root="$(cd -- "$(dirname -- "$0")" && pwd)"
role="$1"
case "$role" in run|relay) ;; *) exit 2 ;; esac
extra=()
if [[ "${SOURCE_AGENT_PROFILE_BLOCKS:-0}" == 1 ]]; then
  extra=("-test.blockprofile=$root/$role.block.pprof" -test.blockprofilerate=100000
         "-test.mutexprofile=$root/$role.mutex.pprof" -test.mutexprofilefraction=10)
fi
exec "$root/replica.test" -test.run='^TestProfileReplica$' -test.timeout=0 \
  "-test.cpuprofile=$root/$role.cpu.pprof" "-test.memprofile=$root/$role.mem.pprof" "${extra[@]}" -- "$@"
LAUNCH
chmod +x -- "$profile_dir/profile-replica"
