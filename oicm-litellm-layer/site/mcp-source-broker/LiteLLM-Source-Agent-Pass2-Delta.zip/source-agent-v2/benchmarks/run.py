"""Reproducible local baseline and candidate runs against the real agent binary."""

import argparse
import concurrent.futures
import contextlib
import hashlib
import json
import os
import platform
import secrets
import signal
import socket
import statistics
import subprocess
import tempfile
import threading
import time
import urllib.error
import urllib.request
from base64 import b64encode
from pathlib import Path

HERE = Path(__file__).resolve().parent
HOST = "127.0.0.1"
APIVERSION = "source-agent.example.org/v1alpha1"
TICKS = os.sysconf("SC_CLK_TCK")
PORTS = set()


def port():
    while True:
        with socket.socket() as sock:
            sock.bind((HOST, 0))
            candidate = sock.getsockname()[1]
        if candidate not in PORTS:
            PORTS.add(candidate)
            return candidate


def write(path, value):
    path.write_text(json.dumps(value), encoding="utf-8")
    path.chmod(0o600)
    return str(path)


def text_file(path, value):
    path.write_text(value, encoding="utf-8")
    path.chmod(0o600)
    return str(path)


def local(url, headers=None, timeout=5):
    request = urllib.request.Request(url, headers=headers or {})
    try:
        response = urllib.request.urlopen(request, timeout=timeout)
    except urllib.error.HTTPError as response:
        with response:
            return response.code, dict(response.headers), response.read()
    with response:
        return response.status, dict(response.headers), response.read()


def wait(test, seconds=15, step=0.025):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        try:
            result = test()
            if result:
                return result
        except (OSError, urllib.error.URLError, KeyError):
            pass
        time.sleep(step)
    raise RuntimeError("condition timed out")


def proc(pid):
    root = Path("/proc") / str(pid)
    fields = (root / "stat").read_text().rsplit(")", 1)[1].split()
    variables = {}
    for line in (root / "status").read_text().splitlines():
        key, _, value = line.partition(":")
        if key in ("VmRSS", "VmHWM", "Threads"):
            variables[key] = int(value.strip().split()[0])
    return {"us_user": int(fields[11]) / TICKS, "us_system": int(fields[12]) / TICKS,
            "rssKiB": variables.get("VmRSS", 0), "hwmKiB": variables.get("VmHWM", 0),
            "threads": variables.get("Threads", 0), "fd": len(list((root / "fd").iterdir()))}


def summary(samples, start, stop):
    rows = [item for item in samples if start <= item["monotonic"] < stop and "relay" in item]
    output = {}
    if len(rows) < 2:
        return output
    elapsed = rows[-1]["monotonic"] - rows[0]["monotonic"]
    for role in rows[0]:
        if role == "monotonic" or role not in rows[-1]:
            continue
        first, last = rows[0][role], rows[-1][role]
        output[role] = {
            "cpuCores": round((last["us_user"] + last["us_system"] - first["us_user"] - first["us_system"]) / elapsed, 4),
            "userCores": round((last["us_user"] - first["us_user"]) / elapsed, 4),
            "systemCores": round((last["us_system"] - first["us_system"]) / elapsed, 4),
            "rssMedianKiB": int(statistics.median(row[role]["rssKiB"] for row in rows if role in row)),
            "rssMaxKiB": max(row[role]["rssKiB"] for row in rows if role in row),
            "peakFD": max(row[role]["fd"] for row in rows if role in row),
        }
    return output


class Lab:
    def __init__(self, args, channels, out):
        self.args = args
        self.n = channels
        self.out = out
        self.out.mkdir(parents=True, exist_ok=True)
        self.roles = {}
        self.close = contextlib.ExitStack()
        self.secrets = {"agent": secrets.token_urlsafe(32), "broker": secrets.token_urlsafe(32)}
        self.headers = {"X-Source-Broker-Key": self.secrets["broker"]}
        self.agent_id = "local-agent"
        self.catalog = hashlib.sha256(b"load fixture catalog").hexdigest()

    def spawn(self, role, *cmd, **kwargs):
        log = self.close.enter_context((self.out / f"{role}.log").open("wb"))
        handle = subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT, **kwargs)
        self.roles[role] = handle
        self.close.callback(self.stop, handle)
        return handle

    @staticmethod
    def stop(process):
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(3)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(3)

    def setup(self):
        self.work = Path(self.close.enter_context(tempfile.TemporaryDirectory(prefix="source-scale-")))
        self.relay_port, worker, ingress = port(), port(), port()
        self.proof = self.work / "bad-proof"
        self.stats_files = str(self.work / "origin-")
        self.targets = [{"id": f"service-{i:02}", "port": port()} for i in range(self.n)]
        cert, key, proof = [self.work / name for name in ("tls.pem", "tls-key.pem", "proof-key.pem")]
        subprocess.run(["openssl", "req", "-x509", "-newkey", "ec", "-pkeyopt", "ec_paramgen_curve:P-256",
                        "-nodes", "-keyout", key, "-out", cert, "-days", "2",
                        "-subj", "/CN=127.0.0.1", "-addext", "subjectAltName=IP:127.0.0.1"],
                       check=True, capture_output=True)
        subprocess.run(["openssl", "genpkey", "-algorithm", "ED25519", "-out", proof], check=True, capture_output=True)
        der = subprocess.check_output(["openssl", "pkey", "-in", proof, "-pubout", "-outform", "DER"])
        assert der[:12] == bytes.fromhex("302a300506032b6570032100"), "unexpected Ed25519 SPKI"
        proof_public = b64encode(der[12:]).decode()
        fixture = write(self.work / "fixtures.json", {
            "cert": str(cert), "key": str(key), "proofKey": str(proof), "worker": worker, "ingress": ingress,
            "channels": self.targets, "catalog": self.catalog, "responseBytes": self.args.body,
            "badProof": str(self.proof), "holdMS": self.args.hold_ms, "statsPrefix": self.stats_files,
            "noDelay": not self.args.ingress_nagle,
        })
        self.origins = [
            self.spawn(f"origin-{replica}", "node", HERE / "fixtures.mjs", "origin", fixture)
            for replica in range(self.args.origin_workers)
        ]
        self.spawn("ingress", "node", HERE / "fixtures.mjs", "ingress", fixture)
        for role in self.roles:
            wait(lambda: b"READY" in (self.out / f"{role}.log").read_bytes())
        descriptors = []
        for i, channel in enumerate(self.targets):
            concurrency = self.args.parallel if i == 0 else self.args.sibling_parallel
            descriptor = {"id": channel["id"], "kind": "openapi", "path": "/api", "proof_path": "/proof",
                          "parallel": concurrency, "address": f"{HOST}:{channel['port']}", "methods": ["GET"]}
            if self.args.variant == "candidate":
                rate = self.args.limit_rps if i == 0 else 0
                descriptor["scale"] = {
                    "idle_connections": min(self.args.idle_connections, concurrency),
                    "requests_per_second": rate, "burst": min(concurrency, rate),
                    "memory_mib": self.args.channel_memory if i == 0 else 0,
                }
            descriptors.append(descriptor)
        authority = write(self.work / "authority.json", {
            "revision": 1, "agents": [{"id": self.agent_id, "epoch": 1, "phase": "active",
                "credential_sha256": hashlib.sha256(self.secrets["agent"].encode()).hexdigest(), "channels": [
                    {"descriptor": descriptor, "revision": 1, "phase": "active",
                     "catalog_sha256": self.catalog, "proof_key": proof_public} for descriptor in descriptors
                ]}],
        })
        policy = write(self.work / "policy.json", {"apiVersion": APIVERSION, "kind": "TargetPolicy", "targets": descriptors})
        state = write(self.work / "state.json", {"apiVersion": APIVERSION, "kind": "AgentState", "revision": 1,
                                              "enabled": [c["id"] for c in self.targets]})
        credential = write(self.work / "credential.json", {"epoch": 1, "token": self.secrets["agent"]})
        identity = write(self.work / "identity.json", {
            "agent": self.agent_id, "endpoint": f"wss://{HOST}:{ingress}/mcp-source-agent", "ca_file": str(cert),
        })
        broker = text_file(self.work / "broker.key", self.secrets["broker"] + "\n")
        env = os.environ | {"GOMAXPROCS": str(self.args.go_cores), "GODEBUG": "gctrace=1"}
        relay_flags = ["-data-memory-mib", str(self.args.data_memory), "-probe-memory-mib", "32",
                       "-data-connections", str(self.args.data_connections)]
        agent_flags = ["-data-streams", str(self.args.agent_streams)]
        scaled = self.args.variant == "candidate"
        self.spawn("relay", self.args.binary, "relay", "-policy", authority, "-worker", f"{HOST}:{worker}",
                   "-data", f"{HOST}:{self.relay_port}", "-data-token", broker,
                   *(relay_flags if scaled else []), env=env)
        self.spawn("agent", self.args.binary, "run", "-identity", identity, "-state", state,
                   "-policy", policy, "-credential", credential, *(agent_flags if scaled else []), env=env)
        began = time.monotonic()
        wait(lambda: len(status := self.status()) == self.n and all(c["ready"] for c in status))
        self.ready_ms = (time.monotonic() - began) * 1000

    def status(self):
        code, _, data = local(f"http://{HOST}:{self.relay_port}/v1/observed", self.headers)
        if code != 200:
            return []
        return json.loads(data).get("attached", {}).get(self.agent_id, {}).get("targets") or []

    def url(self, i, relay=True, query=""):
        if relay:
            return f"http://{HOST}:{self.relay_port}/sources/{self.agent_id}/{self.targets[i]['id']}{query}"
        return f"http://{HOST}:{self.targets[i]['port']}/api{query}"

    def origin_counts(self):
        total = [{} for _ in self.targets]
        for origin in self.origins:
            report = Path(self.stats_files + str(origin.pid) + ".json")
            report.unlink(missing_ok=True)
            origin.send_signal(signal.SIGUSR2)
            wait(report.is_file, 5)
            for dst, src in zip(total, json.loads(report.read_bytes()), strict=True):
                for k, v in src.items():
                    dst[k] = dst.get(k, 0) + v
        return total

    def monitor(self, samples, stop):
        while True:
            snapshot = {"monotonic": time.monotonic()}
            for key, child in list(self.roles.items()):
                try:
                    snapshot[key] = proc(child.pid)
                except OSError:
                    continue
            samples.append(snapshot)
            if stop.wait(0.1):
                return

    def profile(self, name, groups=None, duration=None, direct=False):
        samples = []
        stop_event = threading.Event()
        duration = duration or self.args.seconds
        thread = threading.Thread(target=self.monitor, args=(samples, stop_event))
        begin = time.monotonic()
        # State snapshots include proof dials, which are counted separately.
        origins_before = self.origin_counts()
        thread.start()
        try:
            if groups:
                config = {"groups": groups, "duration": duration, "maxLagMS": self.args.lag_ms}
                if not direct:
                    config["secret"] = self.secrets["broker"]
                spec = write(self.work / "load.json", config)
                driver = subprocess.Popen(["node", HERE / "load.mjs", spec], stdout=subprocess.PIPE, text=True)
                self.roles["driver"] = driver
                try:
                    raw, _ = driver.communicate(timeout=duration + 25)
                finally:
                    self.stop(driver)
                    self.roles.pop("driver")
                if driver.returncode != 0:
                    raise RuntimeError(f"load exited {driver.returncode}")
                metrics = json.loads(raw)
                start = metrics[0]["scheduledStartMonotonicMS"] / 1000
            else:
                start = time.monotonic()
                time.sleep(duration)
                metrics = []
        finally:
            stop_event.set()
            thread.join()
        origins_after = self.origin_counts()
        result = {
            "case": name, "channels": self.n, "duration": duration, "groups": metrics, "readyMS": self.ready_ms,
            "steady": summary(samples, start + min(0.5, duration / 4), start + duration),
            "originDelta": [{k: after[k] - before[k] for k in after}
                            for before, after in zip(origins_before, origins_after, strict=True)],
            "wallS": time.monotonic() - begin,
        }
        with (self.out / "samples.jsonl").open("a") as fp:
            for sample in samples:
                fp.write(json.dumps({"case": name, **sample}, sort_keys=True) + "\n")
        self.record(result)
        return result

    def record(self, result):
        row = json.dumps(result, sort_keys=True)
        with (self.out / "profiles.jsonl").open("a") as fp:
            fp.write(row + "\n")
        print(row, flush=True)

    def traffic(self, name, rps, indices=(0,), relay=True, sibling=False):
        return {"name": name, "rps": rps, "concurrency": 8 if sibling else self.args.concurrency,
                "workers": 1 if sibling else self.args.workers, "responseBytes": self.args.body,
                "urls": [self.url(i, relay) for i in indices]}

    def pressure(self):
        idle = self.profile("pressure-idle", duration=2)
        rows = []
        with contextlib.ExitStack() as sockets:
            for index in range(self.n):
                limit = self.args.parallel if index == 0 else self.args.sibling_parallel
                for _ in range(limit):
                    sock = sockets.enter_context(socket.socket())
                    sock.settimeout(3)
                    sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 4096)
                    sock.connect((HOST, self.relay_port))
                    path = self.url(index).split(str(self.relay_port), 1)[1]
                    wire = (f"GET {path} HTTP/1.1\r\nHost: {HOST}\r\n"
                            f"X-Source-Broker-Key: {self.secrets['broker']}\r\n"
                            "Connection: close\r\n\r\n").encode()
                    sock.sendall(wire)
            for _ in range(20):
                rows.append({"inFlight": sum(c["in_flight"] for c in self.status()),
                             **{role: proc(self.roles[role].pid) for role in ("relay", "agent")}})
                time.sleep(0.1)
        self.record({"case": "body-pressure", "channels": self.n, "responseBytes": self.args.body,
                     "peakInFlight": max(row["inFlight"] for row in rows), "samples": rows,
                     "idle": idle["steady"]})

    def recovery(self):
        with concurrent.futures.ThreadPoolExecutor(self.args.parallel) as pool:
            held = [pool.submit(local, self.url(0, query="?hold=1"), self.headers)
                    for _ in range(self.args.parallel)]
            wait(lambda: any(item["id"] == self.targets[0]["id"] and item["in_flight"] >= self.args.parallel
                             for item in self.status()), 5, 0.005)
            code, headers, _ = local(self.url(0), self.headers)
            began = time.monotonic()
            sibling, _, _ = local(self.url(1), self.headers)
            wait(lambda: local(self.url(0), self.headers)[0] == 200, 5, 0.01)
            recovered = 1000 * (time.monotonic() - began)
            successful_held = sum(task.result()[0] == 200 for task in held)
        began = time.monotonic()
        self.proof.touch()
        wait(lambda: local(self.url(0), self.headers)[0] == 503)
        detect = 1000 * (time.monotonic() - began)
        self.proof.unlink()
        began = time.monotonic()
        wait(lambda: local(self.url(0), self.headers)[0] == 200)
        proof_return = 1000 * (time.monotonic() - began)
        self.record({"case": "controlled-recovery", "busyStatus": code, "retryAfter": headers.get("Retry-After"),
                     "siblingStatus": sibling, "successfulHeld": successful_held,
                     "capacityRecoveryMSFrom503": recovered, "proofDetectionMS": detect,
                     "proofRecoveryMS": proof_return})
        assert code == 503 and headers.get("Retry-After") == "1" and sibling == 200
        assert successful_held == self.args.parallel


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--binary", required=True, type=Path)
    ap.add_argument("--variant", choices=("reference", "candidate"), required=True)
    ap.add_argument("--out", required=True, type=Path)
    ap.add_argument("--suite", choices=("sweep", "fair", "wide", "pressure", "recovery", "tcp-ablation"), default="sweep")
    ap.add_argument("--rates", default="50,250,500,1000,2500,5000,10000,50000,100000")
    ap.add_argument("--hot-rate", type=int, default=50_000)
    ap.add_argument("--seconds", default=3.0, type=float)
    ap.add_argument("--parallel", type=int, default=8)
    ap.add_argument("--sibling-parallel", type=int, default=2)
    ap.add_argument("--channels", type=int)
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--origin-workers", type=int, default=2)
    ap.add_argument("--concurrency", type=int, default=384)
    ap.add_argument("--body", type=int, default=128)
    ap.add_argument("--go-cores", type=int, default=4)
    ap.add_argument("--lag-ms", type=int, default=10)
    ap.add_argument("--ingress-nagle", action="store_true", help="diagnostic comparison with ingress TCP_NODELAY disabled")
    ap.add_argument("--hold-ms", type=int, default=650)
    ap.add_argument("--idle-connections", type=int, default=128)
    ap.add_argument("--limit-rps", type=int, default=0)
    ap.add_argument("--channel-memory", type=int, default=0)
    ap.add_argument("--data-memory", type=int, default=320)
    ap.add_argument("--data-connections", type=int, default=2048)
    ap.add_argument("--agent-streams", type=int, default=700)
    args = ap.parse_args()
    args.binary = args.binary.resolve(strict=True)
    args.out.mkdir(parents=True, exist_ok=True)
    if (args.out / "profiles.jsonl").exists():
        ap.error("choose a fresh output directory")
    if args.suite == "wide":
        channels = 64 if args.variant == "candidate" else 16
    else:
        channels = 1 if args.suite in ("sweep", "tcp-ablation", "pressure") else 2
    metric = args.channels or channels
    meta = {key: str(value) if isinstance(value, Path) else value for key, value in vars(args).items()
            if key not in ("binary", "out")}
    meta.update({"channels": metric, "binarySHA256": hashlib.sha256(args.binary.read_bytes()).hexdigest(),
                 "kernel": platform.release(), "machine": platform.machine(), "cpus": len(os.sched_getaffinity(0)),
                 "node": subprocess.check_output(["node", "--version"], text=True).strip(),
                 "openssl": subprocess.check_output(["openssl", "version"], text=True).strip(),
                 "python": platform.python_version(), "topology": "loopback/private HTTP and TLS-terminated WSS",
                 "startedUTC": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())})
    (args.out / "environment.json").write_text(json.dumps(meta, indent=2) + "\n")
    lab = Lab(args, metric, args.out)
    with lab.close:
        lab.setup()
        if args.suite == "sweep":
            lab.profile("idle", duration=2)
            for rate in map(int, args.rates.split(",")):
                for relay in (False, True):
                    label = ("relay" if relay else "direct") + f"-{rate}"
                    group = lab.traffic(label, rate, relay=relay)
                    lab.profile(label, [group], direct=not relay)
        elif args.suite == "fair":
            sibling = lab.traffic("sibling", 10, (1,), sibling=True)
            lab.profile("sibling-idle", [sibling])
            lab.profile("sibling-with-hot", [lab.traffic("hot", args.hot_rate), sibling])
        elif args.suite == "tcp-ablation":
            for rate in map(int, args.rates.split(",")):
                for close in (False, True):
                    label = ("direct-close" if close else "direct-keepalive") + f"-{rate}"
                    group = lab.traffic(label, rate, relay=False)
                    if close:
                        group["headers"] = {"Connection": "close"}
                    lab.profile(label, [group], direct=True)
        elif args.suite == "pressure":
            lab.pressure()
        elif args.suite == "wide":
            lab.profile(f"idle-{metric}", duration=3)
            group = lab.traffic("spread", args.hot_rate, tuple(range(metric)))
            lab.profile(f"loaded-{metric}", [group])
        else:
            lab.recovery()


if __name__ == "__main__":
    main()
