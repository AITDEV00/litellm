package reconcile

import (
	"context"
	"net/http"
	"time"

	"example.org/litellm/source-agent/target"
	"example.org/litellm/source-agent/transport"
)

const DefaultDataMiB = 96
const DefaultProbeMiB = 32
const siblingReserve = (target.MaxTargets - 1) * (transport.RequestCharge + transport.StreamCharge)

type OriginPool interface {
	http.RoundTripper
	Sweep(time.Time)
	DiscardIdle()
}

type RelayCapacity struct {
	DataMiB  int
	ProbeMiB int
	Pool     func(context.Context, target.Descriptor, Dial) OriginPool
}

// rateBucket is used with Relay.mu held, together with the existing admission check.
type rateBucket struct {
	perSecond float64
	burst     float64
	tokens    float64
	last      time.Time
}

func newRate(d target.Descriptor) rateBucket {
	if d.Scale == nil || d.Scale.RequestsPerSecond == 0 {
		return rateBucket{}
	}
	burst := d.Scale.Burst
	if burst == 0 {
		burst = min(d.StreamLimit(), max(1, d.Scale.RequestsPerSecond/10))
	}
	return rateBucket{perSecond: float64(d.Scale.RequestsPerSecond),
		burst: float64(burst), tokens: float64(burst)}
}

func (b *rateBucket) allow(now time.Time) bool {
	if b.perSecond == 0 {
		return true
	}
	if !b.last.IsZero() {
		b.tokens = min(b.burst, b.tokens+now.Sub(b.last).Seconds()*b.perSecond)
	}
	b.last = now
	if b.tokens < 1 {
		return false
	}
	b.tokens--
	return true
}

func (r *Relay) takeData(c *channel, bytes int64, first bool) bool {
	reserve := siblingReserve
	if first {
		reserve = 0
	}
	if !r.dataBudget.Take(bytes, reserve) {
		return false
	}
	if c.budget != nil && !c.budget.Take(bytes, 0) {
		r.dataBudget.Release(bytes)
		return false
	}
	return true
}

func (r *Relay) releaseData(c *channel, bytes int64) {
	if c.budget != nil {
		c.budget.Release(bytes)
	}
	r.dataBudget.Release(bytes)
}

func (r *Relay) reserveDial(p *peer, c *channel) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	if c.ctx.Err() != nil || c.resident >= c.approval.Descriptor.StreamLimit() {
		return false
	}
	limit, channels := p.dataStreams, target.MaxTargets
	if limit == 0 {
		// Pass 1 advertises no data capacity and accepts 160 streams total.
		limit, channels = 128, 16
	}
	first := c.resident == 0
	if p.resident >= limit || (!first && p.extraResident >= limit-channels) ||
		!r.takeData(c, transport.StreamCharge, first) {
		return false
	}
	c.resident++
	p.resident++
	if !first {
		p.extraResident++
	}
	return true
}

func (r *Relay) releaseDial(p *peer, c *channel) {
	r.mu.Lock()
	c.resident--
	p.resident--
	if c.resident > 0 {
		p.extraResident--
	}
	r.mu.Unlock()
	r.releaseData(c, transport.StreamCharge)
}
