package reconcile

import (
	"context"
	"testing"
	"time"

	"example.org/litellm/source-agent/target"
	"example.org/litellm/source-agent/transport"
)

func TestScaleBucket(t *testing.T) {
	rate := newRate(target.Descriptor{Parallel: 512, Scale: &target.Scale{RequestsPerSecond: 10000, Burst: 2}})
	now := time.Now()
	if !rate.allow(now) || !rate.allow(now) || rate.allow(now) ||
		rate.allow(now.Add(99*time.Microsecond)) || !rate.allow(now.Add(101*time.Microsecond)) {
		t.Fatal("rate bucket failed burst and microsecond refill")
	}
}

func TestHotChannelLeavesPhysicalStreamForSibling(t *testing.T) {
	r := NewRelay(nil, nil, RelayCapacity{DataMiB: 256})
	p := &peer{dataStreams: transport.DefaultDataStreams}
	h := &channel{ctx: context.Background(), approval: Admission{Descriptor: target.Descriptor{Parallel: 512}}}
	s := &channel{ctx: context.Background(), approval: Admission{Descriptor: target.Descriptor{Parallel: 2}}}
	hotLimit := p.dataStreams - target.MaxTargets + 1
	for i := 0; i < hotLimit; i++ {
		if !r.reserveDial(p, h) {
			t.Fatalf("hot channel lost its stream quota after %d reservations", i)
		}
	}
	if r.reserveDial(p, h) || !r.reserveDial(p, s) || r.reserveDial(p, s) {
		t.Fatal("hot case used a spare slot or sibling could not use its reservation")
	}
	r.releaseDial(p, s)
	for i := 0; i < hotLimit; i++ {
		r.releaseDial(p, h)
	}
	if p.resident != 0 || p.extraResident != 0 || h.resident != 0 || s.resident != 0 {
		t.Fatal("stream permits leaked")
	}
}

func TestDataByteReserve(t *testing.T) {
	r := NewRelay(nil, nil, RelayCapacity{DataMiB: 32, ProbeMiB: 1})
	h, s := &channel{}, &channel{}
	one := transport.StreamCharge + transport.RequestCharge
	taken := 0
	for r.takeData(h, one, taken == 0) {
		taken++
	}
	if taken == 0 || !r.takeData(s, one, true) ||
		!r.probeBudget.Take(transport.StreamCharge, 0) {
		t.Fatal("data channel consumed the spare or the proof budget")
	}
	r.probeBudget.Release(transport.StreamCharge)
	r.releaseData(s, one)
	for i := 0; i < taken; i++ {
		r.releaseData(h, one)
	}
}
