package reconcile

import (
	"context"
	"errors"
	"net"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"example.org/litellm/source-agent/target"
	"example.org/litellm/source-agent/transport"
	yamux "github.com/libp2p/go-yamux/v5"
)

type Dial func(context.Context) (net.Conn, error)
type Probe func(context.Context, string, Admission, Dial) error

type Relay struct {
	feed        Feed
	probe       Probe
	dataBudget  *transport.Budget
	probeBudget *transport.Budget
	capacity    RelayCapacity

	mu        sync.Mutex
	policy    Snapshot
	loadedAt  time.Time
	feedError string
	peers     map[string]*peer
}

type peer struct {
	id            string
	epoch         uint64
	digest        string
	mux           *transport.Session
	inventory     map[string]string
	reportedAt    time.Time
	attachedAt    time.Time
	reportedRev   uint64
	ctx           context.Context
	cancel        context.CancelFunc
	channels      map[string]*channel
	dataStreams   int
	resident      int
	extraResident int
}

type channel struct {
	approval  Admission
	ctx       context.Context
	cancel    context.CancelFunc
	goodUntil time.Time
	problem   string
	active    atomic.Int64
	sessions  map[string]time.Time
	open      transport.Open
	resident  int
	budget    *transport.Budget
	rate      rateBucket
	origin    OriginPool
}

func NewRelay(feed Feed, probe Probe, config ...RelayCapacity) *Relay {
	capacity := RelayCapacity{}
	if len(config) != 0 {
		capacity = config[0]
	}
	if capacity.DataMiB == 0 {
		capacity.DataMiB = DefaultDataMiB
	}
	if capacity.ProbeMiB == 0 {
		capacity.ProbeMiB = DefaultProbeMiB
	}
	return &Relay{feed: feed, probe: probe, peers: make(map[string]*peer), capacity: capacity,
		dataBudget:  transport.NewBudget(int64(capacity.DataMiB) << 20),
		probeBudget: transport.NewBudget(int64(capacity.ProbeMiB) << 20)}
}

func (r *Relay) Run(ctx context.Context) {
	defer func() {
		r.mu.Lock()
		defer r.mu.Unlock()
		for _, p := range r.peers {
			p.cancel()
		}
	}()
	interval := time.NewTicker(500 * time.Millisecond)
	defer interval.Stop()
	for {
		policy, err := r.feed(ctx)
		now := time.Now()
		r.mu.Lock()
		switch {
		case err != nil:
			r.feedError = "read_failed"
		case policy.normalize() != nil:
			r.feedError = "invalid_snapshot"
		case checkPolicyTransition(r.policy, policy) != nil:
			r.feedError = "revision_conflict"
		default:
			r.policy, r.loadedAt = policy, now
			r.feedError = ""
		}
		for id, p := range r.peers {
			grant, ok := r.policy.agent(id)
			if !r.fresh(now) || !ok || grant.Phase != "active" || grant.Epoch != p.epoch ||
				grant.CredentialHash != p.digest || (!p.reportedAt.IsZero() && now.Sub(p.reportedAt) > transport.InventoryTTL) {
				delete(r.peers, id)
				p.cancel()
				continue
			}
			r.syncChannels(p, grant, now)
		}
		r.mu.Unlock()
		select {
		case <-ctx.Done():
			return
		case <-interval.C:
		}
	}
}

func (r *Relay) fresh(now time.Time) bool {
	return !r.loadedAt.IsZero() && now.Sub(r.loadedAt) < PolicyTTL
}

func (r *Relay) Attach(w http.ResponseWriter, req *http.Request) {
	if !strings.EqualFold(req.Header.Get("Upgrade"), "websocket") ||
		req.Header.Get("Sec-WebSocket-Protocol") != transport.Protocol {
		http.Error(w, "source-agent WebSocket required", http.StatusUpgradeRequired)
		return
	}
	id := req.Header.Get("X-Source-Agent")
	epoch, err := strconv.ParseUint(req.Header.Get("X-Source-Epoch"), 10, 64)
	r.mu.Lock()
	grant, ok := r.policy.agent(id)
	if !r.fresh(time.Now()) {
		r.mu.Unlock()
		http.Error(w, "authority unavailable", http.StatusServiceUnavailable)
		return
	}
	if !ok || err != nil || grant.Phase != "active" || epoch != grant.Epoch || !Matches(grant.CredentialHash, Auth(req)) {
		r.mu.Unlock()
		http.Error(w, "source agent unauthorized", http.StatusUnauthorized)
		return
	}
	if _, exists := r.peers[id]; exists {
		r.mu.Unlock()
		http.Error(w, "source agent already attached", http.StatusConflict)
		return
	}
	ctx, cancel := context.WithCancel(req.Context())
	p := &peer{id: id, epoch: epoch, digest: grant.CredentialHash, ctx: ctx, cancel: cancel, attachedAt: time.Now(),
		channels: make(map[string]*channel)}
	r.peers[id] = p
	r.mu.Unlock()
	defer func() {
		cancel()
		r.mu.Lock()
		defer r.mu.Unlock()
		if r.peers[id] == p {
			delete(r.peers, id)
		}
	}()
	mux, err := transport.Accept(ctx, w, req)
	if err != nil {
		return
	}
	defer mux.Close()
	stop := context.AfterFunc(ctx, func() { _ = mux.Close() })
	defer stop()
	r.mu.Lock()
	p.mux = mux
	r.mu.Unlock()

	timer := time.AfterFunc(transport.InventoryTTL, cancel)
	stream, err := mux.AcceptStream()
	timer.Stop()
	if err != nil {
		return
	}
	defer stream.Reset()
	for ctx.Err() == nil {
		stream.SetDeadline(time.Now().Add(transport.InventoryTTL))
		var view transport.Inventory
		if err := transport.Read(stream, &view, transport.MaxControl); err != nil {
			return
		}
		result, err := r.inventory(p, view)
		if err != nil || transport.Write(stream, result, transport.MaxControl) != nil {
			return
		}
	}
}

func (r *Relay) inventory(p *peer, view transport.Inventory) (transport.Reply, error) {
	count := target.MaxTargets
	if view.DataStreams == 0 {
		count = 16
	} else if view.DataStreams < count || view.DataStreams > transport.MaxDataStreams {
		return transport.Reply{}, errors.New("invalid advertised data-stream capacity")
	}
	if view.Revision == 0 || len(view.Targets) > count {
		return transport.Reply{}, errors.New("invalid inventory")
	}
	inventory := make(map[string]string, len(view.Targets))
	for _, d := range view.Targets {
		if !target.ID(d.ID) || !target.Digest(d.Fingerprint) || inventory[d.ID] != "" {
			return transport.Reply{}, errors.New("invalid or duplicate inventory channel")
		}
		inventory[d.ID] = d.Fingerprint
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	grant, ok := r.policy.agent(p.id)
	now := time.Now()
	if r.peers[p.id] != p || !r.fresh(now) || !ok || view.Revision < p.reportedRev ||
		(p.reportedRev != 0 && view.DataStreams != p.dataStreams) {
		return transport.Reply{}, errors.New("stale inventory or connection")
	}
	p.inventory, p.reportedRev, p.reportedAt = inventory, view.Revision, now
	p.dataStreams = view.DataStreams
	r.syncChannels(p, grant, now)
	return r.report(p, now), nil
}

func (r *Relay) syncChannels(p *peer, grant AgentGrant, now time.Time) {
	for name, c := range p.channels {
		desired, exists := grant.channel(name)
		if !exists || p.inventory[name] != desired.Descriptor.Fingerprint() || !compatible(c.approval, desired) ||
			desired.Phase == "revoked" || (desired.Phase == "draining" && !now.Before(desired.DrainUntil)) {
			delete(p.channels, name)
			c.cancel()
			continue
		}
		c.approval.Phase, c.approval.DrainUntil = desired.Phase, desired.DrainUntil
		for session, expires := range c.sessions {
			if !now.Before(expires) {
				delete(c.sessions, session)
			}
		}
	}
	for _, desired := range grant.Channels {
		d := desired.Descriptor
		id := d.ID
		if p.channels[id] != nil || desired.Phase != "active" || p.inventory[id] == "" {
			continue
		}
		fingerprint := d.Fingerprint()
		if p.inventory[id] != fingerprint {
			continue
		}
		ctx, cancel := context.WithCancel(p.ctx)
		c := &channel{approval: desired, ctx: ctx, cancel: cancel, sessions: make(map[string]time.Time),
			open: transport.Open{Target: id, Fingerprint: fingerprint}, rate: newRate(d)}
		if d.Scale != nil {
			if d.Scale.MemoryMiB > 0 {
				c.budget = transport.NewBudget(int64(d.Scale.MemoryMiB) << 20)
			}
			if r.capacity.Pool != nil && !d.Scale.DisableKeepAlive {
				c.origin = r.capacity.Pool(ctx, d, func(ctx context.Context) (net.Conn, error) {
					return r.dial(ctx, p, c, false)
				})
			}
		}
		p.channels[id] = c
		go r.watch(p, c, desired)
	}
}

func (r *Relay) watch(p *peer, c *channel, approval Admission) {
	interval := time.NewTicker(transport.Heartbeat)
	defer interval.Stop()
	for {
		if c.origin != nil {
			c.origin.Sweep(time.Now())
		}
		r.mu.Lock()
		active := c.approval.Phase == "active"
		r.mu.Unlock()
		if active && r.probeBudget.Take(transport.StreamCharge, 0) {
			r.probeChannel(p, c, approval)
			r.probeBudget.Release(transport.StreamCharge)
		}
		select {
		case <-c.ctx.Done():
			return
		case <-interval.C:
		}
	}
}

func (r *Relay) probeChannel(p *peer, c *channel, approval Admission) {
	ctx, cancel := context.WithTimeout(c.ctx, 1500*time.Millisecond)
	err := r.probe(ctx, p.id, approval, func(ctx context.Context) (net.Conn, error) { return r.dial(ctx, p, c, true) })
	cancel()
	r.mu.Lock()
	now := time.Now()
	expired := !c.goodUntil.IsZero() && !now.Before(c.goodUntil)
	if p.channels[approval.Descriptor.ID] == c && c.ctx.Err() == nil && c.approval.Phase == "active" {
		c.goodUntil, c.problem = time.Time{}, ""
		if err != nil {
			c.problem = err.Error()
		} else if !expired || c.origin == nil {
			c.goodUntil = now.Add(HealthTTL)
		}
	}
	r.mu.Unlock()
	if c.origin != nil && (err != nil || expired) {
		c.origin.DiscardIdle()
		if err == nil {
			r.mu.Lock()
			if p.channels[approval.Descriptor.ID] == c && c.ctx.Err() == nil && c.approval.Phase == "active" {
				c.goodUntil = now.Add(HealthTTL)
			}
			r.mu.Unlock()
		}
	}
}

func (r *Relay) dial(ctx context.Context, p *peer, c *channel, proof bool) (net.Conn, error) {
	ctx, cancel := context.WithCancel(ctx)
	defer cancel()
	revoke := context.AfterFunc(c.ctx, cancel)
	defer revoke()
	if c.ctx.Err() != nil {
		return nil, c.ctx.Err()
	}
	if !proof && !r.reserveDial(p, c) {
		if c.ctx.Err() != nil {
			return nil, c.ctx.Err()
		}
		return nil, ErrCapacity
	}
	release := func() {
		if !proof {
			r.releaseDial(p, c)
		}
	}
	open := c.open
	open.Probe = proof
	stream, err := p.mux.Target(ctx, open)
	if err != nil {
		release()
		return nil, err
	}
	closeStream := sync.OnceFunc(func() {
		_ = stream.Reset()
		release()
	})
	stop := context.AfterFunc(c.ctx, closeStream)
	return &channelConn{Stream: stream, close: func() { stop(); closeStream() }}, nil
}

type channelConn struct {
	*yamux.Stream
	close func()
}

func (c *channelConn) Close() error {
	c.close()
	return nil
}

func (r *Relay) report(p *peer, now time.Time) transport.Reply {
	reply := transport.Reply{PolicyRevision: r.policy.Revision, AttachedAt: p.attachedAt.UnixMilli()}
	grant, _ := r.policy.agent(p.id)
	for id, fingerprint := range p.inventory {
		view := transport.Observation{ID: id, Phase: "awaiting_approval"}
		if desired, ok := grant.channel(id); ok {
			view.Revision, view.Phase = desired.Revision, desired.Phase
			if desired.Descriptor.Fingerprint() != fingerprint {
				view.Phase = "descriptor_mismatch"
			}
		}
		if c := p.channels[id]; c != nil {
			view.Ready = c.approval.Phase == "active" && now.Before(c.goodUntil) && r.fresh(now)
			view.InFlight, view.Problem = int(c.active.Load()), c.problem
		}
		reply.Targets = append(reply.Targets, view)
	}
	return reply
}

type RelayStatus struct {
	Revision  uint64                     `json:"loaded_revision"`
	Fresh     bool                       `json:"fresh"`
	FeedError string                     `json:"feed_error,omitempty"`
	Agents    map[string]transport.Reply `json:"attached"`
}

func (r *Relay) Status() RelayStatus {
	now := time.Now()
	r.mu.Lock()
	defer r.mu.Unlock()
	s := RelayStatus{Revision: r.policy.Revision, Fresh: r.fresh(now), FeedError: r.feedError, Agents: make(map[string]transport.Reply)}
	for id, p := range r.peers {
		s.Agents[id] = r.report(p, now)
	}
	return s
}

var ErrUnavailable = errors.New("channel unavailable")
var ErrSession = errors.New("MCP session is gone")
var ErrRate = errors.New("channel request rate exceeded")
var ErrCapacity = errors.New("channel byte or stream budget exhausted")

type Lease struct {
	Admission Admission
	Context   context.Context
	Dial      Dial
	Origin    http.RoundTripper
	Finish    func()
	Session   func(id string, remove bool) bool
}

func (r *Relay) Acquire(ctx context.Context, agent, targetID, sessionID string) (Lease, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	p := r.peers[agent]
	now := time.Now()
	if p == nil || p.ctx.Err() != nil || now.Sub(p.reportedAt) > transport.InventoryTTL || !r.fresh(now) {
		if sessionID != "" {
			return Lease{}, ErrSession
		}
		return Lease{}, ErrUnavailable
	}
	c := p.channels[targetID]
	if sessionID != "" && (c == nil || c.approval.Descriptor.Kind != "mcp" || !now.Before(c.sessions[sessionID])) {
		return Lease{}, ErrSession
	}
	if c == nil || c.ctx.Err() != nil || c.approval.Phase != "active" || !now.Before(c.goodUntil) ||
		c.active.Load() >= int64(c.approval.Descriptor.StreamLimit()) {
		return Lease{}, ErrUnavailable
	}
	approval := c.approval
	if !r.takeData(c, transport.RequestCharge, c.active.Load() == 0) {
		return Lease{}, ErrCapacity
	}
	if !c.rate.allow(now) {
		r.releaseData(c, transport.RequestCharge)
		return Lease{}, ErrRate
	}
	if sessionID != "" {
		c.sessions[sessionID] = now.Add(30 * time.Minute)
	}
	c.active.Add(1)
	streamCtx, cancel := context.WithTimeout(ctx, approval.Descriptor.RequestTime())
	drop := context.AfterFunc(c.ctx, cancel)
	finished := sync.OnceFunc(func() {
		drop()
		cancel()
		r.releaseData(c, transport.RequestCharge)
		c.active.Add(-1)
	})
	return Lease{Admission: approval, Context: streamCtx,
		Dial:   func(ctx context.Context) (net.Conn, error) { return r.dial(ctx, p, c, false) },
		Origin: c.origin, Finish: finished,
		Session: func(id string, remove bool) bool {
			r.mu.Lock()
			defer r.mu.Unlock()
			if c.ctx.Err() != nil || p.channels[targetID] != c {
				return false
			}
			if remove {
				delete(c.sessions, id)
				return true
			}
			if len(c.sessions) >= 256 && c.sessions[id].IsZero() {
				return false
			}
			c.sessions[id] = time.Now().Add(30 * time.Minute)
			return true
		},
	}, nil
}
