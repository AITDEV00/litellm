// Package adapters projects approved channels as private, ordinary HTTP origins.
package adapters

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/base64"
	"errors"
	"io"
	"net"
	"net/http"
	"net/url"
	"strings"
	"time"

	"example.org/litellm/source-agent/reconcile"
	"example.org/litellm/source-agent/target"
	"example.org/litellm/source-agent/transport"
)

const MaxRequest = 2 << 20
const MaxResponse = 16 << 20
const RequestTimeout = target.MaxRequestTime

func authority(d target.Descriptor) string {
	if d.TLSName != "" {
		return d.TLSName
	}
	if d.Service != nil {
		return d.Service.Name + "." + d.Service.Namespace + ".svc"
	}
	return d.Address
}

func origin(d target.Descriptor, path, query string) *url.URL {
	scheme := "http"
	if d.TLSName != "" {
		scheme = "https"
	}
	return &url.URL{Scheme: scheme, Host: authority(d), Path: path, RawQuery: query}
}

func originTransport(dial reconcile.Dial, trusted *http.Client) *http.Transport {
	base := trusted.Transport.(*http.Transport)
	tls := base.TLSClientConfig.Clone()
	return &http.Transport{
		TLSClientConfig: tls, TLSHandshakeTimeout: 3 * time.Second, DisableKeepAlives: true,
		DisableCompression: true, ResponseHeaderTimeout: 15 * time.Second, MaxResponseHeaderBytes: 32 << 10,
		DialContext: func(ctx context.Context, _, _ string) (net.Conn, error) { return dial(ctx) },
	}
}

func ProofMessage(nonce, agent, channel, catalog string) []byte {
	return []byte("source-agent-catalog-v1\n" + nonce + "\n" + agent + "\n" + channel + "\n" + catalog)
}

func VerifyProof(keyText, signature, nonce, agent, channel, catalog string) bool {
	key, e1 := base64.StdEncoding.DecodeString(keyText)
	sig, e2 := base64.StdEncoding.DecodeString(signature)
	return e1 == nil && e2 == nil && len(key) == ed25519.PublicKeySize &&
		ed25519.Verify(ed25519.PublicKey(key), ProofMessage(nonce, agent, channel, catalog), sig)
}

func CatalogProbe(trusted *http.Client) reconcile.Probe {
	return func(ctx context.Context, agent string, approval reconcile.Admission, dial reconcile.Dial) error {
		random := make([]byte, 32)
		if _, err := rand.Read(random); err != nil {
			return errors.New("could not make challenge")
		}
		nonce := base64.RawURLEncoding.EncodeToString(random)
		d := approval.Descriptor
		req, err := http.NewRequestWithContext(ctx, http.MethodGet, origin(d, d.Proof, "").String(), nil)
		if err != nil {
			return errors.New("invalid proof request")
		}
		req.Header.Set("X-Source-Nonce", nonce)
		req.Header.Set("X-Source-Agent", agent)
		req.Header.Set("X-Source-Channel", d.ID)
		resp, err := originTransport(dial, trusted).RoundTrip(req)
		if err != nil {
			return errors.New("origin proof unavailable")
		}
		defer resp.Body.Close()
		catalog := resp.Header.Get("X-Source-Catalog")
		if resp.StatusCode != http.StatusNoContent || !target.Digest(catalog) {
			return errors.New("invalid origin proof response")
		}
		if !VerifyProof(approval.ProofKey, resp.Header.Get("X-Source-Signature"), nonce, agent, d.ID, catalog) {
			return errors.New("origin proof signature mismatch")
		}
		if catalog != approval.Catalog {
			return errors.New("catalog differs from approved revision")
		}
		return nil
	}
}

type HTTP struct {
	Relay   *reconcile.Relay
	KeyHash string
	TLS     *http.Client
}

func (a HTTP) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if !reconcile.Matches(a.KeyHash, r.Header.Get("X-Source-Broker-Key")) {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	if r.Method == http.MethodConnect || r.Header.Get("Upgrade") != "" || r.URL.RawPath != "" || !target.Path(r.URL.Path) {
		http.Error(w, "unsupported request", http.StatusBadRequest)
		return
	}
	parts := strings.SplitN(strings.TrimPrefix(r.URL.Path, "/"), "/", 4)
	if len(parts) < 3 || parts[0] != "sources" || !target.ID(parts[1]) || !target.ID(parts[2]) {
		http.NotFound(w, r)
		return
	}
	ids := r.Header.Values("Mcp-Session-Id")
	var id string
	if len(ids) > 0 {
		if len(ids) != 1 || !validSession(ids[0]) {
			http.Error(w, "invalid MCP session", http.StatusBadRequest)
			return
		}
		id = ids[0]
	}
	lease, err := a.Relay.Acquire(r.Context(), parts[1], parts[2], id)
	if errors.Is(err, reconcile.ErrSession) {
		http.Error(w, "MCP session is gone; initialize again", http.StatusNotFound)
		return
	}
	if err != nil {
		w.Header().Set("Retry-After", "1")
		if errors.Is(err, reconcile.ErrRate) {
			http.Error(w, "channel request rate exceeded", http.StatusTooManyRequests)
			return
		}
		http.Error(w, "source unavailable", http.StatusServiceUnavailable)
		return
	}
	defer lease.Finish()
	suffix := ""
	if len(parts) == 4 {
		suffix = "/" + parts[3]
	}
	d := lease.Admission.Descriptor
	if d.Scale != nil {
		deadline, _ := lease.Context.Deadline()
		controller := http.NewResponseController(w)
		_ = controller.SetReadDeadline(deadline)
		_ = controller.SetWriteDeadline(deadline.Add(5 * time.Second))
	}
	path, allowed := d.Route(r.Method, suffix)
	if !allowed {
		http.NotFound(w, r)
		return
	}
	if r.ContentLength > MaxRequest {
		http.Error(w, "request exceeds size limit", http.StatusRequestEntityTooLarge)
		return
	}
	var body io.Reader
	if r.Body != nil && r.Body != http.NoBody {
		body = http.MaxBytesReader(w, r.Body, MaxRequest)
	}
	u := origin(d, path, r.URL.RawQuery)
	out, err := http.NewRequestWithContext(lease.Context, r.Method, u.String(), body)
	if err != nil {
		http.Error(w, "bad source request", http.StatusBadRequest)
		return
	}
	out.ContentLength = r.ContentLength
	for _, key := range []string{"Accept", "Content-Type", "If-None-Match", "If-Modified-Since"} {
		copyHeader(out.Header, r.Header, key)
	}
	if d.Kind == "mcp" {
		for _, key := range []string{"Mcp-Protocol-Version", "Mcp-Session-Id", "Mcp-Method", "Mcp-Name", "Last-Event-Id"} {
			copyHeader(out.Header, r.Header, key)
		}
	}
	reader := lease.Origin
	if reader == nil {
		fresh := originTransport(lease.Dial, a.TLS)
		fresh.ResponseHeaderTimeout = d.HeaderTime()
		reader = fresh
	}
	resp, err := reader.RoundTrip(out)
	if err != nil {
		if _, ok := errors.AsType[*http.MaxBytesError](err); ok {
			http.Error(w, "request exceeds size limit", http.StatusRequestEntityTooLarge)
			return
		}
		if errors.Is(err, reconcile.ErrCapacity) || errors.Is(err, transport.ErrTargetBusy) {
			w.Header().Set("Retry-After", "1")
			http.Error(w, "source unavailable", http.StatusServiceUnavailable)
			return
		}
		http.Error(w, "origin request failed", http.StatusBadGateway)
		return
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 300 && resp.StatusCode < 400 && resp.StatusCode != http.StatusNotModified {
		http.Error(w, "origin redirects are disabled", http.StatusBadGateway)
		return
	}
	if resp.ContentLength > MaxResponse {
		http.Error(w, "origin response exceeds size limit", http.StatusBadGateway)
		return
	}
	if d.Kind == "mcp" && !mcpSession(w, r, resp, id, lease) {
		http.Error(w, "invalid or exhausted MCP session", http.StatusBadGateway)
		return
	}
	for _, key := range []string{"Content-Type", "Content-Length", "Etag", "Last-Modified", "Retry-After", "Mcp-Protocol-Version"} {
		copyHeader(w.Header(), resp.Header, key)
	}
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(resp.StatusCode)
	writer := io.Writer(w)
	if strings.HasPrefix(resp.Header.Get("Content-Type"), "text/event-stream") {
		flush := http.NewResponseController(w)
		_ = flush.Flush()
		writer = flushing{w: w, flush: flush}
	}
	limited := &io.LimitedReader{R: resp.Body, N: MaxResponse}
	if _, err := transport.Copy(writer, limited); err != nil {
		if r.Context().Err() == nil {
			panic(http.ErrAbortHandler)
		}
		return
	}
	if limited.N == 0 {
		var extra [1]byte
		if n, _ := resp.Body.Read(extra[:]); n > 0 {
			panic(http.ErrAbortHandler)
		}
	}
}

func validSession(id string) bool {
	if len(id) == 0 || len(id) > 256 {
		return false
	}
	for i := range len(id) {
		if id[i] <= 0x20 || id[i] >= 0x7f {
			return false
		}
	}
	return true
}

func mcpSession(w http.ResponseWriter, req *http.Request, resp *http.Response, id string, lease reconcile.Lease) bool {
	returned := resp.Header.Values("Mcp-Session-Id")
	success := resp.StatusCode >= 200 && resp.StatusCode < 300
	if id != "" && (resp.StatusCode == 404 || (req.Method == http.MethodDelete && success)) {
		lease.Session(id, true)
		return true
	}
	if len(returned) == 0 || !success {
		return len(returned) <= 1
	}
	if len(returned) != 1 || !validSession(returned[0]) ||
		(id != "" && returned[0] != id) || (id == "" && req.Method != http.MethodPost) || !lease.Session(returned[0], false) {
		return false
	}
	w.Header().Set("Mcp-Session-Id", returned[0])
	return true
}

func copyHeader(dst, src http.Header, key string) {
	for _, value := range src.Values(key) {
		dst.Add(key, value)
	}
}

type flushing struct {
	w     http.ResponseWriter
	flush *http.ResponseController
}

func (f flushing) Write(b []byte) (int, error) {
	n, err := f.w.Write(b)
	if err == nil {
		err = f.flush.Flush()
	}
	return n, err
}
