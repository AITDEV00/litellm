package adapters

import (
	"context"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"example.org/litellm/source-agent/reconcile"
	"example.org/litellm/source-agent/target"
)

func TestOriginPoolReuseAndFence(t *testing.T) {
	origin := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/api/drop" {
			conn, _, err := http.NewResponseController(w).Hijack()
			if err != nil {
				http.Error(w, "hijack failed", 500)
				return
			}
			conn.Close()
			return
		}
		w.Write([]byte("fixture"))
	}))
	defer origin.Close()
	trusted, err := reconcile.TLSClient("", 0)
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	d := target.Descriptor{Address: strings.TrimPrefix(origin.URL, "http://"), Path: "/api",
		Kind: "openapi", Parallel: 4, Scale: &target.Scale{IdleConnections: 2}}
	var dials atomic.Int64
	pool := PoolFactory(trusted)(ctx, d, func(ctx context.Context) (net.Conn, error) {
		dials.Add(1)
		return (&net.Dialer{}).DialContext(ctx, "tcp", d.Address)
	})

	get := func(path string) (*http.Response, error) {
		req, err := http.NewRequestWithContext(ctx, http.MethodGet, origin.URL+path, nil)
		if err != nil {
			t.Fatal(err)
		}
		return pool.RoundTrip(req)
	}
	ok := func() {
		t.Helper()
		resp, err := get("/api")
		if err != nil {
			t.Fatal(err)
		}
		body, readErr := io.ReadAll(resp.Body)
		closeErr := resp.Body.Close()
		if string(body) != "fixture" || readErr != nil || closeErr != nil {
			t.Fatalf("body %q, read %v, close %v", body, readErr, closeErr)
		}
	}
	ok()
	ok()
	if n := dials.Load(); n != 1 {
		t.Fatalf("warm requests used %d connections", n)
	}
	if resp, err := get("/api/drop"); err == nil {
		resp.Body.Close()
		t.Fatal("dropped response succeeded")
	}
	if n := dials.Load(); n != 1 {
		t.Fatalf("request was replayed on connection %d", n)
	}
	ok()
	pool.DiscardIdle()
	ok()
	if n := dials.Load(); n != 3 {
		t.Fatalf("wanted a new connection after invalidation, got %d", n)
	}
	cancel()
	if resp, err := get("/api"); err == nil {
		resp.Body.Close()
		t.Fatal("revoked generation used a connection")
	}
}

func TestOriginPoolHeaderDeadline(t *testing.T) {
	origin := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		time.Sleep(200 * time.Millisecond)
		w.WriteHeader(http.StatusNoContent)
	}))
	defer origin.Close()
	trusted, err := reconcile.TLSClient("", 0)
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	d := target.Descriptor{Address: strings.TrimPrefix(origin.URL, "http://"), Path: "/api",
		Kind: "openapi", Parallel: 2, Scale: &target.Scale{HeaderTimeoutMS: 10}}
	pool := PoolFactory(trusted)(ctx, d, func(ctx context.Context) (net.Conn, error) {
		return (&net.Dialer{}).DialContext(ctx, "tcp", d.Address)
	})
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, origin.URL+"/api", nil)
	if err != nil {
		t.Fatal(err)
	}
	res, err := pool.RoundTrip(req)
	if err == nil {
		res.Body.Close()
		t.Fatal("origin returned headers after the response deadline")
	}
}
