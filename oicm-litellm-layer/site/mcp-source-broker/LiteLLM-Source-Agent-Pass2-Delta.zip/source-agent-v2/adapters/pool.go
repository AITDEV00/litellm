package adapters

import (
	"context"
	"errors"
	"io"
	"net"
	"net/http"
	"sync"
	"time"

	"example.org/litellm/source-agent/reconcile"
	"example.org/litellm/source-agent/target"
	"example.org/litellm/source-agent/transport"
)

const idleLifetime = 15 * time.Second

type idleOrigin struct {
	conn   *http.ClientConn
	born   time.Time
	idleAt time.Time
}

type originPool struct {
	ctx       context.Context
	transport *http.Transport
	scheme    string
	addr      string
	idleCap   int
	maxAge    time.Duration

	mu    sync.Mutex
	idle  []idleOrigin
	epoch uint64
}

func PoolFactory(trusted *http.Client) func(context.Context, target.Descriptor, reconcile.Dial) reconcile.OriginPool {
	return func(ctx context.Context, d target.Descriptor, dial reconcile.Dial) reconcile.OriginPool {
		t := originTransport(dial, trusted)
		t.DisableKeepAlives = false
		t.ResponseHeaderTimeout = d.HeaderTime()
		t.Protocols = new(http.Protocols)
		t.Protocols.SetHTTP1(true)
		u := origin(d, d.Path, "")
		maxIdle := d.Scale.IdleConnections
		if maxIdle == 0 {
		maxIdle = min(d.StreamLimit(), 32)
		}
		p := &originPool{
			ctx: ctx, transport: t, scheme: u.Scheme, addr: net.JoinHostPort(u.Hostname(), u.Port()),
			idleCap: maxIdle, maxAge: transport.BridgeLifetime - d.RequestTime(),
		}
		context.AfterFunc(ctx, p.DiscardIdle)
		return p
	}
}

func (p *originPool) live(c idleOrigin, now time.Time) bool {
	return now.Sub(c.born) < p.maxAge && now.Sub(c.idleAt) < idleLifetime && c.conn.Available() == 1
}

func (p *originPool) checkout(ctx context.Context) (idleOrigin, uint64, error) {
	for {
		if err := ctx.Err(); err != nil {
			return idleOrigin{}, 0, err
		}
		if err := p.ctx.Err(); err != nil {
			return idleOrigin{}, 0, err
		}
		p.mu.Lock()
		epoch := p.epoch
		n := len(p.idle)
		if n == 0 {
			p.mu.Unlock()
			born := time.Now()
			conn, err := p.transport.NewClientConn(ctx, p.scheme, p.addr)
			return idleOrigin{conn: conn, born: born}, epoch, err
		}
		c := p.idle[n-1]
		p.idle[n-1] = idleOrigin{}
		p.idle = p.idle[:n-1]
		p.mu.Unlock()
		if p.live(c, time.Now()) {
			return c, epoch, nil
		}
		c.conn.Close()
	}
}

func (p *originPool) RoundTrip(req *http.Request) (*http.Response, error) {
	c, epoch, err := p.checkout(req.Context())
	if err != nil {
		if req.Body != nil {
			req.Body.Close()
		}
		return nil, err
	}
	if err := p.ctx.Err(); err != nil {
		c.conn.Close()
		if req.Body != nil {
			req.Body.Close()
		}
		return nil, err
	}
	// ClientConn performs this request on just this connection. In particular,
	// Transport.RoundTrip's reused-connection retry rules never apply here.
	resp, err := c.conn.RoundTrip(req)
	if err != nil {
		c.conn.Close()
		return nil, err
	}
	resp.Body = &poolBody{ReadCloser: resp.Body, complete: resp.Body == http.NoBody,
		put: func(clean bool) {
			if clean && req.Context().Err() == nil {
				c.idleAt = time.Now()
				if p.put(c, epoch) {
					return
				}
			}
			c.conn.Close()
		}}
	return resp, nil
}

func (p *originPool) put(c idleOrigin, epoch uint64) bool {
	if !p.live(c, c.idleAt) {
		return false
	}
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.ctx.Err() != nil || p.epoch != epoch || len(p.idle) >= p.idleCap {
		return false
	}
	p.idle = append(p.idle, c)
	return true
}

func (p *originPool) Sweep(now time.Time) {
	p.mu.Lock()
	var expired []idleOrigin
	kept := p.idle[:0]
	for _, c := range p.idle {
		if p.live(c, now) {
			kept = append(kept, c)
		} else {
			expired = append(expired, c)
		}
	}
	clear(p.idle[len(kept):])
	p.idle = kept
	p.mu.Unlock()
	retire(expired)
}

func (p *originPool) DiscardIdle() {
	p.mu.Lock()
	idle := p.idle
	p.idle = nil
	p.epoch++
	p.mu.Unlock()
	retire(idle)
}

func retire(entries []idleOrigin) {
	if len(entries) != 0 {
		// Close can wait for yamux's writer. The proof loop and new pool
		// epoch can progress while the detached streams return their credits.
		go func() {
			for _, c := range entries {
				c.conn.Close()
			}
		}()
	}
}

type poolBody struct {
	io.ReadCloser
	complete bool
	put      func(bool)
}

func (b *poolBody) Read(buf []byte) (int, error) {
	n, err := b.ReadCloser.Read(buf)
	if errors.Is(err, io.EOF) {
		b.complete = true
	}
	return n, err
}

func (b *poolBody) Close() error {
	err := b.ReadCloser.Close()
	if b.put != nil {
		b.put(b.complete && err == nil)
		b.put = nil
	}
	return err
}
